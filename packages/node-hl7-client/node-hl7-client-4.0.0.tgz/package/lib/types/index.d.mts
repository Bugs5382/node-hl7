import EventEmitter from "node:events";
import { Socket, TcpSocketConnectOpts } from "node:net";
import { ConnectionOptions } from "node:tls";

//#region src/builder/interface/hL7Node.d.ts
/**
 * Node Base
 * @since 1.0.0
 */
interface HL7Node {
  [Symbol.iterator]: () => Iterator<HL7Node>;
  exists: (path: number | string) => boolean;
  forEach: (callback: (value: HL7Node, index: number) => void) => void;
  get: (path: number | string) => HL7Node;
  isEmpty: () => boolean;
  length: number;
  name: string;
  path: string[];
  read: (path: string[]) => HL7Node;
  set: (path: number | string, value?: any) => HL7Node;
  toArray: () => HL7Node[];
  toBoolean: () => boolean;
  toDate: () => Date;
  toFile: (name: string, newLine?: boolean, location?: string) => void;
  toFloat: () => number;
  toInteger: () => number;
  toRaw: () => string;
  toString: () => string;
  write: (path: string[], value: string) => HL7Node;
}
//#endregion
//#region src/declaration/enum.d.ts
/**
 * Type of Segments Values
 * @remarks Used during the class creation to give each type its own index value.
 * This is done during the constructor phase of the classes.
 * @since 1.0.0
 */
declare enum Delimiters {
  /** Usually each line of the overall HL7 Message. */
  Segment = 0,
  /** The field of each segment. Usually separated with a | */
  Field = 1,
  /** Usually within each Field, seperated by ^ */
  Component = 2,
  /** Usually within each Component, seperated by & */
  Repetition = 3,
  /** The escape string used within the code. */
  Escape = 4,
  /** Usually within each Field, seperated by ~ */
  SubComponent = 5
}
/**
 * State of the Connected to the Server
 * @remarks These are the states that are used to track the connecting to the server side and also during the auto-reconnect phase.
 * @since 1.0.0
 */
declare enum ReadyState {
  /** The client is trying to connect to the server. */
  CONNECTING = 0,
  /** The client is connected to the server.  */
  CONNECTED = 1,
  /** The client is open, but not yet trying to connect to the server.  */
  OPEN = 2,
  /** The client is closing the connection by force or by timeout */
  CLOSING = 3,
  /** The client connection is closed.  */
  CLOSED = 4
}
//#endregion
//#region src/builder/modules/emptyNode.d.ts
/**
 * Empty Node
 * @since 1.0.0
 */
declare class EmptyNode implements HL7Node {
  get length(): number;
  get name(): string;
  get path(): string[];
  exists(_path: number | string): boolean;
  forEach(_callback: (value: HL7Node, index: number) => void): void;
  get(_path: number | string): HL7Node;
  isEmpty(): boolean;
  read(_path: string[]): HL7Node;
  set(_path: number | string, _value?: any): HL7Node;
  [Symbol.iterator](): Iterator<HL7Node>;
  toArray(): HL7Node[];
  toBoolean(): boolean;
  toDate(): Date;
  toFile(_name: string, _newLine?: boolean, _location?: string): void;
  toFloat(): number;
  toInteger(): number;
  toRaw(): string;
  toString(): string;
  write(_path: string[], _value: string): HL7Node;
}
//#endregion
//#region src/builder/modules/nodeBase.d.ts
/**
 * Node Base
 * @since 1.0.0
 */
declare class NodeBase extends EventEmitter implements HL7Node {
  static empty: EmptyNode;
  _name: string;
  get length(): number;
  get name(): string;
  get path(): string[];
  protected parent: NodeBase | null;
  /** @internal */
  protected get children(): HL7Node[];
  /** @internal */
  protected get delimiter(): string;
  /** @internal */
  protected get message(): Batch | Message | undefined;
  private _children;
  private readonly _delimiter;
  private _delimiterText;
  private _dirty;
  private _message;
  private _path;
  private _text;
  constructor(parent: NodeBase | null, text?: string, delimiter?: Delimiters | undefined);
  exists(path: number | string): boolean;
  forEach(callback: (value: HL7Node, index: number) => void): void;
  get(path: number | string): HL7Node;
  isEmpty(): boolean;
  read(_path: string[]): HL7Node;
  set(path: number | string, value?: any): HL7Node;
  [Symbol.iterator](): Iterator<HL7Node>;
  toArray(): HL7Node[];
  toBoolean(): boolean;
  toDate(): Date;
  toFile(_name: string, _newLine?: boolean, _location?: string): void;
  toFloat(): number;
  toInteger(): number;
  toRaw(): string;
  toString(): string;
  write(path: string[], value: string): HL7Node;
  /** @internal */
  protected addChild(text: string): HL7Node;
  /** @internal */
  protected createChild(_text: string, _index: number): HL7Node;
  /** @internal */
  protected ensure(path: number | string): HL7Node;
  /** @internal */
  protected pathCore(): string[];
  /** @internal */
  protected preparePath(path: string): string[];
  /** @internal */
  protected prepareValue(value: any): string;
  /** @internal */
  protected setChild(child: HL7Node, index: number): HL7Node;
  /** @internal */
  protected setDirty(): void;
  /** @internal */
  protected writeAtIndex(path: string[], value: string, index: number, emptyValue?: string): HL7Node;
  /** @internal */
  protected writeCore(_path: string[], _value: string): HL7Node;
  /** @internal */
  private _formatDate;
  /** @internal */
  private _formatDateTime;
  /** @internal */
  private _isSubPath;
  /** @internal */
  private _remainderOf;
}
//#endregion
//#region src/builder/modules/rootBase.d.ts
/**
 * Root Base
 * @since 1.0.0
 * @extends NodeBase
 */
declare class RootBase extends NodeBase {
  /** @internal */
  private static readonly _defaultDelimiters;
  /** @internal */
  private static readonly _defaultMatchEscape;
  /** @internal */
  private static readonly _defaultMatchUnescape;
  /** @internal */
  _opt: any;
  /** @internal */
  get delimiters(): string;
  /** @internal */
  private readonly _delimiters;
  /** @internal */
  private readonly _matchEscape;
  /** @internal */
  private readonly _matchUnescape;
  constructor(opt: ClientBuilderMessageOptions);
  /** @internal */
  protected static _makeMatchEscape(delimiters: string): RegExp;
  /** @internal */
  protected static _makeMatchUnescape(delimiters: string): RegExp;
  /** @internal */
  escape(text: string): string;
  /** @internal */
  unescape(text: string): string;
}
//#endregion
//#region src/builder/modules/segment.d.ts
/**
 * Segment
 * @since 1.0.0
 */
declare class Segment extends NodeBase {
  /** @internal */
  private readonly _segmentName;
  /** @internal */
  constructor(parent: NodeBase, text: string);
  /** @internal */
  read(path: string[]): HL7Node;
  /** @internal */
  set(path: number | string, value?: any): HL7Node;
  /** @internal */
  protected createChild(text: string, index: number): HL7Node;
  /** @internal */
  protected pathCore(): string[];
  /** @internal */
  protected writeCore(path: string[], value: string): HL7Node;
}
//#endregion
//#region src/builder/message.d.ts
/**
 * Message Class
 * @since 1.0.0
 */
declare class Message extends RootBase {
  /** @internal */
  _opt: ReturnType<typeof normalizedClientMessageParserOptions>;
  /**
   * Build the Message or Parse It
   * @since 1.0.0
   * @param props {@link ClientBuilderOptions}
   * @example
   * If you are processing a full message, do this:
   *
   * const message = new Message({text: "The HL7 Message Here"})
   * ... output cut ...
   *
   * If you are building out a message, do this:
   *
   * const message = new Message({messageHeader: { ... MSH Header Required Values Here ... }});
   *
   * which then you add segments with fields and values for your Hl7 message.
   *
   */
  constructor(properties?: ClientBuilderMessageOptions);
  /**
   * Add a new segment to a message.
   * @since 1.0.0
   * @remarks Creating a new segment adds an empty segment to the message.
   * It could be blank, or it could have values added into it.
   * @param path
   * @example
   *
   * const message = new Message({. the correct options here .})
   *
   * const segment = message.addSegment('PV1')
   * segment.set('PV1.1', 'Value Here');
   *
   * // When doing this, it overall adds it to the 'message' object
   * // when your output is the final result.
   *
   * const finalMessage = message.toString();
   *
   */
  addSegment(path: string): Segment;
  /**
   * Get HL7 Segment at Path
   * @since 1.0.0
   * @param path
   */
  get(path: number | string): HL7Node;
  getFirstSegment(): Segment;
  getLastSegment(): Segment;
  /**
   * Read a path of a message.
   * @remarks Could return {@link SegmentList}
   * @since 1.0.0
   * @param path
   */
  read(path: string[]): HL7Node;
  /**
   * Set HL7 Segment at Path with a Value
   * @since 1.0.0
   * @param path
   * @param value
   */
  set(path: number | string, value?: any): HL7Node;
  /**
   * Create File from a Message
   * @remarks Will procure a file of the saved MSH in the proper format
   * that includes a FHS and FTS segments.
   * @since 1.0.0
   * @param name File Name
   * @param newLine Provide a New Line
   * @param location Where to save the exported file
   * @param extension Custom extension of the file.
   * Default: hl7
   * @example
   * ```ts
   * const message = new Message({text: hl7_batch_string})
   * message.toFile('readTestMSH', true, 'temp/')
   * ```
   * You can set an `extension` parameter on Batch to set a custom extension if you don't want to be HL7.
   */
  toFile(name: string, newLine?: boolean, location?: string, extension?: string): string;
  /**
   * Total Segments
   * @remarks That match the name.
   * @since 4.0.0
   * @param name
   */
  totalSegment(name: string): number;
  /**
   * Create a new child of a message which is a segment.
   * @since
   * @see {@link Segment}
   * @param text Segment string. Must be 3 characters long.
   * @param _index Not used to create a segment.
   * @protected
   */
  protected createChild(text: string, _index: number): HL7Node;
  /**
   * Path Core
   * @since 1.0.0
   * @protected
   */
  protected pathCore(): string[];
  /**
   * Write Core of the Message
   * @since 1.0.0
   * @param path
   * @param value
   * @protected
   */
  protected writeCore(path: string[], value: string): HL7Node;
  /** @internal */
  private _getFirstSegment;
  /** @internal */
  private _getFirstSegmentIndex;
}
//#endregion
//#region src/client/inboundResponse.d.ts
/**
 * Inbound Request
 * @since 1.0.0
 */
declare class InboundResponse {
  /** @internal */
  private readonly _message;
  /**
   * Process the Inbound Response from the Server
   * @remarks This takes the string of the response from the server and makes it a message.
   * A response from a broker SHOULD always be a properly formated Hl7 message, we hope.
   * @since 1.0.0
   * @param data
   */
  constructor(data: string);
  /** '
   * Get Message
   * @since 1.0.0
   * @return Message
   */
  getMessage(): Message;
}
//#endregion
//#region src/hl7/types/acc.d.ts
interface HL7_ACC {
  /**
   * Accident Date/Time
   * @since 4.0.0
   */
  acc_1?: Date;
  /**
   * Accident Code
   * @since 4.0.0
   */
  acc_2?: string;
  /**
   * Accident Location
   * @since 4.0.0
   */
  acc_3?: string;
  /**
   * Accident Code
   * @since 4.0.0
   */
  accidentCode?: string;
  /**
   * Accident Location
   * @since 4.0.0
   */
  accidentLocation?: string;
  /**
   * Accident Date/Time
   * @since 4.0.0
   */
  timeStamp?: Date;
}
//#endregion
//#region src/hl7/2.1/acc.d.ts
type HL7_2_1_ACC = HL7_ACC;
//#endregion
//#region src/hl7/types/blg.d.ts
interface HL7_BLG {
  /**
   * @since 4.0.0
   */
  billingAccountId?: string;
  /**
   * @since 4.0.0
   */
  billingChargeType?: string;
  /**
   * @since 4.0.0
   */
  billingWhenToCharge?: string;
  /**
   * @since 4.0.0
   */
  blg_1?: string;
  /**
   * @since 4.0.0
   */
  blg_2?: string;
  /**
   * @since 4.0.0
   */
  blg_3?: string;
}
//#endregion
//#region src/hl7/2.1/blg.d.ts
type HL7_2_1_BLG = HL7_BLG;
//#endregion
//#region src/hl7/types/dg1.d.ts
interface HL7_DG1 {
  /** Diagnosis Id
   * @since 4.0.0 */
  dg1_1?: string;
  /** Diagnosis Grouper Review Code
   * @since 4.0.0 */
  dg1_10?: string;
  /** Diagnosis Outlier Type
   * @since 4.0.0 */
  dg1_11?: string;
  /** Diagnosis Outlier Days
   * @since 4.0.0 */
  dg1_12?: string;
  /** Diagnosis Outlier Cost
   * @since 4.0.0 */
  dg1_13?: string;
  /** Diagnosis Grouper Version and Type
   * @since 4.0.0 */
  dg1_14?: string;
  /** Diagnosis Coding Method
   * @since 4.0.0 */
  dg1_2: string;
  /** Diagnosis Code
   * @since 4.0.0 */
  dg1_3?: string;
  /** Diagnosis Description
   * @since 4.0.0 */
  dg1_4?: string;
  /** Diagnosis Timestamp
   * @default Uses current new Date()
   * @since 4.0.0 */
  dg1_5?: Date;
  /** Diagnosis Type
   * @since 4.0.0 */
  dg1_6?: string;
  /** Diagnosis Major Category
   * @since 4.0.0 */
  dg1_7?: string;
  /** Diagnosis Related Group
   * @since 4.0.0 */
  dg1_8?: string;
  /** Diagnosis Approval Indicator
   * @since 4.0.0 */
  dg1_9?: string;
  /** Diagnosis Approval Indicator
   * @since 4.0.0 */
  diagnosisApprovalIndicator?: string;
  /** Diagnosis Code
   * @since 4.0.0 */
  diagnosisCode?: string;
  /** Diagnosis Coding Method
   * @since 4.0.0 */
  diagnosisCodingMethod?: string;
  /** Diagnosis Description
   * @since 4.0.0 */
  diagnosisDescription?: string;
  /** Diagnosis Grouper Review Code
   * @since 4.0.0 */
  diagnosisGrouperReviewCode?: string;
  /** Diagnosis Grouper Version and Type
   * @since 4.0.0 */
  diagnosisGrouperVersionAndType?: string;
  /** Diagnosis Id
   * @since 4.0.0 */
  diagnosisId?: string;
  /** Diagnosis Major Category
   * @since 4.0.0 */
  diagnosisMajorCategory?: string;
  /** Diagnosis Outlier Cost
   * @since 4.0.0 */
  diagnosisOutlierCost?: string;
  /** Diagnosis Outlier Days
   * @since 4.0.0 */
  diagnosisOutlierDays?: string;
  /** Diagnosis Outlier Type
   * @since 4.0.0 */
  diagnosisOutlierType?: string;
  /** Diagnosis Related Group
   * @since 4.0.0 */
  diagnosisRelatedGroup?: string;
  /** Diagnosis Type
   * @since 4.0.0 */
  diagnosisType?: string;
  /** Diagnosis Timestamp
   * @default Uses current new Date()
   * @since 4.0.0 */
  timeStamp?: Date;
}
//#endregion
//#region src/hl7/2.1/dg1.d.ts
type HL7_2_1_DG1 = HL7_DG1;
//#endregion
//#region src/hl7/types/dsc.d.ts
interface HL7_DSC {
  /**
   * @since 4.0.0
   */
  continuationPointer?: string;
  /**
   * @since 4.0.0
   */
  dsc_1?: string;
}
//#endregion
//#region src/hl7/2.1/dsc.d.ts
type HL7_2_1_DSC = HL7_DSC;
//#endregion
//#region src/hl7/types/err.d.ts
interface HL7_ERR {
  err_1?: string;
  errorIdAndLocation?: string;
}
//#endregion
//#region src/hl7/2.1/err.d.ts
type HL7_2_1_ERR = HL7_ERR;
//#endregion
//#region src/hl7/tables/0003.d.ts
declare const TABLE_0003: string[];
//#endregion
//#region src/hl7/tables/0062.d.ts
declare const TABLE_0062: string[];
//#endregion
//#region src/hl7/types/evn.d.ts
interface HL7_EVN {
  evn_1?: Table0003Value;
  evn_2?: Date;
  evn_3?: Date;
  evn_4?: Table0062Value;
}
type Table0003Value = (typeof TABLE_0003)[number];
type Table0062Value = (typeof TABLE_0062)[number];
//#endregion
//#region src/hl7/2.1/evn.d.ts
type HL7_2_1_EVN = HL7_EVN;
//#endregion
//#region src/hl7/types/ft1.d.ts
/** HL7 FT1 - Financial Transaction */
interface HL7_FT1 {
  /** FT1.1 - Set ID */
  ft1_1?: number | string;
  /** FT1.10 - Transaction Quantity */
  ft1_10?: string;
  /** FT1.11 - Transaction Amount - Extended */
  ft1_11?: string;
  /** FT1.12 - Transaction Amount - Unit */
  ft1_12?: string;
  /** FT1.13 - Department Code */
  ft1_13?: string;
  /** FT1.14 - Insurance Plan ID */
  ft1_14?: string;
  /** FT1.15 - Insurance Amount */
  ft1_15?: string;
  /** FT1.16 - Assigned Patient Location */
  ft1_16?: string;
  /** FT1.17 - Fee Schedule */
  ft1_17?: string;
  /** FT1.18 - Patient Type */
  ft1_18?: string;
  /** FT1.19 - Diagnosis Code */
  ft1_19?: string;
  /** FT1.2 - Transaction ID */
  ft1_2?: string;
  /** FT1.20 - Performed By Code */
  ft1_20?: string;
  /** FT1.21 - Ordered By Code */
  ft1_21?: string;
  /** FT1.22 - Unit Cost */
  ft1_22?: string;
  /** FT1.3 - Transaction Batch ID */
  ft1_3?: string;
  /** FT1.4 - Transaction Date */
  ft1_4: Date | string;
  /** FT1.5 - Transaction Posting Date */
  ft1_5?: Date | string;
  /** FT1.6 - Transaction Type */
  ft1_6: string;
  /** FT1.7 - Transaction Code */
  ft1_7: string;
  /** FT1.8 - Transaction Description */
  ft1_8?: string;
  /** FT1.9 - Transaction Description - Alt */
  ft1_9?: string;
  transactionCode?: string;
  transactionType?: string;
}
//#endregion
//#region src/hl7/2.1/ft1.d.ts
type HL7_2_1_FT1 = HL7_FT1;
//#endregion
//#region src/hl7/types/gt1.d.ts
/** HL7 GT1 - Guarantor */
interface HL7_GT1 {
  /** GT1.1 - Set ID */
  gt1_1?: number | string;
  /** GT1.10 - Guarantor Type */
  gt1_10?: string;
  /** GT1.11 - Guarantor Relationship */
  gt1_11?: string;
  /** GT1.12 - Guarantor SSN */
  gt1_12?: string;
  /** GT1.13 - Guarantor Date - Begin */
  gt1_13?: Date | string;
  /** GT1.14 - Guarantor Date - End */
  gt1_14?: Date | string;
  /** GT1.15 - Guarantor Priority */
  gt1_15?: string;
  /** GT1.16 - Guarantor Employer Name */
  gt1_16?: string;
  /** GT1.17 - Guarantor Employer Address */
  gt1_17?: string;
  /** GT1.18 - Guarantor Employment Status */
  gt1_18?: string;
  /** GT1.19 - Guarantor Organization */
  gt1_19?: string;
  /** GT1.2 - Guarantor ID */
  gt1_2?: string;
  /** GT1.20 - Guarantor Billing Hold Flag */
  gt1_20?: string;
  /** GT1.3 - Guarantor Name */
  gt1_3?: string;
  /** GT1.4 - Guarantor Spouse Name */
  gt1_4?: string;
  /** GT1.5 - Guarantor Address */
  gt1_5?: string;
  /** GT1.6 - Guarantor Phone Number - Home */
  gt1_6?: string;
  /** GT1.7 - Guarantor Phone Number - Business */
  gt1_7?: string;
  /** GT1.8 - Guarantor Date/Time of Birth */
  gt1_8?: Date | string;
  /** GT1.9 - Guarantor Sex */
  gt1_9?: string;
  guarantorName?: string;
}
//#endregion
//#region src/hl7/2.1/gt1.d.ts
type HL7_2_1_GT1 = HL7_GT1;
//#endregion
//#region src/hl7/tables/0001.d.ts
declare const TABLE_0001: string[];
//#endregion
//#region src/hl7/types/in1.d.ts
/** HL7 IN1 - Insurance */
interface HL7_IN1 {
  /** IN1.1 - Set ID */
  in1_1: number | string;
  /** IN1.10 - Insured's Group Employee ID */
  in1_10?: string;
  /** IN1.11 - Insured's Group Employee Name */
  in1_11?: string;
  /** IN1.12 - Plan Effective Date */
  in1_12?: Date | string;
  /** IN1.13 - Plan Expiration Date */
  in1_13?: Date | string;
  /** IN1.14 - Authorization Information */
  in1_14?: string;
  /** IN1.15 - Plan Type */
  in1_15?: string;
  /** IN1.16 - Name Of Insured */
  in1_16?: string;
  /** IN1.17 - Insured's Relationship To Patient */
  in1_17?: string;
  /** IN1.18 - Insured's Date Of Birth */
  in1_18?: Date | string;
  /** IN1.19 - Insured's Address */
  in1_19?: string;
  /** IN1.2 - Insurance Plan ID */
  in1_2: string;
  /** IN1.20 - Assignment Of Benefits */
  in1_20?: string;
  /** IN1.21 - Coordination Of Benefits */
  in1_21?: string;
  /** IN1.22 - Coordination Of Benefits - Priority */
  in1_22?: string;
  /** IN1.23 - Notice Of Admission Flag */
  in1_23?: string;
  /** IN1.24 - Notice Of Admission Date */
  in1_24?: Date | string;
  /** IN1.25 - Report Of Eligibility Flag */
  in1_25?: string;
  /** IN1.26 - Report Of Eligibility Date */
  in1_26?: Date | string;
  /** IN1.27 - Release Information Code */
  in1_27?: string;
  /** IN1.28 - Pre-Admit Certification */
  in1_28?: string;
  /** IN1.29 - Verification Date/Time */
  in1_29?: Date | string;
  /** IN1.3 - Insurance Company ID */
  in1_3: string;
  /** IN1.30 - Verification By */
  in1_30?: string;
  /** IN1.31 - Type Of Agreement Code */
  in1_31?: string;
  /** IN1.32 - Billing Status */
  in1_32?: string;
  /** IN1.33 - Lifetime Reserve Days */
  in1_33?: string;
  /** IN1.34 - Delay Before LR Day */
  in1_34?: string;
  /** IN1.35 - Company Plan Code */
  in1_35?: string;
  /** IN1.36 - Policy Number */
  in1_36?: string;
  /** IN1.37 - Policy Deductible */
  in1_37?: string;
  /** IN1.38 - Policy Limit - Amount */
  in1_38?: string;
  /** IN1.39 - Policy Limit - Days */
  in1_39?: string;
  /** IN1.4 - Insurance Company Name */
  in1_4?: string;
  /** IN1.40 - Room Rate - Semi-Private */
  in1_40?: string;
  /** IN1.41 - Room Rate - Private */
  in1_41?: string;
  /** IN1.42 - Insured's Employment Status */
  in1_42?: string;
  /** IN1.43 - Insured's Sex */
  in1_43?: Table0001Value$2;
  /** IN1.44 - Insured's Employer Address */
  in1_44?: string;
  /** IN1.5 - Insurance Company Address */
  in1_5?: string;
  /** IN1.6 - Insurance Company Contact Person */
  in1_6?: string;
  /** IN1.7 - Insurance Company Phone Number */
  in1_7?: string;
  /** IN1.8 - Group Number */
  in1_8?: string;
  /** IN1.9 - Group Name */
  in1_9?: string;
  insuranceCompanyId?: string;
  insurancePlanId?: string;
  setId?: number | string;
}
type Table0001Value$2 = (typeof TABLE_0001)[number];
//#endregion
//#region src/hl7/2.1/in1.d.ts
type HL7_2_1_IN1 = HL7_IN1;
//#endregion
//#region src/hl7/types/mrg.d.ts
/** HL7 MRG - Merge Patient Information */
interface HL7_MRG {
  /** MRG.1 - Prior Patient ID - Internal */
  mrg_1: string;
  /** MRG.2 - Prior Alternate Patient ID */
  mrg_2?: string;
  /** MRG.3 - Prior Patient Account Number */
  mrg_3?: string;
  priorPatientIdInternal?: string;
}
//#endregion
//#region src/hl7/2.1/mrg.d.ts
type HL7_2_1_MRG = HL7_MRG;
//#endregion
//#region src/hl7/types/msa.d.ts
/** HL7 MSA - Message Acknowledgment */
interface HL7_MSA {
  ackCode?: string;
  messageControlId?: string;
  /** MSA.1 - Acknowledgment Code */
  msa_1: string;
  /** MSA.2 - Message Control ID */
  msa_2: string;
  /** MSA.3 - Text Message */
  msa_3?: string;
  /** MSA.4 - Expected Sequence Number */
  msa_4?: string;
  /** MSA.5 - Delayed Acknowledgment Type */
  msa_5?: string;
  textMessage?: string;
}
//#endregion
//#region src/hl7/2.1/msa.d.ts
type HL7_2_1_MSA = HL7_MSA;
//#endregion
//#region src/hl7/types/msh.d.ts
interface HL7_MSH {
  /** Processing ID
   * @since 1.0.0 */
  msh_11: "P" | "T";
  /** Sending Application
   * @since 4.0.0 */
  msh_3?: string;
  /** Sending Facility
   * @since 4.0.0 */
  msh_4?: string;
  /** Receiving Application
   * @since 4.0.0 */
  msh_5?: string;
  /** Receiving Facility
   * @since 4.0.0 */
  msh_6?: string;
  /** Date of Message
   * @remarks Equivalent to 'timeStamp'
   * @defailt Current Date/Time
   * @since 4.0.0 */
  msh_7?: Date;
  /** Security
   * @remarks Optional, String Data
   * @since 4.0.0 */
  msh_8?: string;
  /** Processing ID
   * @since 4.0.0 */
  processingId: "P" | "T";
  /** Receiving Application
   * @since 4.0.0 */
  receivingApplication?: string;
  /** Receiving Facility
   * @since 4.0.0 */
  receivingFacility?: string;
  /** Security
   * @remarks Optional, String Data
   * @since 4.0.0 */
  security?: string;
  /** Sending Application
   * @since 4.0.0 */
  sendingApplication?: string;
  /** Sending Application
   * @since 4.0.0 */
  sendingFacility?: string;
  /** Date of Message
   * @remarks Equivalent to MSH.7
   * @defailt Current Date/Time
   * @since 4.0.0 */
  timeStamp?: Date;
}
//#endregion
//#region src/hl7/2.1/msh.d.ts
/**
 * HL7 2.1 MSH Specification
 * @remarks
 * @since 1.0.0
 * @example
 * To make it easier on having to fill this out each time, you may do this in your code:
 * ```
 * // Make this a constant in your application.
 * const MSH_HEADER: HL7_2_1_MSH = {
 *   msh_9: "ADT",
 *   msh_11_1: "D",
 * }
 * ```
 * MSH.7 (Date Time) and MSH.12 (HL7 Spec) are filled in automatically at the time of creation.
 * and when you create your Message class:
 * ```
 * const message = new Hl7_2_1({ ...MSH_HEADER, msh_10: 'unique id' })
 * ```
 * so this way your code is much neater.
 *
 */
interface HL7_2_1_MSH extends HL7_MSH {
  /** Message Code
   * @example ADT
   * @since 1.0.0 */
  messageCode: string;
  /** Message Control ID
   * @remarks This ID is unique to the message being sent
   * so the client can track
   * to see if they get a response back from the server that this particular message was successful.
   * Max 20 characters.
   * @since 1.0.0
   * @default Random 20 Character String {@link randomString} if this is set to nothing or not included. */
  messageControlId?: string;
  /** Message Control ID
   * @remarks This ID is unique to the message being sent
   * so the client can track
   * to see if they get a response back from the server that this particular message was successful.
   * Max 20 characters.
   * @since 1.0.0
   * @default Random 20 Character String {@link randomString} if this is set to nothing or not included. */
  msh_10?: string;
  /** Message Code
   * @example ADT
   * @since 1.0.0 */
  msh_9: string;
}
//#endregion
//#region src/hl7/tables/0116.d.ts
declare const TABLE_0116: string[];
//#endregion
//#region src/hl7/types/npu.d.ts
/** HL7 NPU - Bed Status Update */
interface HL7_NPU {
  bedLocation?: string;
  bedStatus?: Table0116Value$1;
  /** NPU.1 - Bed Location */
  npu_1: string;
  /** NPU.2 - Bed Status */
  npu_2?: Table0116Value$1;
}
type Table0116Value$1 = (typeof TABLE_0116)[number];
//#endregion
//#region src/hl7/2.1/npu.d.ts
type HL7_2_1_NPU = HL7_NPU;
//#endregion
//#region src/hl7/types/nsc.d.ts
/** HL7 NSC - Status Change */
interface HL7_NSC {
  networkChangeType?: string;
  /** NSC.1 - Network Change Type */
  nsc_1: string;
  /** NSC.2 - Current CPU */
  nsc_2?: string;
  /** NSC.3 - Current Fileserver */
  nsc_3?: string;
  /** NSC.4 - Current Application */
  nsc_4?: string;
  /** NSC.5 - Current Facility */
  nsc_5?: string;
  /** NSC.6 - New CPU */
  nsc_6?: string;
  /** NSC.7 - New Fileserver */
  nsc_7?: string;
  /** NSC.8 - New Application */
  nsc_8?: string;
  /** NSC.9 - New Facility */
  nsc_9?: string;
}
//#endregion
//#region src/hl7/2.1/nsc.d.ts
type HL7_2_1_NSC = HL7_NSC;
//#endregion
//#region src/hl7/types/nte.d.ts
/** HL7 NTE - Notes and Comments */
interface HL7_NTE {
  comment?: string;
  /** NTE.1 - Set ID */
  nte_1?: number | string;
  /** NTE.2 - Source of Comment */
  nte_2?: string;
  /** NTE.3 - Comment */
  nte_3?: string;
  sourceOfComment?: string;
}
//#endregion
//#region src/hl7/2.1/nte.d.ts
type HL7_2_1_NTE = HL7_NTE;
//#endregion
//#region src/hl7/types/pr1.d.ts
/** HL7 PR1 - Procedures */
interface HL7_PR1 {
  anesthesiaCode?: string;
  anesthesiaMinutes?: number | string;
  anesthesiologist?: string;
  /** PR1.1 - Set ID */
  pr1_1: number | string;
  /** PR1.10 - Anesthesia Minutes */
  pr1_10?: number | string;
  /** PR1.11 - Surgeon */
  pr1_11?: string;
  /** PR1.2 - Procedure Coding Method */
  pr1_2: string;
  /** PR1.3 - Procedure Code */
  pr1_3: string;
  /** PR1.4 - Procedure Description */
  pr1_4?: string;
  /** PR1.5 - Procedure Date/Time */
  pr1_5: Date | string;
  /** PR1.6 - Procedure Type */
  pr1_6?: string;
  /** PR1.7 - Procedure Minutes */
  pr1_7?: number | string;
  /** PR1.8 - Anesthesiologist */
  pr1_8?: string;
  /** PR1.9 - Anesthesia Code */
  pr1_9?: string;
  procedureCode?: string;
  procedureCodingMethod?: string;
  procedureDateTime?: Date | string;
  procedureDescription?: string;
  procedureMinutes?: number | string;
  procedureType?: string;
  surgeon?: string;
}
//#endregion
//#region src/hl7/2.1/pr1.d.ts
type HL7_2_1_PR1 = HL7_PR1;
//#endregion
//#region src/hl7/types/qrd.d.ts
/** HL7 QRD - Original-Style Query Definition */
interface HL7_QRD {
  deferredResponseType?: string;
  /** QRD.1 - Query Date/Time */
  qrd_1: Date | string;
  /** QRD.10 - What Department Data Code */
  qrd_10?: string;
  /** QRD.2 - Query Format Code (R=Record-oriented, T=Text, D=Display) */
  qrd_2: string;
  /** QRD.3 - Query Priority (D=Deferred, I=Immediate) */
  qrd_3: string;
  /** QRD.4 - Query ID */
  qrd_4: string;
  /** QRD.5 - Deferred Response Type */
  qrd_5?: string;
  /** QRD.6 - Deferred Response Date/Time */
  qrd_6?: Date | string;
  /** QRD.7 - Quantity Limited Request */
  qrd_7: string;
  /** QRD.8 - Who Subject Filter */
  qrd_8: string;
  /** QRD.9 - What Subject Filter */
  qrd_9: string;
  quantityLimitedRequest?: string;
  queryDateTime?: Date | string;
  queryFormatCode?: string;
  queryId?: string;
  queryPriority?: string;
  whatDepartmentDataCode?: string;
  whatSubjectFilter?: string;
  whoSubjectFilter?: string;
}
//#endregion
//#region src/hl7/2.1/qrd.d.ts
type HL7_2_1_QRD = HL7_QRD;
//#endregion
//#region src/hl7/types/qrf.d.ts
/** HL7 QRF - Original Style Query Filter */
interface HL7_QRF {
  otherQrySubjectFilter?: string;
  /** QRF.1 - Where Subject Filter */
  qrf_1: string;
  /** QRF.2 - When Data Start Date/Time */
  qrf_2?: Date | string;
  /** QRF.3 - When Data End Date/Time */
  qrf_3?: Date | string;
  /** QRF.4 - What User Qualifier */
  qrf_4?: string;
  /** QRF.5 - Other QRY Subject Filter */
  qrf_5?: string;
  whatUserQualifier?: string;
  whenDataEndDateTime?: Date | string;
  whenDataStartDateTime?: Date | string;
  whereSubjectFilter?: string;
}
//#endregion
//#region src/hl7/2.1/qrf.d.ts
type HL7_2_1_QRF = HL7_QRF;
//#endregion
//#region src/hl7/types/rx1.d.ts
/** HL7 RX1 - Pharmacy/Treatment Order (HL7 2.1) */
interface HL7_RX1 {
  allowSubstitutions?: string;
  deliverToLocation?: string;
  giveAmountMaximum?: number | string;
  giveAmountMinimum?: number | string;
  giveCode?: string;
  giveDosageForm?: string;
  givePer?: string;
  giveRateAmount?: number | string;
  giveRateUnits?: string;
  giveUnits?: string;
  pharmacistSpecialDispensingInstructions?: string;
  providersAdministrationInstructions?: string;
  providersPharmacyInstructions?: string;
  requestedDosageForm?: string;
  requestedGiveAmountMaximum?: number | string;
  requestedGiveAmountMinimum?: number | string;
  requestedGiveCode?: string;
  requestedGiveUnits?: string;
  /** RX1.1 - Unused */
  rx1_1?: string;
  /** RX1.10 - Allow Substitutions */
  rx1_10?: string;
  /** RX1.11 - Requested Give Code */
  rx1_11?: string;
  /** RX1.12 - Requested Give Amount - Minimum */
  rx1_12?: number | string;
  /** RX1.13 - Requested Give Amount - Maximum */
  rx1_13?: number | string;
  /** RX1.14 - Requested Give Units */
  rx1_14?: string;
  /** RX1.15 - Requested Dosage Form */
  rx1_15?: string;
  /** RX1.16 - Pharmacist Special Dispensing Instructions */
  rx1_16?: string;
  /** RX1.17 - Give Per */
  rx1_17?: string;
  /** RX1.18 - Give Rate Amount */
  rx1_18?: number | string;
  /** RX1.19 - Give Rate Units */
  rx1_19?: string;
  /** RX1.2 - Give Code */
  rx1_2: string;
  /** RX1.20 - Requested Give Rate Amount */
  rx1_20?: number | string;
  /** RX1.21 - Requested Give Rate Units */
  rx1_21?: string;
  /** RX1.22 - Total Daily Dose */
  rx1_22?: string;
  /** RX1.3 - Give Amount - Minimum */
  rx1_3: number | string;
  /** RX1.4 - Give Amount - Maximum */
  rx1_4?: number | string;
  /** RX1.5 - Give Units */
  rx1_5?: string;
  /** RX1.6 - Give Dosage Form */
  rx1_6?: string;
  /** RX1.7 - Provider's Pharmacy Instructions */
  rx1_7?: string;
  /** RX1.8 - Provider's Administration Instructions */
  rx1_8?: string;
  /** RX1.9 - Deliver-to Location */
  rx1_9?: string;
  totalDailyDose?: string;
}
//#endregion
//#region src/hl7/2.1/rx1.d.ts
type HL7_2_1_RX1 = HL7_RX1;
//#endregion
//#region src/hl7/types/ub1.d.ts
/** HL7 UB1 - UB82 Data */
interface HL7_UB1 {
  bloodDeductible?: number | string;
  bloodFurnishedPints?: number | string;
  bloodNotReplacedPints?: number | string;
  bloodReplacedPints?: number | string;
  coInsuranceDays?: number | string;
  conditionCode?: string;
  coveredDays?: number | string;
  nonCoveredDays?: number | string;
  numberOfGraceDays?: number | string;
  occurrence?: string;
  occurrenceSpan?: string;
  specialProgramIndicator?: string;
  /** UB1.1 - Set ID */
  ub1_1?: number | string;
  /** UB1.10 - Value Amount and Code */
  ub1_10?: string;
  /** UB1.11 - Number of Grace Days */
  ub1_11?: number | string;
  /** UB1.12 - Special Program Indicator */
  ub1_12?: string;
  /** UB1.13 - PSRO/UR Approval Indicator */
  ub1_13?: string;
  /** UB1.14 - PSRO/UR Approved Stay - From */
  ub1_14?: Date | string;
  /** UB1.15 - PSRO/UR Approved Stay - To */
  ub1_15?: Date | string;
  /** UB1.16 - Occurrence */
  ub1_16?: string;
  /** UB1.17 - Occurrence Span */
  ub1_17?: string;
  /** UB1.18 - Occurrence Span Start Date */
  ub1_18?: Date | string;
  /** UB1.19 - Occurrence Span Stop Date */
  ub1_19?: Date | string;
  /** UB1.2 - Blood Deductible */
  ub1_2?: number | string;
  /** UB1.20 - UB-82 Locator 2 */
  ub1_20?: string;
  /** UB1.21 - UB-82 Locator 9 */
  ub1_21?: string;
  /** UB1.22 - UB-82 Locator 27 */
  ub1_22?: string;
  /** UB1.23 - UB-82 Locator 45 */
  ub1_23?: string;
  /** UB1.3 - Blood Furnished Pints */
  ub1_3?: number | string;
  /** UB1.4 - Blood Replaced Pints */
  ub1_4?: number | string;
  /** UB1.5 - Blood Not Replaced Pints */
  ub1_5?: number | string;
  /** UB1.6 - Co-Insurance Days */
  ub1_6?: number | string;
  /** UB1.7 - Condition Code */
  ub1_7?: string;
  /** UB1.8 - Covered Days */
  ub1_8?: number | string;
  /** UB1.9 - Non-Covered Days */
  ub1_9?: number | string;
  valueAmountCode?: string;
}
//#endregion
//#region src/hl7/2.1/ub1.d.ts
type HL7_2_1_UB1 = HL7_UB1;
//#endregion
//#region src/hl7/types/urd.d.ts
/** HL7 URD - Results/Update Definition */
interface HL7_URD {
  reportPriority?: string;
  ruDateTime?: Date | string;
  ruWhatSubjectDefinition?: string;
  ruWhoSubjectDefinition?: string;
  /** URD.1 - R/U Date/Time */
  urd_1?: Date | string;
  /** URD.2 - Report Priority */
  urd_2?: string;
  /** URD.3 - R/U Who Subject Definition */
  urd_3: string;
  /** URD.4 - R/U What Subject Definition */
  urd_4?: string;
}
//#endregion
//#region src/hl7/2.1/urd.d.ts
type HL7_2_1_URD = HL7_URD;
//#endregion
//#region src/hl7/types/urs.d.ts
/** HL7 URS - Unsolicited Selection */
interface HL7_URS {
  ruWhatUserQualifier?: string;
  ruWhereSubjectDefinition?: string;
  /** URS.1 - R/U Where Subject Definition */
  urs_1: string;
  /** URS.2 - R/U When Data Start Date/Time */
  urs_2?: Date | string;
  /** URS.3 - R/U When Data End Date/Time */
  urs_3?: Date | string;
  /** URS.4 - R/U What User Qualifier */
  urs_4?: string;
  /** URS.5 - R/U Other Results Subject Definition */
  urs_5?: string;
  /** URS.6 - R/U Which Date/Time Qualifier */
  urs_6?: string;
}
//#endregion
//#region src/hl7/2.1/urs.d.ts
type HL7_2_1_URS = HL7_URS;
//#endregion
//#region src/hl7/tables/0127.d.ts
declare const TABLE_0127: string[];
//#endregion
//#region src/hl7/tables/0128.d.ts
declare const TABLE_0128: string[];
//#endregion
//#region src/hl7/tables/0136.d.ts
declare const TABLE_0136: string[];
//#endregion
//#region src/hl7/2.2/al1.d.ts
/** HL7 2.2 AL1 - Patient Allergy Information */
interface HL7_2_2_AL1 {
  /** AL1.1 - Set ID (required) */
  al1_1: number | string;
  /** AL1.2 - Allergy Type */
  al1_2?: Table0127Value;
  /** AL1.3 - Allergy Code/Mnemonic/Description (required) */
  al1_3: string;
  /** AL1.4 - Allergy Severity */
  al1_4?: Table0128Value;
  /** AL1.5 - Allergy Reaction */
  al1_5?: string;
  /** AL1.6 - Identification Date */
  al1_6?: Date | string;
}
type Table0127Value = (typeof TABLE_0127)[number];
type Table0128Value = (typeof TABLE_0128)[number];
//#endregion
//#region src/hl7/2.2/mfe.d.ts
/** HL7 2.2 MFE - Master File Entry */
interface HL7_2_2_MFE {
  /** MFE.1 - Record-Level Event Code (required) */
  mfe_1: "MAC" | "MAD" | "MDC" | "MDL" | "MUP";
  /** MFE.2 - MFN Control ID (max 20) */
  mfe_2?: string;
  /** MFE.3 - Effective Date/Time */
  mfe_3?: Date | string;
  /** MFE.4 - Primary Key Value - MFE (required, max 200) */
  mfe_4: string;
}
//#endregion
//#region src/hl7/2.2/mfi.d.ts
/** HL7 2.2 MFI - Master File Identification */
interface HL7_2_2_MFI {
  /** MFI.1 - Master File Identifier (required, max 60) */
  mfi_1: string;
  /** MFI.2 - Master File Application Identifier (max 60) */
  mfi_2?: string;
  /** MFI.3 - File-Level Event Code (required) */
  mfi_3: "REP" | "UPD";
  /** MFI.4 - Entered Date/Time */
  mfi_4?: Date | string;
  /** MFI.5 - Effective Date/Time */
  mfi_5?: Date | string;
  /** MFI.6 - Response Level Code (required) */
  mfi_6: "AL" | "ER" | "NE" | "NR";
}
//#endregion
//#region src/hl7/2.2/ods.d.ts
/** HL7 2.2 ODS - Dietary Orders, Supplements, and Preferences */
interface HL7_2_2_ODS {
  /** ODS.1 - Type (required): D=Diet, S=Supplement, P=Preference */
  ods_1: "D" | "P" | "S";
  /** ODS.2 - Service Period */
  ods_2?: string;
  /** ODS.3 - Diet, Supplement, or Preference Code (required) */
  ods_3: string;
  /** ODS.4 - Text Instruction */
  ods_4?: string;
}
//#endregion
//#region src/hl7/2.2/odt.d.ts
/** HL7 2.2 ODT - Diet Tray Instructions */
interface HL7_2_2_ODT {
  /** ODT.1 - Tray Type (required) */
  odt_1: string;
  /** ODT.2 - Service Period */
  odt_2?: string;
  /** ODT.3 - Text Instruction */
  odt_3?: string;
}
//#endregion
//#region src/hl7/tables/0004.d.ts
declare const TABLE_0004: string[];
//#endregion
//#region src/hl7/tables/0007.d.ts
declare const TABLE_0007: string[];
//#endregion
//#region src/hl7/types/pv1.d.ts
/** HL7 PV1 - Patient Visit */
interface HL7_PV1 {
  admissionType?: Table0007Value;
  admitDateTime?: Date | string;
  admitSource?: string;
  admittingDoctor?: string;
  ambulatoryStatus?: string;
  assignedPatientLocation?: string;
  attendingDoctor?: string;
  bedStatus?: Table0116Value;
  consultingDoctor?: string;
  dischargeDisposition?: string;
  financialClass?: string;
  hospitalService?: string;
  patientClass?: Table0004Value;
  patientType?: string;
  preadmitNumber?: string;
  priorPatientLocation?: string;
  /** PV1.1 - Set ID */
  pv1_1?: number | string;
  /** PV1.10 - Hospital Service */
  pv1_10?: string;
  /** PV1.11 - Temporary Location */
  pv1_11?: string;
  /** PV1.12 - Preadmit Test Indicator */
  pv1_12?: string;
  /** PV1.13 - Readmission Indicator */
  pv1_13?: string;
  /** PV1.14 - Admit Source */
  pv1_14?: string;
  /** PV1.15 - Ambulatory Status */
  pv1_15?: string;
  /** PV1.16 - VIP Indicator */
  pv1_16?: string;
  /** PV1.17 - Admitting Doctor */
  pv1_17?: string;
  /** PV1.18 - Patient Type */
  pv1_18?: string;
  /** PV1.19 - Visit Number */
  pv1_19?: number | string;
  /** PV1.2 - Patient Class */
  pv1_2: Table0004Value;
  /** PV1.20 - Financial Class */
  pv1_20?: string;
  /** PV1.21 - Charge Price Indicator */
  pv1_21?: string;
  /** PV1.22 - Courtesy Code */
  pv1_22?: string;
  /** PV1.23 - Credit Rating */
  pv1_23?: string;
  /** PV1.24 - Contract Code */
  pv1_24?: string;
  /** PV1.25 - Contract Effective Date */
  pv1_25?: Date | string;
  /** PV1.26 - Contract Amount */
  pv1_26?: number | string;
  /** PV1.27 - Contract Period */
  pv1_27?: number | string;
  /** PV1.28 - Interest Code */
  pv1_28?: string;
  /** PV1.29 - Transfer to Bad Debt Code */
  pv1_29?: string;
  /** PV1.3 - Assigned Patient Location */
  pv1_3?: string;
  /** PV1.30 - Transfer to Bad Debt Date */
  pv1_30?: Date | string;
  /** PV1.31 - Bad Debt Agency Code */
  pv1_31?: string;
  /** PV1.32 - Bad Debt Transfer Amount */
  pv1_32?: number | string;
  /** PV1.33 - Bad Debt Recovery Amount */
  pv1_33?: number | string;
  /** PV1.34 - Delete Account Indicator */
  pv1_34?: string;
  /** PV1.35 - Delete Account Date */
  pv1_35?: Date | string;
  /** PV1.36 - Discharge Disposition */
  pv1_36?: string;
  /** PV1.37 - Discharged to Location */
  pv1_37?: string;
  /** PV1.38 - Diet Type */
  pv1_38?: string;
  /** PV1.39 - Servicing Facility */
  pv1_39?: string;
  /** PV1.4 - Admission Type */
  pv1_4?: Table0007Value;
  /** PV1.40 - Bed Status */
  pv1_40?: Table0116Value;
  /** PV1.41 - Account Status */
  pv1_41?: string;
  /** PV1.42 - Pending Location */
  pv1_42?: string;
  /** PV1.43 - Prior Temporary Location */
  pv1_43?: string;
  /** PV1.44 - Admit Date/Time */
  pv1_44?: Date | string;
  /** PV1.5 - Preadmit Number */
  pv1_5?: string;
  /** PV1.6 - Prior Patient Location */
  pv1_6?: string;
  /** PV1.7 - Attending Doctor */
  pv1_7?: string;
  /** PV1.8 - Referring Doctor */
  pv1_8?: string;
  /** PV1.9 - Consulting Doctor */
  pv1_9?: string;
  referringDoctor?: string;
  temporaryLocation?: string;
  vipIndicator?: string;
  visitNumber?: number | string;
}
type Table0004Value = (typeof TABLE_0004)[number];
type Table0007Value = (typeof TABLE_0007)[number];
type Table0116Value = (typeof TABLE_0116)[number];
//#endregion
//#region src/hl7/2.1/pv1.d.ts
type HL7_2_1_PV1 = HL7_PV1;
//#endregion
//#region src/hl7/tables/0326.d.ts
declare const TABLE_0326: string[];
//#endregion
//#region src/hl7/2.2/pv1.d.ts
/** HL7 2.2 PV1 - extends 2.1 with fields 45-52 */
interface HL7_2_2_PV1 extends HL7_2_1_PV1 {
  /** PV1.45 - Discharge Date/Time */
  pv1_45?: Date | string;
  /** PV1.46 - Current Patient Balance */
  pv1_46?: string;
  /** PV1.47 - Total Charges */
  pv1_47?: string;
  /** PV1.48 - Total Adjustments */
  pv1_48?: string;
  /** PV1.49 - Total Payments */
  pv1_49?: string;
  /** PV1.50 - Alternate Visit ID (max 15) */
  pv1_50?: string;
  /** PV1.51 - Visit Indicator */
  pv1_51?: (typeof TABLE_0326)[number];
  /** PV1.52 - Other Healthcare Provider */
  pv1_52?: string;
}
//#endregion
//#region src/hl7/2.2/rxa.d.ts
/** HL7 2.2 RXA - Pharmacy/Treatment Administration */
interface HL7_2_2_RXA {
  /** RXA.1 - Give Sub-ID Counter (required) */
  rxa_1: number | string;
  /** RXA.10 - Administering Provider (max 80) */
  rxa_10?: string;
  /** RXA.11 - Administered-at Location (max 12) */
  rxa_11?: string;
  /** RXA.12 - Administered Per (Time Unit) (max 20) */
  rxa_12?: string;
  /** RXA.2 - Administration Sub-ID Counter (required) */
  rxa_2: number | string;
  /** RXA.3 - Date/Time Start of Administration (required) */
  rxa_3: Date | string;
  /** RXA.4 - Date/Time End of Administration (required) */
  rxa_4: Date | string;
  /** RXA.5 - Administered Code (required, max 100) */
  rxa_5: string;
  /** RXA.6 - Administered Amount (required, max 20) */
  rxa_6: string;
  /** RXA.7 - Administered Units (max 60) */
  rxa_7?: string;
  /** RXA.8 - Administered Dosage Form (max 60) */
  rxa_8?: string;
  /** RXA.9 - Administration Notes (max 200) */
  rxa_9?: string;
}
//#endregion
//#region src/hl7/2.2/rxd.d.ts
/** HL7 2.2 RXD - Pharmacy/Treatment Dispense */
interface HL7_2_2_RXD {
  /** RXD.1 - Dispense Sub-ID Counter (required) */
  rxd_1: string;
  /** RXD.10 - Dispensing Provider */
  rxd_10?: string;
  /** RXD.11 - Substitution Status */
  rxd_11?: string;
  /** RXD.12 - Total Daily Dose */
  rxd_12?: string;
  /** RXD.13 - Dispense-to Location */
  rxd_13?: string;
  /** RXD.14 - Needs Human Review */
  rxd_14?: "N" | "Y";
  /** RXD.15 - Pharmacy/Treatment Supplier's Special Dispensing Instructions */
  rxd_15?: string;
  /** RXD.2 - Dispense/Give Code (required) */
  rxd_2: string;
  /** RXD.3 - Date/Time Dispensed (required) */
  rxd_3: Date | string;
  /** RXD.4 - Actual Dispense Amount (required) */
  rxd_4: string;
  /** RXD.5 - Actual Dispense Units */
  rxd_5?: string;
  /** RXD.6 - Actual Dosage Form */
  rxd_6?: string;
  /** RXD.7 - Prescription Number (required) */
  rxd_7: string;
  /** RXD.8 - Number Of Refills Remaining */
  rxd_8?: string;
  /** RXD.9 - Dispense Notes */
  rxd_9?: string;
}
//#endregion
//#region src/hl7/2.2/rxe.d.ts
/** HL7 2.2 RXE - Pharmacy/Treatment Encoded Order */
interface HL7_2_2_RXE {
  /** RXE.1 - Quantity/Timing */
  rxe_1?: string;
  /** RXE.10 - Dispense Amount */
  rxe_10?: string;
  /** RXE.11 - Dispense Units */
  rxe_11?: string;
  /** RXE.12 - Number Of Refills */
  rxe_12?: string;
  /** RXE.13 - Ordering Provider's DEA Number */
  rxe_13?: string;
  /** RXE.14 - Pharmacist/Treatment Supplier's Verifier ID */
  rxe_14?: string;
  /** RXE.15 - Prescription Number */
  rxe_15?: string;
  /** RXE.16 - Number Of Refills Remaining */
  rxe_16?: string;
  /** RXE.17 - Number Of Refills/Doses Dispensed */
  rxe_17?: string;
  /** RXE.18 - Date/Time of Most Recent Refill or Dose Dispensed */
  rxe_18?: Date | string;
  /** RXE.19 - Total Daily Dose */
  rxe_19?: string;
  /** RXE.2 - Give Code (required) */
  rxe_2: string;
  /** RXE.20 - Needs Human Review */
  rxe_20?: "N" | "Y";
  /** RXE.21 - Pharmacy/Treatment Supplier's Special Dispensing Instructions */
  rxe_21?: string;
  /** RXE.22 - Give Per (Time Unit) */
  rxe_22?: string;
  /** RXE.23 - Give Rate Amount */
  rxe_23?: string;
  /** RXE.24 - Give Rate Units */
  rxe_24?: string;
  /** RXE.3 - Give Amount - Minimum (required) */
  rxe_3: string;
  /** RXE.4 - Give Amount - Maximum */
  rxe_4?: string;
  /** RXE.5 - Give Units (required) */
  rxe_5: string;
  /** RXE.6 - Give Dosage Form */
  rxe_6?: string;
  /** RXE.7 - Provider's Administration Instructions */
  rxe_7?: string;
  /** RXE.8 - Deliver-to Location */
  rxe_8?: string;
  /** RXE.9 - Substitution Status */
  rxe_9?: string;
}
//#endregion
//#region src/hl7/2.2/rxg.d.ts
/** HL7 2.2 RXG - Pharmacy/Treatment Give */
interface HL7_2_2_RXG {
  /** RXG.1 - Give Sub-ID Counter (required) */
  rxg_1: string;
  /** RXG.10 - Substitution Status */
  rxg_10?: string;
  /** RXG.11 - Dispense-to Location */
  rxg_11?: string;
  /** RXG.12 - Needs Human Review */
  rxg_12?: "N" | "Y";
  /** RXG.13 - Special Administration Instructions */
  rxg_13?: string;
  /** RXG.14 - Give Per (Time Unit) */
  rxg_14?: string;
  /** RXG.15 - Give Rate Amount */
  rxg_15?: string;
  /** RXG.16 - Give Rate Units */
  rxg_16?: string;
  /** RXG.2 - Dispense Sub-ID Counter */
  rxg_2?: string;
  /** RXG.3 - Quantity/Timing */
  rxg_3?: string;
  /** RXG.4 - Give Code (required) */
  rxg_4: string;
  /** RXG.5 - Give Amount - Minimum (required) */
  rxg_5: string;
  /** RXG.6 - Give Amount - Maximum */
  rxg_6?: string;
  /** RXG.7 - Give Units (required) */
  rxg_7: string;
  /** RXG.8 - Give Dosage Form */
  rxg_8?: string;
  /** RXG.9 - Administration Notes */
  rxg_9?: string;
}
//#endregion
//#region src/hl7/2.2/rxo.d.ts
/** HL7 2.2 RXO - Pharmacy/Treatment Prescription Order */
interface HL7_2_2_RXO {
  /** RXO.1 - Requested Give Code (required) */
  rxo_1: string;
  /** RXO.10 - Requested Dispense Code */
  rxo_10?: string;
  /** RXO.11 - Requested Dispense Amount */
  rxo_11?: string;
  /** RXO.12 - Requested Dispense Units */
  rxo_12?: string;
  /** RXO.13 - Number Of Refills */
  rxo_13?: string;
  /** RXO.14 - Ordering Provider's DEA Number */
  rxo_14?: string;
  /** RXO.15 - Pharmacist/Treatment Supplier's Verifier ID */
  rxo_15?: string;
  /** RXO.16 - Needs Human Review */
  rxo_16?: "N" | "Y";
  /** RXO.17 - Requested Give Per (Time Unit) */
  rxo_17?: string;
  /** RXO.2 - Requested Give Amount - Minimum (required) */
  rxo_2: string;
  /** RXO.3 - Requested Give Amount - Maximum */
  rxo_3?: string;
  /** RXO.4 - Requested Give Units */
  rxo_4?: string;
  /** RXO.5 - Requested Dosage Form */
  rxo_5?: string;
  /** RXO.6 - Provider's Pharmacy/Treatment Instructions */
  rxo_6?: string;
  /** RXO.7 - Provider's Administration Instructions */
  rxo_7?: string;
  /** RXO.8 - Deliver-to Location */
  rxo_8?: string;
  /** RXO.9 - Allow Substitutions */
  rxo_9?: "G" | "N";
}
//#endregion
//#region src/hl7/2.2/rxr.d.ts
/** HL7 2.2 RXR - Pharmacy/Treatment Route */
interface HL7_2_2_RXR {
  /** RXR.1 - Route (required, max 60) */
  rxr_1: string;
  /** RXR.2 - Administration Site (max 60) */
  rxr_2?: string;
  /** RXR.3 - Administration Device (max 60) */
  rxr_3?: string;
  /** RXR.4 - Administration Method (max 60) */
  rxr_4?: string;
}
//#endregion
//#region src/hl7/2.2/stf.d.ts
/** HL7 2.2 STF - Staff Identification */
interface HL7_2_2_STF {
  /** STF.2 alias */
  staffIdCode?: string;
  /** STF.3 alias */
  staffName?: string;
  /** STF.1 - Primary Key Value - STF (max 60) */
  stf_1?: string;
  /** STF.10 - Phone (max 40) */
  stf_10?: string;
  /** STF.11 - Office/Home Address (max 106) */
  stf_11?: string;
  /** STF.12 - Institution Activation Date */
  stf_12?: Date | string;
  /** STF.13 - Institution Inactivation Date */
  stf_13?: Date | string;
  /** STF.14 - Backup Person ID (max 60) */
  stf_14?: string;
  /** STF.2 - Staff ID Code (required, max 60) */
  stf_2: string;
  /** STF.3 - Staff Name (max 48) */
  stf_3?: string;
  /** STF.4 - Staff Type (max 2) */
  stf_4?: string;
  /** STF.5 - Sex (max 1) */
  stf_5?: Table0001Value$1;
  /** STF.6 - Date/Time of Birth */
  stf_6?: Date | string;
  /** STF.7 - Active/Inactive Flag */
  stf_7?: "A" | "I";
  /** STF.8 - Department (max 200) */
  stf_8?: string;
  /** STF.9 - Hospital Service - STF (max 200) */
  stf_9?: string;
}
type Table0001Value$1 = (typeof TABLE_0001)[number];
//#endregion
//#region src/hl7/2.2/ub2.d.ts
/** HL7 2.2 UB2 - Uniform Billing Data (UB-92) */
interface HL7_2_2_UB2 {
  /** UB2.1 - Set ID (optional) */
  ub2_1?: number | string;
  /** UB2.10 - UB92 Locator 11 (State) (max 12) */
  ub2_10?: string;
  /** UB2.11 - UB92 Locator 31 (National) (max 5) */
  ub2_11?: string;
  /** UB2.12 - Document Control Number (max 23) */
  ub2_12?: string;
  /** UB2.13 - UB92 Locator 49 (National) (max 4) */
  ub2_13?: string;
  /** UB2.14 - UB92 Locator 56 (State) (max 14) */
  ub2_14?: string;
  /** UB2.15 - UB92 Locator 57 (National) (max 27) */
  ub2_15?: string;
  /** UB2.16 - UB92 Locator 78 (State) (max 2) */
  ub2_16?: string;
  /** UB2.17 - Special Visit Count (max 3) */
  ub2_17?: string;
  /** UB2.2 - Co-Insurance Days (max 3) */
  ub2_2?: string;
  /** UB2.3 - Condition Code (max 14) */
  ub2_3?: string;
  /** UB2.4 - Covered Days (max 3) */
  ub2_4?: string;
  /** UB2.5 - Non-Covered Days (max 4) */
  ub2_5?: string;
  /** UB2.6 - Value Amount & Code */
  ub2_6?: string;
  /** UB2.7 - Occurrence Code & Date */
  ub2_7?: string;
  /** UB2.8 - Occurrence Span Code/Dates */
  ub2_8?: string;
  /** UB2.9 - UB92 Locator 2 (State) (max 29) */
  ub2_9?: string;
}
//#endregion
//#region src/hl7/2.3/aig.d.ts
/** HL7 2.3 AIG - Appointment Information - General Resource */
interface HL7_2_3_AIG {
  /** AIG.1 - Set ID (required) */
  aig_1: number | string;
  /** AIG.10 - Start Date/Time Offset Units */
  aig_10?: string;
  /** AIG.11 - Duration */
  aig_11?: string;
  /** AIG.12 - Duration Units */
  aig_12?: string;
  /** AIG.13 - Allow Substitution Code */
  aig_13?: string;
  /** AIG.14 - Filler Status Code */
  aig_14?: string;
  /** AIG.2 - Segment Action Code */
  aig_2?: "A" | "D" | "U";
  /** AIG.3 - Resource ID */
  aig_3?: string;
  /** AIG.4 - Resource Type (required) */
  aig_4: string;
  /** AIG.5 - Resource Group */
  aig_5?: string;
  /** AIG.6 - Resource Quantity */
  aig_6?: string;
  /** AIG.7 - Resource Quantity Units */
  aig_7?: string;
  /** AIG.8 - Start Date/Time */
  aig_8?: Date | string;
  /** AIG.9 - Start Date/Time Offset */
  aig_9?: string;
}
//#endregion
//#region src/hl7/2.3/ail.d.ts
/** HL7 2.3 AIL - Appointment Information - Location Resource */
interface HL7_2_3_AIL {
  /** AIL.1 - Set ID (required) */
  ail_1: number | string;
  /** AIL.10 - Duration Units */
  ail_10?: string;
  /** AIL.11 - Allow Substitution Code */
  ail_11?: string;
  /** AIL.12 - Filler Status Code */
  ail_12?: string;
  /** AIL.2 - Segment Action Code */
  ail_2?: "A" | "D" | "U";
  /** AIL.3 - Location Resource ID */
  ail_3?: string;
  /** AIL.4 - Location Type */
  ail_4?: string;
  /** AIL.5 - Location Group */
  ail_5?: string;
  /** AIL.6 - Start Date/Time */
  ail_6?: Date | string;
  /** AIL.7 - Start Date/Time Offset */
  ail_7?: string;
  /** AIL.8 - Start Date/Time Offset Units */
  ail_8?: string;
  /** AIL.9 - Duration */
  ail_9?: string;
}
//#endregion
//#region src/hl7/2.3/aip.d.ts
/** HL7 2.3 AIP - Appointment Information - Personnel Resource */
interface HL7_2_3_AIP {
  /** AIP.1 - Set ID (required) */
  aip_1: number | string;
  /** AIP.10 - Duration Units */
  aip_10?: string;
  /** AIP.11 - Allow Substitution Code */
  aip_11?: string;
  /** AIP.12 - Filler Status Code */
  aip_12?: string;
  /** AIP.2 - Segment Action Code */
  aip_2?: "A" | "D" | "U";
  /** AIP.3 - Personnel Resource ID */
  aip_3?: string;
  /** AIP.4 - Resource Role (required) */
  aip_4: string;
  /** AIP.5 - Resource Group */
  aip_5?: string;
  /** AIP.6 - Start Date/Time */
  aip_6?: Date | string;
  /** AIP.7 - Start Date/Time Offset */
  aip_7?: string;
  /** AIP.8 - Start Date/Time Offset Units */
  aip_8?: string;
  /** AIP.9 - Duration */
  aip_9?: string;
}
//#endregion
//#region src/hl7/2.3/ais.d.ts
/** HL7 2.3 AIS - Appointment Information - Service */
interface HL7_2_3_AIS {
  /** AIS.1 - Set ID (required) */
  ais_1: number | string;
  /** AIS.10 - Filler Status Code */
  ais_10?: string;
  /** AIS.2 - Segment Action Code */
  ais_2?: "A" | "D" | "U";
  /** AIS.3 - Universal Service Identifier (required) */
  ais_3: string;
  /** AIS.4 - Start Date/Time */
  ais_4?: Date | string;
  /** AIS.5 - Start Date/Time Offset */
  ais_5?: string;
  /** AIS.6 - Start Date/Time Offset Units */
  ais_6?: string;
  /** AIS.7 - Duration */
  ais_7?: string;
  /** AIS.8 - Duration Units */
  ais_8?: string;
  /** AIS.9 - Allow Substitution Code */
  ais_9?: string;
}
//#endregion
//#region src/hl7/2.3/apr.d.ts
/** HL7 2.3 APR - Appointment Preferences */
interface HL7_2_3_APR {
  /** APR.1 - Time Selection Criteria */
  apr_1?: string;
  /** APR.2 - Resource Selection Criteria */
  apr_2?: string;
  /** APR.3 - Location Selection Criteria */
  apr_3?: string;
  /** APR.4 - Slot Spacing Criteria */
  apr_4?: string;
  /** APR.5 - Filler Override Criteria */
  apr_5?: string;
}
//#endregion
//#region src/hl7/2.3/csp.d.ts
/** HL7 2.3 CSP - Clinical Study Phase */
interface HL7_2_3_CSP {
  /** CSP.1 - Study Phase Identifier (required) */
  csp_1: string;
  /** CSP.2 - Date/Time Study Phase Began (required) */
  csp_2: Date | string;
  /** CSP.3 - Date/Time Study Phase Ended */
  csp_3?: Date | string;
  /** CSP.4 - Study Phase Evaluability */
  csp_4?: string;
}
//#endregion
//#region src/hl7/2.3/csr.d.ts
/** HL7 2.3 CSR - Clinical Study Registration */
interface HL7_2_3_CSR {
  /** CSR.1 - Sponsor Study ID (required) */
  csr_1: string;
  /** CSR.10 - Patient Study Eligibility Status */
  csr_10?: string;
  /** CSR.11 - Study Randomization Date/Time */
  csr_11?: Date | string;
  /** CSR.12 - Randomized Study Arm */
  csr_12?: string;
  /** CSR.13 - Stratum for Study Randomization */
  csr_13?: string;
  /** CSR.14 - Patient Evaluability Status */
  csr_14?: string;
  /** CSR.15 - Date/Time Ended Study */
  csr_15?: Date | string;
  /** CSR.16 - Reason Ended Study */
  csr_16?: string;
  /** CSR.2 - Alternate Study ID */
  csr_2?: string;
  /** CSR.3 - Institution Registering the Patient */
  csr_3?: string;
  /** CSR.4 - Sponsor Patient ID (required) */
  csr_4: string;
  /** CSR.5 - Alternate Patient ID */
  csr_5?: string;
  /** CSR.6 - Date/Time of Patient Study Registration (required) */
  csr_6: Date | string;
  /** CSR.7 - Person Performing Study Registration */
  csr_7?: string;
  /** CSR.8 - Study Authorizing Provider (required) */
  csr_8: string;
  /** CSR.9 - Date/Time Patient Study Consent Signed */
  csr_9?: Date | string;
}
//#endregion
//#region src/hl7/2.3/css.d.ts
/** HL7 2.3 CSS - Clinical Study Data Schedule Segment */
interface HL7_2_3_CSS {
  /** CSS.1 - Study Scheduled Time Point (required) */
  css_1: string;
  /** CSS.2 - Study Scheduled Patient Time Point */
  css_2?: Date | string;
  /** CSS.3 - Study Quality Control Codes */
  css_3?: string;
}
//#endregion
//#region src/hl7/2.3/ctd.d.ts
/** HL7 2.3 CTD - Contact Data */
interface HL7_2_3_CTD {
  /** CTD.1 - Contact Role (required) */
  ctd_1: string;
  /** CTD.2 - Contact Name */
  ctd_2?: string;
  /** CTD.3 - Contact Address */
  ctd_3?: string;
  /** CTD.4 - Contact Location */
  ctd_4?: string;
  /** CTD.5 - Contact Communication Information */
  ctd_5?: string;
  /** CTD.6 - Preferred Method of Contact */
  ctd_6?: string;
  /** CTD.7 - Contact Identifiers */
  ctd_7?: string;
}
//#endregion
//#region src/hl7/types/nk1.d.ts
/** HL7 NK1 - Next of Kin */
interface HL7_NK1 {
  /** NK1.1 - Set ID */
  nk1_1: number | string;
  /** NK1.2 - Name */
  nk1_2?: string;
  /** NK1.3 - Relationship */
  nk1_3?: string;
  /** NK1.4 - Address */
  nk1_4?: string;
  /** NK1.5 - Phone Number */
  nk1_5?: string;
  setId?: number | string;
}
//#endregion
//#region src/hl7/2.1/nk1.d.ts
type HL7_2_1_NK1 = HL7_NK1;
//#endregion
//#region src/hl7/2.3/nk1.d.ts
/** HL7 2.3 NK1 - extends 2.1 with fields 6-20 */
interface HL7_2_3_NK1 extends HL7_2_1_NK1 {
  /** NK1.10 - Next of Kin/Associated Parties Job Title */
  nk1_10?: string;
  /** NK1.11 - Next of Kin/Associated Parties Job Code/Class */
  nk1_11?: string;
  /** NK1.12 - Next of Kin/Associated Parties Employee Number */
  nk1_12?: string;
  /** NK1.13 - Organization Name - NK1 */
  nk1_13?: string;
  /** NK1.14 - Marital Status */
  nk1_14?: string;
  /** NK1.15 - Administrative Sex */
  nk1_15?: string;
  /** NK1.16 - Date/Time of Birth */
  nk1_16?: Date | string;
  /** NK1.17 - Living Dependency */
  nk1_17?: string;
  /** NK1.18 - Ambulatory Status */
  nk1_18?: string;
  /** NK1.19 - Citizenship */
  nk1_19?: string;
  /** NK1.20 - Primary Language */
  nk1_20?: string;
  /** NK1.6 - Business Phone Number */
  nk1_6?: string;
  /** NK1.7 - Contact Role */
  nk1_7?: string;
  /** NK1.8 - Start Date */
  nk1_8?: Date | string;
  /** NK1.9 - End Date */
  nk1_9?: Date | string;
}
//#endregion
//#region src/hl7/tables/0078.d.ts
declare const TABLE_0078: string[];
//#endregion
//#region src/hl7/tables/0085.d.ts
declare const TABLE_0085: string[];
//#endregion
//#region src/hl7/tables/0125.d.ts
declare const TABLE_0125: string[];
//#endregion
//#region src/hl7/types/obx.d.ts
/** HL7 OBX - Observation/Result */
interface HL7_OBX {
  abnormalFlags?: Table0078Value;
  observationIdentifier?: string;
  observationResultStatus?: Table0085Value;
  observationSubId?: string;
  observationValue?: string;
  /** OBX.1 - Set ID */
  obx_1?: number | string;
  /** OBX.10 - Nature of Abnormal Test */
  obx_10?: string;
  /** OBX.11 - Observation Result Status */
  obx_11: Table0085Value;
  /** OBX.2 - Value Type */
  obx_2?: Table0125Value;
  /** OBX.3 - Observation Identifier */
  obx_3: string;
  /** OBX.4 - Observation Sub-ID */
  obx_4?: string;
  /** OBX.5 - Observation Value */
  obx_5?: string;
  /** OBX.6 - Units */
  obx_6?: string;
  /** OBX.7 - References Range */
  obx_7?: string;
  /** OBX.8 - Abnormal Flags */
  obx_8?: Table0078Value;
  /** OBX.9 - Probability */
  obx_9?: number | string;
  referencesRange?: string;
  units?: string;
  valueType?: Table0125Value;
}
type Table0078Value = (typeof TABLE_0078)[number];
type Table0085Value = (typeof TABLE_0085)[number];
type Table0125Value = (typeof TABLE_0125)[number];
//#endregion
//#region src/hl7/2.1/obx.d.ts
type HL7_2_1_OBX = HL7_OBX;
//#endregion
//#region src/hl7/2.2/obx.d.ts
/** HL7 2.2 OBX - extends 2.1 with fields 12-15 */
interface HL7_2_2_OBX extends HL7_2_1_OBX {
  /** OBX.12 - Effective Date of Reference Range Values */
  obx_12?: Date | string;
  /** OBX.13 - User Defined Access Checks (max 20) */
  obx_13?: string;
  /** OBX.14 - Date/Time of the Observation */
  obx_14?: Date | string;
  /** OBX.15 - Producer's ID (max 60) */
  obx_15?: string;
}
//#endregion
//#region src/hl7/2.3/obx.d.ts
/** HL7 2.3 OBX - extends 2.2 with fields 16-17 */
interface HL7_2_3_OBX extends HL7_2_2_OBX {
  /** OBX.16 - Responsible Observer (max 80) */
  obx_16?: string;
  /** OBX.17 - Observation Method (max 60) */
  obx_17?: string;
}
//#endregion
//#region src/hl7/2.3/pcr.d.ts
/** HL7 2.3 PCR - Possible Causal Relationship */
interface HL7_2_3_PCR {
  /** PCR.1 - Implicated Product (required) */
  pcr_1: string;
  /** PCR.10 - Indication For Product Use */
  pcr_10?: string;
  /** PCR.11 - Product Problem */
  pcr_11?: string;
  /** PCR.12 - Product Serial/Lot Number */
  pcr_12?: string;
  /** PCR.13 - Product Available For Inspection */
  pcr_13?: string;
  /** PCR.14 - Product Evaluation Performed */
  pcr_14?: string;
  /** PCR.15 - Product Evaluation Status */
  pcr_15?: string;
  /** PCR.16 - Product Evaluation Results */
  pcr_16?: string;
  /** PCR.17 - Evaluated Product Source */
  pcr_17?: string;
  /** PCR.18 - Date Product Returned To Manufacturer */
  pcr_18?: Date | string;
  /** PCR.19 - Device Operator Qualifications */
  pcr_19?: string;
  /** PCR.2 - Generic Product */
  pcr_2?: "N" | "NA" | "Y";
  /** PCR.20 - Relatedness Assessment */
  pcr_20?: string;
  /** PCR.21 - Action Taken In Response To The Event */
  pcr_21?: string;
  /** PCR.22 - Event Causality Observations */
  pcr_22?: string;
  /** PCR.23 - Indirect Exposure Mechanism */
  pcr_23?: string;
  /** PCR.3 - Product Class */
  pcr_3?: string;
  /** PCR.4 - Total Duration Of Therapy */
  pcr_4?: string;
  /** PCR.5 - Product Manufacture Date */
  pcr_5?: Date | string;
  /** PCR.6 - Product Expiration Date */
  pcr_6?: Date | string;
  /** PCR.7 - Product Implantation Date */
  pcr_7?: Date | string;
  /** PCR.8 - Product Explantation Date */
  pcr_8?: Date | string;
  /** PCR.9 - Single Use Device */
  pcr_9?: string;
}
//#endregion
//#region src/hl7/2.3/pd1.d.ts
/** HL7 2.3 PD1 - Patient Additional Demographic */
interface HL7_2_3_PD1 {
  /** PD1.1 - Living Dependency */
  pd1_1?: string;
  /** PD1.10 - Duplicate Patient */
  pd1_10?: string;
  /** PD1.11 - Publicity Code */
  pd1_11?: string;
  /** PD1.12 - Protection Indicator */
  pd1_12?: "N" | "Y";
  /** PD1.2 - Living Arrangement */
  pd1_2?: string;
  /** PD1.3 - Patient Primary Facility */
  pd1_3?: string;
  /** PD1.4 - Patient Primary Care Provider Name & ID No. */
  pd1_4?: string;
  /** PD1.5 - Student Indicator */
  pd1_5?: string;
  /** PD1.6 - Handicap */
  pd1_6?: string;
  /** PD1.7 - Living Will Code */
  pd1_7?: string;
  /** PD1.8 - Organ Donor Code */
  pd1_8?: string;
  /** PD1.9 - Separate Bill */
  pd1_9?: "N" | "Y";
}
//#endregion
//#region src/hl7/2.3/pra.d.ts
/** HL7 2.3 PRA - Practitioner Detail */
interface HL7_2_3_PRA {
  /** PRA.1 - Primary Key Value - PRA */
  pra_1?: string;
  /** PRA.2 - Practitioner Group */
  pra_2?: string;
  /** PRA.3 - Practitioner Category */
  pra_3?: string;
  /** PRA.4 - Provider Billing */
  pra_4?: "I" | "O";
  /** PRA.5 - Specialty */
  pra_5?: string;
  /** PRA.6 - Practitioner ID Numbers */
  pra_6?: string;
  /** PRA.7 - Privileges */
  pra_7?: string;
  /** PRA.8 - Date Entered Practice */
  pra_8?: Date | string;
}
//#endregion
//#region src/hl7/2.3/prd.d.ts
/** HL7 2.3 PRD - Provider Data */
interface HL7_2_3_PRD {
  /** PRD.1 - Provider Role (required) */
  prd_1: string;
  /** PRD.2 - Provider Name */
  prd_2?: string;
  /** PRD.3 - Provider Address */
  prd_3?: string;
  /** PRD.4 - Provider Location */
  prd_4?: string;
  /** PRD.5 - Provider Communication Information */
  prd_5?: string;
  /** PRD.6 - Preferred Method of Contact */
  prd_6?: string;
  /** PRD.7 - Provider Identifiers */
  prd_7?: string;
  /** PRD.8 - Effective Start Date of Provider Role */
  prd_8?: Date | string;
  /** PRD.9 - Effective End Date of Provider Role */
  prd_9?: Date | string;
}
//#endregion
//#region src/hl7/2.3/psh.d.ts
/** HL7 2.3 PSH - Product Summary Header */
interface HL7_2_3_PSH {
  /** PSH.1 - Report Type (required) */
  psh_1: string;
  /** PSH.10 - Quantity in Use */
  psh_10?: string;
  /** PSH.11 - Quantity in Use Method */
  psh_11?: "A" | "E";
  /** PSH.12 - Quantity in Use Comment */
  psh_12?: string;
  /** PSH.13 - Number of Product Experience Reports Filed by Facility */
  psh_13?: string;
  /** PSH.14 - Number of Product Experience Reports Filed by Distributor */
  psh_14?: string;
  /** PSH.2 - Report Form Identifier */
  psh_2?: string;
  /** PSH.3 - Report Date (required) */
  psh_3: Date | string;
  /** PSH.4 - Report Interval Start Date */
  psh_4?: Date | string;
  /** PSH.5 - Report Interval End Date */
  psh_5?: Date | string;
  /** PSH.6 - Quantity Manufactured */
  psh_6?: string;
  /** PSH.7 - Quantity Distributed */
  psh_7?: string;
  /** PSH.8 - Quantity Distributed Method */
  psh_8?: "A" | "E";
  /** PSH.9 - Quantity Distributed Comment */
  psh_9?: string;
}
//#endregion
//#region src/hl7/2.3/rdf.d.ts
/** HL7 2.3 RDF - Table Row Definition */
interface HL7_2_3_RDF {
  /** RDF.1 - Number of Columns per Row (required) */
  rdf_1: string;
  /** RDF.2 - Column Description (required) */
  rdf_2: string;
}
//#endregion
//#region src/hl7/2.3/rdt.d.ts
/** HL7 2.3 RDT - Table Row Data */
interface HL7_2_3_RDT {
  /** RDT.1 - Column Value (required) */
  rdt_1: string;
}
//#endregion
//#region src/hl7/2.3/rgs.d.ts
/** HL7 2.3 RGS - Resource Group */
interface HL7_2_3_RGS {
  /** RGS.1 - Set ID (required) */
  rgs_1: number | string;
  /** RGS.2 - Segment Action Code */
  rgs_2?: "A" | "D" | "U";
  /** RGS.3 - Resource Group ID */
  rgs_3?: string;
}
//#endregion
//#region src/hl7/tables/0206.d.ts
declare const TABLE_0206: string[];
//#endregion
//#region src/hl7/2.3/rol.d.ts
/** HL7 2.3 ROL - Role */
interface HL7_2_3_ROL {
  /** ROL.1 - Role Instance ID */
  rol_1?: string;
  /** ROL.2 - Action Code (required) */
  rol_2: (typeof TABLE_0206)[number];
  /** ROL.3 - Role-ROL (required) */
  rol_3: string;
  /** ROL.4 - Role Person (required) */
  rol_4: string;
  /** ROL.5 - Role Begin Date/Time */
  rol_5?: Date | string;
  /** ROL.6 - Role End Date/Time */
  rol_6?: Date | string;
  /** ROL.7 - Role Duration */
  rol_7?: string;
  /** ROL.8 - Role Action Reason */
  rol_8?: string;
}
//#endregion
//#region src/hl7/2.3/sch.d.ts
/** HL7 2.3 SCH - Scheduling Activity Information */
interface HL7_2_3_SCH {
  /** SCH.1 - Placer Appointment ID */
  sch_1?: string;
  /** SCH.10 - Appointment Duration Units */
  sch_10?: string;
  /** SCH.11 - Appointment Timing Quantity (required) */
  sch_11: string;
  /** SCH.12 - Placer Contact Person */
  sch_12?: string;
  /** SCH.13 - Placer Contact Phone Number */
  sch_13?: string;
  /** SCH.14 - Placer Contact Address */
  sch_14?: string;
  /** SCH.15 - Placer Contact Location */
  sch_15?: string;
  /** SCH.16 - Filler Contact Person (required) */
  sch_16: string;
  /** SCH.17 - Filler Contact Phone Number */
  sch_17?: string;
  /** SCH.18 - Filler Contact Address */
  sch_18?: string;
  /** SCH.19 - Filler Contact Location */
  sch_19?: string;
  /** SCH.2 - Filler Appointment ID */
  sch_2?: string;
  /** SCH.20 - Entered By Person (required) */
  sch_20: string;
  /** SCH.21 - Entered By Phone Number */
  sch_21?: string;
  /** SCH.22 - Entered By Location */
  sch_22?: string;
  /** SCH.23 - Parent Placer Appointment ID */
  sch_23?: string;
  /** SCH.24 - Parent Filler Appointment ID */
  sch_24?: string;
  /** SCH.25 - Filler Status Code */
  sch_25?: string;
  /** SCH.3 - Occurrence Number */
  sch_3?: string;
  /** SCH.4 - Placer Group Number */
  sch_4?: string;
  /** SCH.5 - Schedule ID */
  sch_5?: string;
  /** SCH.6 - Event Reason (required) */
  sch_6: string;
  /** SCH.7 - Appointment Reason */
  sch_7?: string;
  /** SCH.8 - Appointment Type */
  sch_8?: string;
  /** SCH.9 - Appointment Duration */
  sch_9?: string;
}
//#endregion
//#region src/hl7/2.3/var.d.ts
/** HL7 2.3 VAR - Variance */
interface HL7_2_3_VAR {
  /** VAR.1 - Variance Instance ID (required) */
  var_1: string;
  /** VAR.2 - Documented Date/Time (required) */
  var_2: Date | string;
  /** VAR.3 - Stated Variance Date/Time */
  var_3?: Date | string;
  /** VAR.4 - Variance Originator */
  var_4?: string;
  /** VAR.5 - Variance Classification */
  var_5?: string;
  /** VAR.6 - Variance Description */
  var_6?: string;
}
//#endregion
//#region src/hl7/2.4/drg.d.ts
/** HL7 2.4 DRG - Diagnosis Related Group */
interface HL7_2_4_DRG {
  /** DRG.1 - Diagnostic Related Group */
  drg_1?: string;
  /** DRG.2 - DRG Assigned Date/Time */
  drg_2?: Date | string;
  /** DRG.3 - DRG Approval Indicator */
  drg_3?: "N" | "Y";
  /** DRG.4 - DRG Grouper Review Code */
  drg_4?: string;
  /** DRG.5 - Outlier Type */
  drg_5?: string;
  /** DRG.6 - Outlier Days */
  drg_6?: number | string;
  /** DRG.7 - Outlier Cost */
  drg_7?: string;
  /** DRG.8 - DRG Payor */
  drg_8?: string;
}
//#endregion
//#region src/hl7/2.4/gol.d.ts
/** HL7 2.4 GOL - Goal Detail */
interface HL7_2_4_GOL {
  /** GOL.1 - Action Code (required) */
  gol_1: "AD" | "CO" | "DE" | "LI" | "UC" | "UN";
  /** GOL.10 - Goal Management Discipline */
  gol_10?: string;
  /** GOL.11 - Current Goal Review Status */
  gol_11?: string;
  /** GOL.12 - Current Goal Review Date/Time */
  gol_12?: Date | string;
  /** GOL.13 - Next Goal Review Date/Time */
  gol_13?: Date | string;
  /** GOL.14 - Previous Goal Review Date/Time */
  gol_14?: Date | string;
  /** GOL.15 - Goal Review Interval */
  gol_15?: Date | string;
  /** GOL.16 - Goal Evaluation */
  gol_16?: string;
  /** GOL.17 - Goal Evaluation Comment */
  gol_17?: string;
  /** GOL.18 - Goal Life Cycle Status */
  gol_18?: string;
  /** GOL.19 - Goal Life Cycle Status Date/Time */
  gol_19?: Date | string;
  /** GOL.2 - Action Date/Time (required) */
  gol_2: Date | string;
  /** GOL.20 - Goal Target Type */
  gol_20?: string;
  /** GOL.21 - Goal Target Name */
  gol_21?: string;
  /** GOL.3 - Goal ID (required) */
  gol_3: string;
  /** GOL.4 - Goal Instance ID */
  gol_4?: string;
  /** GOL.5 - Episode of Care ID */
  gol_5?: string;
  /** GOL.6 - Goal List Priority */
  gol_6?: number | string;
  /** GOL.7 - Goal Established Date/Time */
  gol_7?: Date | string;
  /** GOL.8 - Expected Goal Achieve Date/Time */
  gol_8?: Date | string;
  /** GOL.9 - Goal Classification */
  gol_9?: Date | string;
}
//#endregion
//#region src/hl7/2.4/iam.d.ts
/** HL7 2.4 IAM - Patient Adverse Reaction Information */
interface HL7_2_4_IAM {
  /** IAM.1 - Set ID (required) */
  iam_1: number | string;
  /** IAM.10 - Allergen Group Code/Mnemonic/Description */
  iam_10?: string;
  /** IAM.11 - Onset Date */
  iam_11?: Date | string;
  /** IAM.2 - Allergen Type Code */
  iam_2?: string;
  /** IAM.3 - Allergen Code/Mnemonic/Description (required) */
  iam_3: string;
  /** IAM.4 - Allergy Severity Code */
  iam_4?: "MI" | "MO" | "SV" | "U";
  /** IAM.5 - Allergen Reaction Code */
  iam_5?: string;
  /** IAM.6 - Allergy Action Code (required) */
  iam_6: "A" | "D" | "U";
  /** IAM.7 - Allergy Unique Identifier */
  iam_7?: string;
  /** IAM.8 - Action Reason */
  iam_8?: string;
  /** IAM.9 - Sensitivity to Causative Agent Code */
  iam_9?: string;
}
//#endregion
//#region src/hl7/tables/0074.d.ts
declare const TABLE_0074: string[];
//#endregion
//#region src/hl7/tables/0123.d.ts
declare const TABLE_0123: string[];
//#endregion
//#region src/hl7/types/obr.d.ts
/** HL7 OBR - Observation Request */
interface HL7_OBR {
  collectionVolume?: string;
  diagnosticServiceSectionId?: Table0074Value;
  fillerOrderNumber?: string;
  /** OBR.1 - Set ID */
  obr_1?: number | string;
  /** OBR.10 - Collector Identifier */
  obr_10?: string;
  /** OBR.11 - Specimen Action Code */
  obr_11?: string;
  /** OBR.12 - Danger Code */
  obr_12?: string;
  /** OBR.13 - Relevant Clinical Info */
  obr_13?: string;
  /** OBR.14 - Specimen Received Date/Time */
  obr_14?: Date | string;
  /** OBR.15 - Specimen Source */
  obr_15?: string;
  /** OBR.16 - Ordering Provider */
  obr_16?: string;
  /** OBR.17 - Order Callback Phone Number */
  obr_17?: string;
  /** OBR.18 - Placer Field 1 */
  obr_18?: string;
  /** OBR.19 - Placer Field 2 */
  obr_19?: string;
  /** OBR.2 - Placer Order Number */
  obr_2?: string;
  /** OBR.20 - Filler Field 1 */
  obr_20?: string;
  /** OBR.21 - Filler Field 2 */
  obr_21?: string;
  /** OBR.22 - Results Report/Status Change Date/Time */
  obr_22?: Date | string;
  /** OBR.23 - Charge to Practice */
  obr_23?: string;
  /** OBR.24 - Diagnostic Service Section ID */
  obr_24?: Table0074Value;
  /** OBR.25 - Result Status */
  obr_25?: Table0123Value;
  /** OBR.3 - Filler Order Number */
  obr_3?: string;
  /** OBR.4 - Universal Service ID */
  obr_4: string;
  /** OBR.5 - Priority */
  obr_5?: string;
  /** OBR.6 - Requested Date/Time */
  obr_6?: Date | string;
  /** OBR.7 - Observation Date/Time */
  obr_7?: Date | string;
  /** OBR.8 - Observation End Date/Time */
  obr_8?: Date | string;
  /** OBR.9 - Collection Volume */
  obr_9?: string;
  observationDateTime?: Date | string;
  observationEndDateTime?: Date | string;
  orderingProvider?: string;
  placerOrderNumber?: string;
  resultStatus?: Table0123Value;
  specimenSource?: string;
  universalServiceId?: string;
}
type Table0074Value = (typeof TABLE_0074)[number];
type Table0123Value = (typeof TABLE_0123)[number];
//#endregion
//#region src/hl7/2.1/obr.d.ts
type HL7_2_1_OBR = HL7_OBR;
//#endregion
//#region src/hl7/2.2/obr.d.ts
/** HL7 2.2 OBR - extends 2.1 with fields 26-35 */
interface HL7_2_2_OBR extends HL7_2_1_OBR {
  /** OBR.26 - Parent Result (max 60) */
  obr_26?: string;
  /** OBR.27 - Quantity/Timing (max 200) */
  obr_27?: string;
  /** OBR.28 - Result Copies To (max 150) */
  obr_28?: string;
  /** OBR.29 - Parent (max 150) */
  obr_29?: string;
  /** OBR.30 - Transportation Mode (max 20) */
  obr_30?: string;
  /** OBR.31 - Reason for Study (max 300) */
  obr_31?: string;
  /** OBR.32 - Principal Result Interpreter (max 60) */
  obr_32?: string;
  /** OBR.33 - Assistant Result Interpreter (max 60) */
  obr_33?: string;
  /** OBR.34 - Technician (max 60) */
  obr_34?: string;
  /** OBR.35 - Transcriptionist (max 60) */
  obr_35?: string;
}
//#endregion
//#region src/hl7/2.3/obr.d.ts
/** HL7 2.3 OBR - extends 2.2 with fields 36-43 */
interface HL7_2_3_OBR extends HL7_2_2_OBR {
  /** OBR.36 - Scheduled Date/Time */
  obr_36?: Date | string;
  /** OBR.37 - Number of Sample Containers */
  obr_37?: string;
  /** OBR.38 - Transport Logistics of Collected Sample */
  obr_38?: string;
  /** OBR.39 - Collector's Comment */
  obr_39?: string;
  /** OBR.40 - Transport Arrangement Responsibility */
  obr_40?: string;
  /** OBR.41 - Transport Arranged */
  obr_41?: "A" | "N" | "W";
  /** OBR.42 - Escort Required */
  obr_42?: "N" | "O" | "R";
  /** OBR.43 - Planned Patient Transport Comment */
  obr_43?: string;
}
//#endregion
//#region src/hl7/2.4/obr.d.ts
/** HL7 2.4 OBR - extends 2.3 with fields 44-47 */
interface HL7_2_4_OBR extends HL7_2_3_OBR {
  /** OBR.44 - Procedure Code */
  obr_44?: string;
  /** OBR.45 - Procedure Code Modifier */
  obr_45?: string;
  /** OBR.46 - Placer Supplemental Service Information */
  obr_46?: string;
  /** OBR.47 - Filler Supplemental Service Information */
  obr_47?: string;
}
//#endregion
//#region src/hl7/2.4/om1.d.ts
/** HL7 2.4 OM1 - General Attributes of an Observation */
interface HL7_2_4_OM1 {
  /** OM1.1 - Sequence Number (required) */
  om1_1: number | string;
  /** OM1.10 - Preferred Short Name or Mnemonic */
  om1_10?: string;
  /** OM1.11 - Preferred Long Name for the Observation */
  om1_11?: string;
  /** OM1.12 - Orderability */
  om1_12?: "N" | "Y";
  /** OM1.13 - Identity of Instrument Used to Perform this Study */
  om1_13?: string;
  /** OM1.14 - Coded Representation of Method */
  om1_14?: string;
  /** OM1.15 - Portable Device Indicator */
  om1_15?: "N" | "Y";
  /** OM1.16 - Observation Producing Department/Section */
  om1_16?: string;
  /** OM1.17 - Telephone Number of Section */
  om1_17?: string;
  /** OM1.18 - Nature of Service/Test/Observation */
  om1_18?: "A" | "C" | "E" | "F" | "P" | "S";
  /** OM1.19 - Report Subheader */
  om1_19?: string;
  /** OM1.2 - Producer's Service/Test/Observation ID (required) */
  om1_2: string;
  /** OM1.20 - Report Display Order */
  om1_20?: string;
  /** OM1.21 - Date/Time Stamp for Any Change in Def for Obs */
  om1_21?: Date | string;
  /** OM1.22 - Effective Date/Time of Change */
  om1_22?: Date | string;
  /** OM1.23 - Typical Turn-Around Time */
  om1_23?: string;
  /** OM1.24 - Processing Time */
  om1_24?: number | string;
  /** OM1.25 - Processing Priority */
  om1_25?: "A" | "B" | "C" | "P" | "R" | "S" | "T";
  /** OM1.26 - Reporting Priority */
  om1_26?: "C" | "R";
  /** OM1.27 - Outside Site(s) Where Observation May Be Performed */
  om1_27?: string;
  /** OM1.28 - Address of Outside Site(s) */
  om1_28?: string;
  /** OM1.29 - Phone Number of Outside Site */
  om1_29?: string;
  /** OM1.3 - Permitted Data Types */
  om1_3?: string;
  /** OM1.30 - Confidentiality Code */
  om1_30?: string;
  /** OM1.31 - Observations Required to Interpret the Observation */
  om1_31?: string;
  /** OM1.32 - Interpretation of Observations */
  om1_32?: string;
  /** OM1.33 - Contraindications to Observations */
  om1_33?: string;
  /** OM1.34 - Reflex Tests/Observations */
  om1_34?: string;
  /** OM1.35 - Rules That Trigger Reflex Testing */
  om1_35?: string;
  /** OM1.36 - Fixed Canned Message */
  om1_36?: string;
  /** OM1.37 - Patient Preparation */
  om1_37?: string;
  /** OM1.38 - Procedure Medication */
  om1_38?: string;
  /** OM1.39 - Factors that may Affect the Observation */
  om1_39?: string;
  /** OM1.4 - Specimen Required (required) */
  om1_4: "N" | "Y";
  /** OM1.40 - Service/Test/Observation Performance Schedule */
  om1_40?: string;
  /** OM1.41 - Description of Test Methods */
  om1_41?: string;
  /** OM1.42 - Kind of Quantity Observed */
  om1_42?: string;
  /** OM1.43 - Point vs. Interval */
  om1_43?: string;
  /** OM1.44 - Challenge Information */
  om1_44?: string;
  /** OM1.45 - Relationship Modifier */
  om1_45?: string;
  /** OM1.46 - Target Anatomic Site of Test */
  om1_46?: string;
  /** OM1.47 - Modality of Imaging Measurement */
  om1_47?: string;
  /** OM1.5 - Producer ID (required) */
  om1_5: string;
  /** OM1.6 - Observation Description */
  om1_6?: string;
  /** OM1.7 - Other Service/Test/Observation IDs for the Observation */
  om1_7?: string;
  /** OM1.8 - Other Names */
  om1_8?: string;
  /** OM1.9 - Preferred Report Name for the Observation */
  om1_9?: string;
}
//#endregion
//#region src/hl7/2.4/om2.d.ts
/** HL7 2.4 OM2 - Numeric Observations */
interface HL7_2_4_OM2 {
  /** OM2.1 - Sequence Number (required) */
  om2_1: number | string;
  /** OM2.10 - Minimum Meaningful Increments */
  om2_10?: string;
  /** OM2.2 - Units of Measure */
  om2_2?: string;
  /** OM2.3 - Range of Decimal Precision */
  om2_3?: string;
  /** OM2.4 - Corresponding SI Units of Measure */
  om2_4?: string;
  /** OM2.5 - SI Conversion Factor */
  om2_5?: string;
  /** OM2.6 - Reference (Normal) Range for Ordinal/Continuous Observations */
  om2_6?: string;
  /** OM2.7 - Critical Range for Ordinal/Continuous Obs */
  om2_7?: string;
  /** OM2.8 - Absolute Range for Ordinal/Continuous Obs */
  om2_8?: string;
  /** OM2.9 - Delta Check Criteria */
  om2_9?: string;
}
//#endregion
//#region src/hl7/2.4/om3.d.ts
/** HL7 2.4 OM3 - Categorical/Ordinal Test/Observation */
interface HL7_2_4_OM3 {
  /** OM3.1 - Sequence Number (required) */
  om3_1: number | string;
  /** OM3.2 - Preferred Coding System */
  om3_2?: string;
  /** OM3.3 - Valid Coded Answers */
  om3_3?: string;
  /** OM3.4 - Normal Text/Codes for Categorical Observations */
  om3_4?: string;
  /** OM3.5 - Abnormal Text/Codes for Categorical Obs */
  om3_5?: string;
  /** OM3.6 - Critical Text/Codes for Categorical Obs */
  om3_6?: string;
  /** OM3.7 - Value Type */
  om3_7?: string;
  /** OM3.8 - Units of Measure for Counts */
  om3_8?: string;
  /** OM3.9 - Range of Decimal Precision for Counts */
  om3_9?: string;
}
//#endregion
//#region src/hl7/2.4/om4.d.ts
/** HL7 2.4 OM4 - Observations Requiring Specimens */
interface HL7_2_4_OM4 {
  /** OM4.1 - Sequence Number */
  om4_1?: number | string;
  /** OM4.10 - Normal Collection Volume */
  om4_10?: string;
  /** OM4.11 - Minimum Collection Volume */
  om4_11?: string;
  /** OM4.12 - Specimen Requirements */
  om4_12?: string;
  /** OM4.13 - Specimen Priorities */
  om4_13?: "E" | "R" | "S" | "T";
  /** OM4.14 - Specimen Retention Time */
  om4_14?: string;
  /** OM4.15 - Specimen Handling Code */
  om4_15?: string;
  /** OM4.16 - Specimen Condition */
  om4_16?: string;
  /** OM4.17 - Minimum Volume */
  om4_17?: string;
  /** OM4.18 - Reject if No Performer Reason */
  om4_18?: string;
  /** OM4.19 - Specimen Collection Site */
  om4_19?: string;
  /** OM4.2 - Derived Specimen */
  om4_2?: string;
  /** OM4.3 - Container Description */
  om4_3?: string;
  /** OM4.4 - Container Volume */
  om4_4?: number | string;
  /** OM4.5 - Container Units */
  om4_5?: string;
  /** OM4.6 - Specimen */
  om4_6?: string;
  /** OM4.7 - Additive */
  om4_7?: string;
  /** OM4.8 - Preparation */
  om4_8?: string;
  /** OM4.9 - Special Handling Requirements */
  om4_9?: string;
}
//#endregion
//#region src/hl7/2.4/om5.d.ts
/** HL7 2.4 OM5 - Observation Batteries */
interface HL7_2_4_OM5 {
  /** OM5.1 - Sequence Number (required) */
  om5_1: number | string;
  /** OM5.2 - Test/Observations Included Within an Ordered Test Battery */
  om5_2?: string;
  /** OM5.3 - Observation ID Suffixes */
  om5_3?: string;
}
//#endregion
//#region src/hl7/2.4/om6.d.ts
/** HL7 2.4 OM6 - Calculated Observations */
interface HL7_2_4_OM6 {
  /** OM6.1 - Sequence Number (required) */
  om6_1: number | string;
  /** OM6.2 - Derivation Rule */
  om6_2?: string;
}
//#endregion
//#region src/hl7/tables/0119.d.ts
declare const TABLE_0119: string[];
//#endregion
//#region src/hl7/tables/0121.d.ts
declare const TABLE_0121: string[];
//#endregion
//#region src/hl7/types/orc.d.ts
/** HL7 ORC - Common Order */
interface HL7_ORC {
  callBackPhoneNumber?: string;
  enteredBy?: string;
  fillerOrderNumber?: string;
  /** ORC.1 - Order Control */
  orc_1: Table0119Value;
  /** ORC.10 - Entered By */
  orc_10?: string;
  /** ORC.11 - Verified By */
  orc_11?: string;
  /** ORC.12 - Ordering Provider */
  orc_12?: string;
  /** ORC.13 - Enterer's Location */
  orc_13?: string;
  /** ORC.14 - Call Back Phone Number */
  orc_14?: string;
  /** ORC.2 - Placer Order Number */
  orc_2?: string;
  /** ORC.3 - Filler Order Number */
  orc_3?: string;
  /** ORC.4 - Placer Group Number */
  orc_4?: string;
  /** ORC.5 - Order Status */
  orc_5?: string;
  /** ORC.6 - Response Flag */
  orc_6?: Table0121Value;
  /** ORC.7 - Quantity/Timing */
  orc_7?: string;
  /** ORC.8 - Parent */
  orc_8?: string;
  /** ORC.9 - Date/Time of Transaction */
  orc_9?: Date | string;
  orderControl?: Table0119Value;
  orderingProvider?: string;
  orderStatus?: string;
  placerOrderNumber?: string;
  responseFlag?: Table0121Value;
  transactionDateTime?: Date | string;
  verifiedBy?: string;
}
type Table0119Value = (typeof TABLE_0119)[number];
type Table0121Value = (typeof TABLE_0121)[number];
//#endregion
//#region src/hl7/2.1/orc.d.ts
type HL7_2_1_ORC = HL7_ORC;
//#endregion
//#region src/hl7/2.2/orc.d.ts
/** HL7 2.2 ORC - extends 2.1 with fields 15-20 */
interface HL7_2_2_ORC extends HL7_2_1_ORC {
  /** ORC.15 - Order Effective Date/Time */
  orc_15?: Date | string;
  /** ORC.16 - Order Control Code Reason (max 200) */
  orc_16?: string;
  /** ORC.17 - Entering Organization (max 60) */
  orc_17?: string;
  /** ORC.18 - Entering Device (max 60) */
  orc_18?: string;
  /** ORC.19 - Action By (max 80) */
  orc_19?: string;
  /** ORC.20 - Advanced Beneficiary Notice Code (max 40) */
  orc_20?: string;
}
//#endregion
//#region src/hl7/2.3/orc.d.ts
/** HL7 2.3 ORC - extends 2.2 with fields 21-23 */
interface HL7_2_3_ORC extends HL7_2_2_ORC {
  /** ORC.21 - Ordering Facility Name */
  orc_21?: string;
  /** ORC.22 - Ordering Facility Address */
  orc_22?: string;
  /** ORC.23 - Ordering Facility Phone Number */
  orc_23?: string;
}
//#endregion
//#region src/hl7/2.4/orc.d.ts
/** HL7 2.4 ORC - extends 2.3 with fields 24-30 */
interface HL7_2_4_ORC extends HL7_2_3_ORC {
  /** ORC.24 - Order Status Modifier */
  orc_24?: string;
  /** ORC.25 - Advanced Beneficiary Notice Override Reason */
  orc_25?: string;
  /** ORC.26 - Filler's Expected Availability Date/Time */
  orc_26?: Date | string;
  /** ORC.27 - Confidentiality Code */
  orc_27?: string;
  /** ORC.28 - Order Type */
  orc_28?: "I" | "O";
  /** ORC.29 - Enterer Authorization Mode */
  orc_29?: string;
  /** ORC.30 - Parent Universal Service Identifier */
  orc_30?: string;
}
//#endregion
//#region src/hl7/tables/0002.d.ts
declare const TABLE_0002: string[];
//#endregion
//#region src/hl7/types/pid.d.ts
/** HL7 PID - Patient Identification */
interface HL7_PID {
  alternatePatientId?: string;
  countyCode?: string;
  dateOfBirth?: Date | string;
  language?: string;
  maritalStatus?: Table0002Value;
  mothersMaidenName?: string;
  patientAccountNumber?: string;
  patientAddress?: string;
  patientAlias?: string;
  patientIdExternal?: string;
  patientIdInternal?: string;
  patientName?: string;
  phoneNumberBusiness?: string;
  phoneNumberHome?: string;
  /** PID.1 - Set ID */
  pid_1?: number | string;
  /** PID.10 - Race */
  pid_10?: string;
  /** PID.11 - Patient Address */
  pid_11?: string;
  /** PID.12 - County Code */
  pid_12?: string;
  /** PID.13 - Phone Number - Home */
  pid_13?: string;
  /** PID.14 - Phone Number - Business */
  pid_14?: string;
  /** PID.15 - Language - Patient */
  pid_15?: string;
  /** PID.16 - Marital Status */
  pid_16?: Table0002Value;
  /** PID.17 - Religion */
  pid_17?: string;
  /** PID.18 - Patient Account Number */
  pid_18?: string;
  /** PID.19 - SSN Number - Patient */
  pid_19?: string;
  /** PID.2 - Patient ID (External) */
  pid_2?: string;
  /** PID.3 - Patient ID (Internal) */
  pid_3: string;
  /** PID.4 - Alternate Patient ID */
  pid_4?: string;
  /** PID.5 - Patient Name */
  pid_5: string;
  /** PID.6 - Mother's Maiden Name */
  pid_6?: string;
  /** PID.7 - Date of Birth */
  pid_7?: Date | string;
  /** PID.8 - Sex */
  pid_8?: Table0001Value;
  /** PID.9 - Patient Alias */
  pid_9?: string;
  race?: string;
  religion?: string;
  sex?: Table0001Value;
  ssn?: string;
}
type Table0001Value = (typeof TABLE_0001)[number];
type Table0002Value = (typeof TABLE_0002)[number];
//#endregion
//#region src/hl7/2.1/pid.d.ts
type HL7_2_1_PID = HL7_PID;
//#endregion
//#region src/hl7/2.2/pid.d.ts
/** HL7 2.2 PID - extends 2.1 with fields 20-26 */
interface HL7_2_2_PID extends HL7_2_1_PID {
  /** PID.20 - Driver's License Number - Patient */
  pid_20?: string;
  /** PID.21 - Mother's Identifier */
  pid_21?: string;
  /** PID.22 - Ethnic Group */
  pid_22?: string;
  /** PID.23 - Birth Place */
  pid_23?: string;
  /** PID.24 - Multiple Birth Indicator */
  pid_24?: Table0136Value;
  /** PID.25 - Birth Order */
  pid_25?: number | string;
  /** PID.26 - Citizenship */
  pid_26?: string;
}
type Table0136Value = (typeof TABLE_0136)[number];
//#endregion
//#region src/hl7/2.3/pid.d.ts
/** HL7 2.3 PID - extends 2.2 with fields 27-30 */
interface HL7_2_3_PID extends HL7_2_2_PID {
  /** PID.27 - Veterans Military Status */
  pid_27?: string;
  /** PID.28 - Nationality Code */
  pid_28?: string;
  /** PID.29 - Patient Death Date and Time */
  pid_29?: Date | string;
  /** PID.30 - Patient Death Indicator */
  pid_30?: "N" | "Y";
}
//#endregion
//#region src/hl7/2.4/pid.d.ts
/** HL7 2.4 PID - extends 2.3 with fields 31-39 */
interface HL7_2_4_PID extends HL7_2_3_PID {
  /** PID.31 - Identity Unknown Indicator */
  pid_31?: "N" | "Y";
  /** PID.32 - Identity Reliability Code */
  pid_32?: string;
  /** PID.33 - Last Update Date/Time */
  pid_33?: Date | string;
  /** PID.34 - Last Update Facility */
  pid_34?: string;
  /** PID.35 - Species Code */
  pid_35?: string;
  /** PID.36 - Breed Code */
  pid_36?: string;
  /** PID.37 - Strain */
  pid_37?: string;
  /** PID.38 - Production Class Code */
  pid_38?: string;
  /** PID.39 - Tribal Citizenship */
  pid_39?: string;
}
//#endregion
//#region src/hl7/2.4/prb.d.ts
/** HL7 2.4 PRB - Problem Detail */
interface HL7_2_4_PRB {
  /** PRB.1 - Action Code (required) */
  prb_1: "AD" | "CO" | "DE" | "LI" | "UC" | "UN";
  /** PRB.10 - Problem Classification */
  prb_10?: string;
  /** PRB.11 - Problem Management Discipline */
  prb_11?: string;
  /** PRB.12 - Problem Persistence */
  prb_12?: string;
  /** PRB.13 - Problem Confirmation Status */
  prb_13?: string;
  /** PRB.14 - Problem Life Cycle Status */
  prb_14?: string;
  /** PRB.15 - Problem Life Cycle Status Date/Time */
  prb_15?: Date | string;
  /** PRB.16 - Problem Date of Onset */
  prb_16?: Date | string;
  /** PRB.17 - Problem Onset Text */
  prb_17?: string;
  /** PRB.18 - Problem Ranking */
  prb_18?: string;
  /** PRB.19 - Certainty of Problem */
  prb_19?: string;
  /** PRB.2 - Action Date/Time (required) */
  prb_2: Date | string;
  /** PRB.20 - Probability of Problem (0-1) */
  prb_20?: number | string;
  /** PRB.21 - Individual Awareness of Problem */
  prb_21?: string;
  /** PRB.22 - Problem Prognosis */
  prb_22?: string;
  /** PRB.23 - Individual Awareness of Prognosis */
  prb_23?: string;
  /** PRB.24 - Family/Significant Other Awareness of Problem/Prognosis */
  prb_24?: string;
  /** PRB.25 - Security/Sensitivity */
  prb_25?: string;
  /** PRB.26 - Problem Severity */
  prb_26?: string;
  /** PRB.3 - Problem ID (required) */
  prb_3: string;
  /** PRB.4 - Problem Instance ID (required) */
  prb_4: string;
  /** PRB.5 - Episode of Care ID */
  prb_5?: string;
  /** PRB.6 - Problem List Priority */
  prb_6?: number | string;
  /** PRB.7 - Problem Established Date/Time */
  prb_7?: Date | string;
  /** PRB.8 - Anticipated Problem Resolution Date/Time */
  prb_8?: Date | string;
  /** PRB.9 - Actual Problem Resolution Date/Time */
  prb_9?: Date | string;
}
//#endregion
//#region src/hl7/2.4/pth.d.ts
/** HL7 2.4 PTH - Pathway */
interface HL7_2_4_PTH {
  /** PTH.1 - Action Code (required) */
  pth_1: "AD" | "DE" | "LI" | "UN";
  /** PTH.2 - Pathway ID (required) */
  pth_2: string;
  /** PTH.3 - Pathway Instance ID (required) */
  pth_3: string;
  /** PTH.4 - Pathway Established Date/Time (required) */
  pth_4: Date | string;
  /** PTH.5 - Pathway Life Cycle Status */
  pth_5?: string;
  /** PTH.6 - Change Pathway Life Cycle Status Date/Time */
  pth_6?: Date | string;
  /** PTH.7 - Mood Code */
  pth_7?: string;
}
//#endregion
//#region src/hl7/2.4/txa.d.ts
/** HL7 2.4 TXA - Transcription Document Header */
interface HL7_2_4_TXA {
  /** TXA.1 - Set ID (required) */
  txa_1: number | string;
  /** TXA.10 - Assigned Document Authenticator */
  txa_10?: string;
  /** TXA.11 - Transcriptionist Code/Name */
  txa_11?: string;
  /** TXA.12 - Unique Document Number (required) */
  txa_12: string;
  /** TXA.13 - Parent Document Number */
  txa_13?: string;
  /** TXA.14 - Placer Order Number */
  txa_14?: string;
  /** TXA.15 - Filler Order Number */
  txa_15?: string;
  /** TXA.16 - Unique Document File Name */
  txa_16?: string;
  /** TXA.17 - Document Completion Status (required) */
  txa_17: "AU" | "CA" | "DO" | "DT" | "IN" | "IP" | "LA" | "OB" | "PA" | "PR" | "PY" | "RD" | "RV" | "UN";
  /** TXA.18 - Document Confidentiality Status */
  txa_18?: "EMP" | "ET" | "R" | "UWL" | "V";
  /** TXA.19 - Document Availability Status */
  txa_19?: "AV" | "CA" | "OB" | "UN";
  /** TXA.2 - Document Type (required) */
  txa_2: string;
  /** TXA.20 - Document Storage Status */
  txa_20?: "AA" | "AC" | "AH" | "AL" | "AR" | "PU";
  /** TXA.21 - Document Change Reason */
  txa_21?: string;
  /** TXA.22 - Authentication Person, Time Stamp */
  txa_22?: string;
  /** TXA.23 - Distributed Copies */
  txa_23?: string;
  /** TXA.3 - Document Content Presentation */
  txa_3?: string;
  /** TXA.4 - Activity Date/Time */
  txa_4?: Date | string;
  /** TXA.5 - Primary Activity Provider Code/Name */
  txa_5?: string;
  /** TXA.6 - Origination Date/Time */
  txa_6?: Date | string;
  /** TXA.7 - Transcription Date/Time */
  txa_7?: Date | string;
  /** TXA.8 - Edit Date/Time */
  txa_8?: Date | string;
  /** TXA.9 - Originator Code/Name */
  txa_9?: string;
}
//#endregion
//#region src/hl7/2.5/sft.d.ts
/** HL7 2.5 SFT - Software Segment */
interface HL7_2_5_SFT {
  /** SFT.1 - Software Vendor Organization (required) */
  sft_1: string;
  /** SFT.2 - Software Certified Version or Release Number (required) */
  sft_2: string;
  /** SFT.3 - Software Product Name (required) */
  sft_3: string;
  /** SFT.4 - Software Binary ID (required) */
  sft_4: string;
  /** SFT.5 - Software Product Information */
  sft_5?: string;
  /** SFT.6 - Software Install Date */
  sft_6?: Date | string;
}
//#endregion
//#region src/hl7/2.5/spm.d.ts
/** HL7 2.5 SPM - Specimen */
interface HL7_2_5_SPM {
  /** SPM.1 - Set ID */
  spm_1?: number | string;
  /** SPM.10 - Specimen Collection Site */
  spm_10?: string;
  /** SPM.11 - Specimen Role */
  spm_11?: string;
  /** SPM.12 - Specimen Collection Amount */
  spm_12?: string;
  /** SPM.13 - Grouped Specimen Count */
  spm_13?: number | string;
  /** SPM.14 - Specimen Description */
  spm_14?: string;
  /** SPM.15 - Specimen Handling Code */
  spm_15?: string;
  /** SPM.16 - Specimen Risk Code */
  spm_16?: string;
  /** SPM.17 - Specimen Collection Date/Time */
  spm_17?: Date | string;
  /** SPM.18 - Specimen Received Date/Time */
  spm_18?: Date | string;
  /** SPM.19 - Specimen Expiration Date/Time */
  spm_19?: Date | string;
  /** SPM.2 - Specimen ID */
  spm_2?: string;
  /** SPM.20 - Specimen Availability */
  spm_20?: "N" | "Y";
  /** SPM.21 - Specimen Reject Reason */
  spm_21?: string;
  /** SPM.22 - Specimen Quality */
  spm_22?: string;
  /** SPM.23 - Specimen Appropriateness */
  spm_23?: string;
  /** SPM.24 - Specimen Condition */
  spm_24?: string;
  /** SPM.25 - Specimen Current Quantity */
  spm_25?: string;
  /** SPM.26 - Number of Specimen Containers */
  spm_26?: number | string;
  /** SPM.27 - Container Type */
  spm_27?: string;
  /** SPM.3 - Specimen Parent IDs */
  spm_3?: string;
  /** SPM.4 - Specimen Type (required) */
  spm_4: string;
  /** SPM.5 - Specimen Type Modifier */
  spm_5?: string;
  /** SPM.6 - Specimen Additives */
  spm_6?: string;
  /** SPM.7 - Specimen Collection Method */
  spm_7?: string;
  /** SPM.8 - Specimen Source Site */
  spm_8?: string;
  /** SPM.9 - Specimen Source Site Modifier */
  spm_9?: string;
}
//#endregion
//#region src/hl7/2.6/bpx.d.ts
/** HL7 2.6 BPX - Blood Product Dispense Status */
interface HL7_2_6_BPX {
  /** BPX.1 - Set ID (required) */
  bpx_1: number | string;
  /** BPX.10 - CP Lot Number */
  bpx_10?: string;
  /** BPX.11 - BP Blood Group */
  bpx_11?: string;
  /** BPX.12 - BC Special Testing */
  bpx_12?: string;
  /** BPX.13 - BP Expiration Date/Time of Status */
  bpx_13?: Date | string;
  /** BPX.14 - BP Quantity (required) */
  bpx_14: string;
  /** BPX.15 - BP Amount */
  bpx_15?: string;
  /** BPX.16 - BP Units */
  bpx_16?: string;
  /** BPX.17 - BP Unique ID */
  bpx_17?: string;
  /** BPX.2 - BP Dispense Status (required) */
  bpx_2: string;
  /** BPX.3 - BP Status (required) */
  bpx_3: string;
  /** BPX.4 - BP Date/Time of Status (required) */
  bpx_4: Date | string;
  /** BPX.5 - BC Donation ID */
  bpx_5?: string;
  /** BPX.6 - BC Component */
  bpx_6?: string;
  /** BPX.7 - BC Donation Type / Intended Use */
  bpx_7?: string;
  /** BPX.8 - CP Commercial Product */
  bpx_8?: string;
  /** BPX.9 - CP Manufacturer */
  bpx_9?: string;
}
//#endregion
//#region src/hl7/2.6/btx.d.ts
/** HL7 2.6 BTX - Blood Product Transfusion/Disposition */
interface HL7_2_6_BTX {
  /** BTX.1 - Set ID (required) */
  btx_1: number | string;
  /** BTX.10 - BP Units */
  btx_10?: string;
  /** BTX.11 - BP Transfusion/Disposition Status (required) */
  btx_11: string;
  /** BTX.12 - BP Message Status (required) */
  btx_12: Date | string;
  /** BTX.13 - BP Date/Time of Status */
  btx_13?: Date | string;
  /** BTX.14 - BP Transfusion Administrator */
  btx_14?: string;
  /** BTX.15 - BP Transfusion Verifier */
  btx_15?: string;
  /** BTX.16 - BP Transfusion Start Date/Time of Status */
  btx_16?: Date | string;
  /** BTX.17 - BP Transfusion End Date/Time of Status */
  btx_17?: Date | string;
  /** BTX.2 - BC Donation ID */
  btx_2?: string;
  /** BTX.3 - BC Component */
  btx_3?: string;
  /** BTX.4 - BC Blood Group */
  btx_4?: string;
  /** BTX.5 - CP Commercial Product */
  btx_5?: string;
  /** BTX.6 - CP Manufacturer */
  btx_6?: string;
  /** BTX.7 - CP Lot Number */
  btx_7?: string;
  /** BTX.8 - BP Quantity (required) */
  btx_8?: string;
  /** BTX.9 - BP Amount */
  btx_9?: string;
}
//#endregion
//#region src/hl7/2.6/itm.d.ts
/** HL7 2.6 ITM - Material Item Master */
interface HL7_2_6_ITM {
  /** ITM.1 - Item Identifier (required) */
  itm_1: string;
  /** ITM.10 - Manufacturer Labeler Identifier */
  itm_10?: string;
  /** ITM.11 - Patient Chargeable Indicator */
  itm_11?: "N" | "Y";
  /** ITM.12 - Transaction Code */
  itm_12?: string;
  /** ITM.13 - Transaction Amount – Unit */
  itm_13?: string;
  /** ITM.14 - Stocked Item Indicator */
  itm_14?: "N" | "Y";
  /** ITM.15 - Supply Risk Codes */
  itm_15?: string;
  /** ITM.16 - Approving Regulatory Agency */
  itm_16?: string;
  /** ITM.17 - Latex Indicator */
  itm_17?: "N" | "Y";
  /** ITM.18 - Ruling Act */
  itm_18?: string;
  /** ITM.19 - Item Natural Account Code */
  itm_19?: string;
  /** ITM.2 - Item Description */
  itm_2?: string;
  /** ITM.20 - Approved To Buy Quantity */
  itm_20?: number | string;
  /** ITM.21 - Approved To Buy Price */
  itm_21?: string;
  /** ITM.22 - Taxable Item Indicator */
  itm_22?: "N" | "Y";
  /** ITM.23 - Freight Charge Indicator */
  itm_23?: "N" | "Y";
  /** ITM.24 - Item Set Indicator */
  itm_24?: "N" | "Y";
  /** ITM.25 - Item Set Identifier */
  itm_25?: string;
  /** ITM.26 - Track Department Usage Indicator */
  itm_26?: "N" | "Y";
  /** ITM.27 - Procedure Code */
  itm_27?: string;
  /** ITM.28 - Procedure Code Modifier */
  itm_28?: string;
  /** ITM.29 - Special Handling Code */
  itm_29?: string;
  /** ITM.3 - Item Status */
  itm_3?: "A" | "I" | "P";
  /** ITM.30 - Hazardous Indicator */
  itm_30?: string;
  /** ITM.31 - Sterile Indicator */
  itm_31?: string;
  /** ITM.32 - Material Data Safety Sheet Number */
  itm_32?: string;
  /** ITM.33 - United Nations Standard Products and Services Code */
  itm_33?: string;
  /** ITM.34 - Contract Date */
  itm_34?: string;
  /** ITM.35 - Manufacturer Contact Name */
  itm_35?: string;
  /** ITM.36 - Manufacturer Contact Information */
  itm_36?: string;
  /** ITM.37 - Class of Trade */
  itm_37?: string;
  /** ITM.38 - Field Level Event Code */
  itm_38?: string;
  /** ITM.4 - Item Type */
  itm_4?: string;
  /** ITM.5 - Item Category */
  itm_5?: string;
  /** ITM.6 - Subject to Expiration Indicator */
  itm_6?: "N" | "Y";
  /** ITM.7 - Manufacturer Identifier */
  itm_7?: string;
  /** ITM.8 - Manufacturer Name */
  itm_8?: string;
  /** ITM.9 - Manufacturer Catalog Number */
  itm_9?: string;
}
//#endregion
//#region src/hl7/2.6/ivt.d.ts
/** HL7 2.6 IVT - Material Location */
interface HL7_2_6_IVT {
  /** IVT.1 - Set ID (required) */
  ivt_1: number | string;
  /** IVT.10 - Default Deny/Charge Type */
  ivt_10?: "N" | "Y";
  /** IVT.11 - Charge Code */
  ivt_11?: string;
  /** IVT.12 - Requisition Type */
  ivt_12?: "N" | "Y";
  /** IVT.13 - Requisition Order Identifier */
  ivt_13?: string;
  /** IVT.14 - Requisition Quantity */
  ivt_14?: string;
  /** IVT.15 - Requisition Unit of Measure */
  ivt_15?: string;
  /** IVT.16 - Patient Chargeable Indicator */
  ivt_16?: string;
  /** IVT.17 - Transaction Code */
  ivt_17?: string;
  /** IVT.18 - Transaction Amount – Unit */
  ivt_18?: string;
  /** IVT.19 - Stocked Item Indicator */
  ivt_19?: "N" | "Y";
  /** IVT.2 - Inventory Location Identifier (required) */
  ivt_2: string;
  /** IVT.20 - Supply Risk Codes */
  ivt_20?: string;
  /** IVT.21 - Taxable Item Indicator */
  ivt_21?: "N" | "Y";
  /** IVT.22 - Freight Charge Indicator */
  ivt_22?: "N" | "Y";
  /** IVT.23 - Item Set Indicator */
  ivt_23?: "N" | "Y";
  /** IVT.24 - Item Set Identifier */
  ivt_24?: string;
  /** IVT.25 - Track Department Usage Indicator */
  ivt_25?: "N" | "Y";
  /** IVT.3 - Inventory Location Name */
  ivt_3?: string;
  /** IVT.4 - Source Location Identifier */
  ivt_4?: string;
  /** IVT.5 - Source Location Name */
  ivt_5?: string;
  /** IVT.6 - Item Status */
  ivt_6?: "A" | "I" | "P";
  /** IVT.7 - Bin Location Identifier */
  ivt_7?: string;
  /** IVT.8 - Order Packaging */
  ivt_8?: string;
  /** IVT.9 - Issue Packaging */
  ivt_9?: string;
}
//#endregion
//#region src/hl7/2.6/rel.d.ts
/** HL7 2.6 REL - Clinical Relationship Segment */
interface HL7_2_6_REL {
  /** REL.1 - Set ID */
  rel_1?: number | string;
  /** REL.10 - Asserting Organization */
  rel_10?: string;
  /** REL.11 - Assertor Address */
  rel_11?: string;
  /** REL.12 - Assertor Contact */
  rel_12?: string;
  /** REL.13 - Assertion Recorded Date/Time */
  rel_13?: Date | string;
  /** REL.14 - Assertion Expiration Date/Time */
  rel_14?: string;
  /** REL.2 - Relationship Type (required) */
  rel_2: string;
  /** REL.3 - This Relationship Instance Identifier (required) */
  rel_3: string;
  /** REL.4 - Source Information Instance Identifier (required) */
  rel_4: string;
  /** REL.5 - Target Information Instance Identifier (required) */
  rel_5: string;
  /** REL.6 - Assertion Date Range Begin */
  rel_6?: Date | string;
  /** REL.7 - Assertion Date Range End */
  rel_7?: Date | string;
  /** REL.8 - Asserting Entity Instance ID */
  rel_8?: "N" | "Y";
  /** REL.9 - Asserting Person */
  rel_9?: string;
}
//#endregion
//#region src/hl7/2.7/ipc.d.ts
/** HL7 2.7 IPC - Imaging Procedure Control */
interface HL7_2_7_IPC {
  /** IPC.1 - Accession Identifier (required) */
  ipc_1: string;
  /** IPC.2 - Requested Procedure ID (required) */
  ipc_2: string;
  /** IPC.3 - Study Instance UID (required) */
  ipc_3: string;
  /** IPC.4 - Scheduled Procedure Step ID (required) */
  ipc_4: string;
  /** IPC.5 - Modality */
  ipc_5?: string;
  /** IPC.6 - Protocol Code */
  ipc_6?: string;
  /** IPC.7 - Scheduled Station Name */
  ipc_7?: string;
  /** IPC.8 - Scheduled Procedure Step Location */
  ipc_8?: string;
}
//#endregion
//#region src/hl7/2.7/isd.d.ts
/** HL7 2.7 ISD - Interaction Status Detail */
interface HL7_2_7_ISD {
  /** ISD.1 - Reference Interaction Number (required) */
  isd_1: number | string;
  /** ISD.2 - Interaction Type Identifier */
  isd_2?: string;
  /** ISD.3 - Interaction Active State (required) */
  isd_3: string;
}
//#endregion
//#region src/hl7/2.8/stz.d.ts
/** HL7 2.8 STZ - Sterilization Parameter */
interface HL7_2_8_STZ {
  /** STZ.1 - Sterilization Type */
  stz_1?: string;
  /** STZ.2 - Sterilization Cycle */
  stz_2?: string;
  /** STZ.3 - Maintenance Cycle */
  stz_3?: string;
  /** STZ.4 - Maintenance Type */
  stz_4?: string;
  /** STZ.5 - Sterile Indicator */
  stz_5?: string;
}
//#endregion
//#region src/hl7/types/add.d.ts
interface HL7_ADD {
  /**
   * Addendum Continuation Pointer
   * @since 4.0.0
   */
  add_1?: string;
  /**
   * Addendum Continuation Pointer
   * @since 4.0.0
   */
  addendumContinuationPointer?: string;
}
//#endregion
//#region src/hl7/types/dsp.d.ts
interface HL7_DSP {
  dsp_1?: string;
  dsp_2?: string;
  dsp_3: string;
  dsp_4?: string;
  dsp_5?: string;
}
//#endregion
//#region src/hl7/types/nst.d.ts
interface HL7_NST {
  /** Statistics Available: "Y" or "N" */
  nst_1?: "N" | "Y";
  /** Checksum Errors Received */
  nst_10?: number | string;
  /** Length Errors Received */
  nst_11?: number | string;
  /** Other Errors Received */
  nst_12?: number | string;
  /** Connect Timeouts */
  nst_13?: number | string;
  /** Receive Timeouts */
  nst_14?: number | string;
  /** Application Control Level Errors */
  nst_15?: number | string;
  /** Source Identifier */
  nst_2?: string;
  /** Source Type */
  nst_3?: string;
  /** Statistics Start (date/time) */
  nst_4?: Date | string;
  /** Statistics End (date/time) */
  nst_5?: Date | string;
  /** Receive Character Count */
  nst_6?: number | string;
  /** Send Character Count */
  nst_7?: number | string;
  /** Messages Received */
  nst_8?: number | string;
  /** Messages Sent */
  nst_9?: number | string;
}
//#endregion
//#region src/utils/createHL7Date.d.ts
type DateLength = "12" | "14" | "19" | "24" | "26" | "8" | undefined;
type HL7Date = {
  __brand: "HL7Date";
} & string;
/**
 * Create a valid HL7 Date.
 * @remarks Custom for this package and based on HL7 standards.
 * @since 1.0.0
 * @param date - The JavaScript Date object to format.
 * @param length - Length of the HL7 date string.
 *                 "8"  = YYYYMMDD
 *                 "12" = YYYYMMDDHHMM
 *                 "14" = YYYYMMDDHHMMSS (default)
 *                 "19" = YYYYMMDDHHMMSS.SSSS
 *                 "24" = YYYYMMDDHHMMSS.SSSS+ZZZZ (with timezone offset)
 * @returns A string formatted as an HL7-compatible date.
 */
declare const createHL7Date: (date: Date, length?: DateLength) => HL7Date;
/**
 * HL7 Padding for Date
 * @since 1.0.0
 */
declare const padHL7Date: (n: number, width: number, z?: string) => string;
//#endregion
//#region src/builder/fileBatch.d.ts
/**
 * File Batch Class
 * @remarks Create a File Batch (FHS) which will could include many BHS/BTS segments,
 * which could include many Message (MSH) segments to output the contents into a file on the OS.
 * These files could then be used to send manually or read by another system to interpret the contents.
 * This class helps
 * in generating the particulars for that file generation to make sure that it follows the correct format.
 * @since 1.0.0
 */
declare class FileBatch extends RootBase {
  /** @internal **/
  _opt: ReturnType<typeof normalizedClientFileParserOptions>;
  /** @internal */
  protected _batchCount: number;
  /** @internal */
  protected _fileName: string;
  /** @internal */
  protected _lines: string[];
  /** @internal */
  protected _messagesCount: number;
  /**
   * @since 1.0.0
   * @param props Passing the options to build the file batch.
   */
  constructor(properties?: ClientBuilderFileOptions);
  /**
   * AAdd a Message or a Batch to the File
   * @remarks This adds a Message (MSH) output into the file batch.
   * If there is a Batch ("BHS") already part of this file, any new Message type will be added to the first found BHS regardless if the second Batch is added last.
   * @since 1.0.0
   * @param message The {@link Message} or {@link Batch} to add into the batch.
   */
  add(message: Batch | Message): void;
  /**
   * Create a file to be stored.
   * @since 1.0.0
   * @param name Name of the file.
   */
  createFile(name: string): void;
  /**
   * End Batch
   * @remarks At the conclusion of building the file batch,
   * (Usually {@link add} method will be before this) will add the File Batch Trailing Segment (FTS) to the end.
   * If a message (MSH) is added after this,
   * that message (MSH) will get added to the first BHS found if there is one, otherwise it will just be added.
   * This might be typical inside a file output process.
   * @since 1.0.0
   */
  end(): void;
  /**
   * Get File name
   * @remarks Get File name going to be created.
   * @since 1.2.0
   */
  fileName(): string;
  /**
   * Get FHS Segment at Path
   * @since 1.0.0
   * @param path Could be 'FHS.7' or 7, and it shall get the same result.
   * @example
   * ```ts
   * const fileBatch = file.get('FHS.7')
   * ```
   * or
   * ```ts
   * const fileBatch = file.get(7)
   * ```
   */
  get(path: number | string): HL7Node;
  /**
   * Get Messages within a submitted File Batch
   * @remarks This will parse the passed on "text"
   * in the contractor options and get all the messages (MSH) segments within it and return an array of them.
   * This will happen regardless of the depth of the segments.
   * @since 1.0.0
   * @example
   * ```ts
   * try {
   *  // parser the batch
   *  const parser = new FileBatch({ text: loadedMessage })
   *  // load the messages
   *  const allMessage = parser.messages()
   *  // loop messages
   *  allMessage.forEach((message: Message) => {
   *    const messageParsed = new Message({ text: message.toString() })
   *  })
   * } catch (e) {
   *   // error here
   * }
   * ```
   * @returns Returns an array of messages or a HL7ParserError will throw.
   */
  messages(): Message[];
  /** @internal */
  read(path: string[]): HL7Node;
  /**
   * Set Batch Segment at Path with a Value
   * @since 1.0.0
   * @example
   * ```ts
   * const batch = new Batch()
   * batch.set('BHS.7', '20231231')
   * ```
   * @param path Where you want to set in the segment
   * @param value The value.
   * It Can be an Array, String, or Boolean.
   * If the value is not set, you can chain this to expand the paths
   * @example
   * If the value is not used this can be employed:
   * ```ts
   * batch.set('BHS.3').set(0).set('BHS.3.1', 'abc');
   * ```
   */
  set(path: number | string, value?: any): HL7Node;
  /**
   * Start Batch
   * @since 1.0.0
   */
  start(): void;
  /** @internal */
  protected createChild(text: string, _index: number): HL7Node;
  /** @internal */
  protected pathCore(): string[];
  /** @internal */
  protected writeCore(path: string[], value: string): HL7Node;
  /** @internal **/
  private _addSegment;
  /** @internal */
  private _getFirstBatch;
  /** @internal */
  private _getFirstSegment;
}
//#endregion
//#region src/hl7/metadata/types.d.ts
/**
 * Description of one sub-component inside a composite field.
 *
 * @remarks
 * For composite HL7 data types (e.g. `XAD` Extended Address, `XPN` Extended
 * Person Name, `CE`/`CWE` coded elements, `CX` Extended Composite Id), the
 * field value is a `^`-delimited list whose pieces each have their own
 * data type, length, optionality, and possibly table reference.
 *
 * `components` are populated automatically by the spec generator from the
 * Caristix DataType endpoint. They are documentation/metadata only — the
 * builder does not enforce per-component validation today (the user remains
 * responsible for assembling the composite string).
 *
 * @since 4.0.0
 */
interface ComponentSpec {
  /** HL7 data type, e.g. `"ST"`, `"DTM"`, `"SAD"`. */
  hl7Type?: string;
  /** Exact length or min/max bounds. */
  length?: {
    max?: number;
    min?: number;
  } | number;
  /** Human-readable component name. */
  name: string;
  /** Position within the field, 1-based (e.g. `XAD.3 City` -> 3). */
  num: number;
  /** Cardinality from Caristix (`"1"` = single, `"*"` = unbounded, etc.). */
  rpt?: string;
  /** Numeric HL7 table id, if the component is enumerated. String table
   * names (e.g. `"Street"`, `"City"`) used by Caristix as informal hints
   * are dropped during generation since they have no machine-readable
   * value list. */
  table?: number;
  /** HL7 usage code (R/O/B/W/D/X) at this component position, as published
   * for the parent data type or field. Sub-component usage isn't versioned
   * the same way fields are — composite types evolved less frequently —
   * so we store a single canonical value. */
  usage?: HL7UsageCode;
}
/**
 * Description of a single field within a segment, with per-version usage codes.
 *
 * A version that is missing from `usage` means the field does NOT exist in that
 * version of the spec — attempting to set it must be rejected at runtime.
 *
 * @since 4.0.0
 */
interface FieldSpec {
  /** Restricted set of allowed string values. */
  allowedValues?: string[];
  /**
   * Sub-components for composite data types (XAD, XPN, CE, CWE, CX, ...).
   * Empty/absent for primitive fields (ST, NM, ID, DTM, ...). Generated
   * from the Caristix DataType endpoint per the latest version of the spec
   * where this segment exists.
   */
  components?: readonly ComponentSpec[];
  /**
   * Conditional dependency — used when usage code is `"D"`. If present, the
   * dependency must resolve before the field is considered satisfied.
   */
  dependsOn?: {
    mustBeSet?: boolean;
    mustEqual?: any;
    path: string;
  };
  /** HL7 data type identifier, e.g. `"ST"`, `"NM"`, `"DTM"`, `"CWE"`. */
  hl7Type?: string;
  /** Exact length or min/max bounds for string values. */
  length?: {
    max?: number;
    min?: number;
  } | number;
  /** Human-readable field name from the HL7 spec. */
  name: string;
  /** Field number within the segment, e.g. ECD.4 -> 4. */
  num: number;
  /** HL7 table id used to validate this field, if any. */
  table?: number;
  /**
   * Per-version usage code map. A version key being absent means the field is
   * not part of that version of the spec at all.
   */
  usage: Partial<Record<HL7Version, HL7UsageCode>>;
}
/**
 * HL7 v2 spec usage code as defined by the HL7 standard.
 *
 * - `R` Required — field must be populated.
 * - `O` Optional — field may or may not be present.
 * - `B` Backward Compatibility — kept for older versions, profiled to "X" in modern impls.
 * - `W` Withdrawn — element is not to be used; treated as "X" (Not Supported).
 * - `D` Dependent / Conditional — usage depends on another field or trigger event.
 * - `X` Not Supported — element cannot be present.
 *
 * @since 4.0.0
 */
type HL7UsageCode = "B" | "D" | "O" | "R" | "W" | "X";
/**
 * Supported HL7 v2 spec versions.
 * @since 4.0.0
 */
type HL7Version = "2.1" | "2.2" | "2.3.1" | "2.3" | "2.4" | "2.5.1" | "2.5" | "2.6" | "2.7.1" | "2.7" | "2.8";
/**
 * Runtime list of the HL7 v2 spec versions recognized by this library, in
 * ascending order. Used to validate a client/listener `version` at runtime.
 * @since 4.0.0
 */
declare const KNOWN_VERSIONS: readonly HL7Version[];
/**
 * Description of an HL7 segment, with per-version availability and field set.
 * @since 4.0.0
 */
interface SegmentSpec {
  /** Human-readable description of the segment. */
  description: string;
  /** All fields defined for this segment across any version. */
  fields: readonly FieldSpec[];
  /** Three-letter segment name, e.g. `"ECD"`. */
  name: string;
  /**
   * Versions of HL7 in which the segment exists at all. A builder for a version
   * not in this list must reject calls to build the segment.
   */
  versions: readonly HL7Version[];
}
/**
 * Runtime guard for {@link HL7Version}. Returns `true` when `v` is one of the
 * {@link KNOWN_VERSIONS}.
 * @since 4.0.0
 */
declare function isKnownVersion(v: unknown): v is HL7Version;
//#endregion
//#region src/declaration/validationRule.d.ts
type ValidationRule = {
  /** An array of valid values. Requires `type` to be `'string'` (the default). */allowedValues?: string[];
  dependsOn?: {
    mustBeSet?: boolean;
    mustEqual?: any;
    path: string;
  };
  deprecated?: boolean; /** Version expression(s) this field is valid for, e.g. `">=2.3"` or `[">=2.1", "<=2.6"]`. */
  hl7Support?: string | string[]; /** HL7 data type identifier, e.g. `"ST"`, `"NM"`, `"DTM"`, `"CWE"`. Documentation only. */
  hl7Type?: string; /** Exact length or min/max bounds for string values. */
  length?: {
    max?: number;
    min?: number;
  } | number; /** Min/max bounds for numeric values. Requires `type: 'number'`. */
  number?: {
    max?: number;
    min?: number;
  };
  pattern?: RegExp;
  /** If `true`, the field must be present and non-empty.
   * @default false */
  required?: boolean;
  /** Input type — controls which validations are applied.
   * @default "string" */
  type?: "date" | "number" | "string";
  /**
   * HL7 usage code for the field in the current version. When set, drives:
   * - `"R"` => required = true
   * - `"B"` => deprecated = true (warning, value still serializes)
   * - `"W"` / `"X"` => hard error if value is provided
   * - `"D"` => requires `dependsOn` to resolve
   * - `"O"` => no extra constraint
   */
  usage?: HL7UsageCode; /** When `deprecated` is true, name the replacement field here. */
  useField?: string;
};
//#endregion
//#region src/hl7/specs.d.ts
/**
 * HL7 Base Interface
 * @since 1.0.0
 */
interface HL7_SPEC {
  /** Build ACC (Accident) Segment */
  buildACC: (properties: ACC) => this;
  /** Build ADD (Addendum) Segment */
  buildADD: (properties: ADD) => this;
  /** Build AIG (Appointment Information - General) Segment */
  buildAIG: (properties: Partial<AIG>) => this;
  /** Build AIL (Appointment Information - Location) Segment */
  buildAIL: (properties: Partial<AIL>) => this;
  /** Build AIP (Appointment Information - Personnel) Segment */
  buildAIP: (properties: Partial<AIP>) => this;
  /** Build AIS (Appointment Information - Service) Segment */
  buildAIS: (properties: Partial<AIS>) => this;
  /** Build AL1 (Allergy Information) Segment */
  buildAL1: (properties: Partial<AL1>) => this;
  /** Build APR (Appointment Preferences) Segment */
  buildAPR: (properties: Partial<APR>) => this;
  /** Build BLG (Billing) Segment */
  buildBLG: (properties: BLG) => this;
  /** Build BPX (Blood Product Dispense Status) Segment */
  buildBPX: (properties: Partial<BPX>) => this;
  /** Build BTX (Blood Product Transfusion/Disposition) Segment */
  buildBTX: (properties: Partial<BTX>) => this;
  /** Build CSP (Clinical Study Phase) Segment */
  buildCSP: (properties: Partial<CSP>) => this;
  /** Build CSR (Clinical Study Registration) Segment */
  buildCSR: (properties: Partial<CSR>) => this;
  /** Build CSS (Clinical Study Data Schedule) Segment */
  buildCSS: (properties: Partial<CSS>) => this;
  /** Build CTD (Contact Data) Segment */
  buildCTD: (properties: Partial<CTD>) => this;
  /** Build DG1 (Diagnosis) Segment */
  buildDG1: (properties: DG1) => this;
  /** Build DRG (Diagnosis Related Group) Segment */
  buildDRG: (properties: Partial<DRG>) => this;
  /** Build DSC (Continuation Pointer) Segment */
  buildDSC: (properties: DSC) => this;
  /** Build DSP (Display Data) Segment */
  buildDSP: (properties: DSP) => this;
  /** Build ERR (Error) Segment */
  buildERR: (properties: ERR) => this;
  /** Build EVN (Event Type) Segment */
  buildEVN: (properties: EVN) => this;
  /** Build FT1 (Financial Transaction) Segment */
  buildFT1: (properties: any) => this;
  /** Build GOL (Goal Detail) Segment */
  buildGOL: (properties: Partial<GOL>) => this;
  /** Build GT1 (Guarantor) Segment */
  buildGT1: (properties: any) => this;
  /** Build IAM (Patient Adverse Reaction Information) Segment */
  buildIAM: (properties: Partial<IAM>) => this;
  /** Build IN1 (Insurance) Segment */
  buildIN1: (properties: any) => this;
  /** Build IPC (Imaging Procedure Control) Segment */
  buildIPC: (properties: Partial<IPC>) => this;
  /** Build ISD (Interaction Status Detail) Segment */
  buildISD: (properties: Partial<ISD>) => this;
  /** Build ITM (Material Item Master) Segment */
  buildITM: (properties: Partial<ITM>) => this;
  /** Build IVT (Material Location) Segment */
  buildIVT: (properties: Partial<IVT>) => this;
  /** Build MFE (Master File Entry) Segment */
  buildMFE: (properties: Partial<MFE>) => this;
  /** Build MFI (Master File Identification) Segment */
  buildMFI: (properties: Partial<MFI>) => this;
  /** Build MRG (Merge Patient Info) Segment */
  buildMRG: (properties: any) => this;
  /** Build MSA (Acknowledgment) Segment */
  buildMSA: (properties: any) => this;
  /** Build MSH (Message Header) Segment */
  buildMSH: (properties: MSH) => this;
  /** Build NCK (System Clock) Segment */
  buildNCK: () => this;
  /** Build NK1 (Next of Kin) Segment */
  buildNK1: (properties: NK1) => this;
  /** Build NPU (Bed Status Update) Segment */
  buildNPU: (properties: NPU) => this;
  /** Build NSC (Network Change) Segment */
  buildNSC: (properties: NSC) => this;
  /** Build NST (Statistics) Segment */
  buildNST: (properties: any) => this;
  /** Build NTE (Notes and Comments) Segment */
  buildNTE: (properties: NTE) => this;
  /** Build OBR (Observation Request) Segment */
  buildOBR: (properties: OBR) => this;
  /** Build OBX (Observation/Result) Segment */
  buildOBX: (properties: OBX) => this;
  /** Build ODS (Dietary Orders) Segment */
  buildODS: (properties: Partial<ODS>) => this;
  /** Build ODT (Diet Tray Instructions) Segment */
  buildODT: (properties: Partial<ODT>) => this;
  /** Build OM1 (General Attributes of an Observation) Segment */
  buildOM1: (properties: Partial<OM1>) => this;
  /** Build OM2 (Numeric Observations) Segment */
  buildOM2: (properties: Partial<OM2>) => this;
  /** Build OM3 (Categorical Test/Observation) Segment */
  buildOM3: (properties: Partial<OM3>) => this;
  /** Build OM4 (Observations Requiring Specimens) Segment */
  buildOM4: (properties: Partial<OM4>) => this;
  /** Build OM5 (Observation Batteries) Segment */
  buildOM5: (properties: Partial<OM5>) => this;
  /** Build OM6 (Observations Copied from Other Observations) Segment */
  buildOM6: (properties: Partial<OM6>) => this;
  /** Build ORC (Common Order) Segment */
  buildORC: (properties: ORC) => this;
  /** Build PCR (Possible Causal Relationship) Segment */
  buildPCR: (properties: Partial<PCR>) => this;
  /** Build PD1 (Patient Additional Demographic) Segment */
  buildPD1: (properties: PD1) => this;
  /** Build PID (Patient Identification) Segment */
  buildPID: (properties: PID) => this;
  /** Build PR1 (Procedures) Segment */
  buildPR1: (properties: PR1) => this;
  /** Build PRA (Practitioner Detail) Segment */
  buildPRA: (properties: Partial<PRA>) => this;
  /** Build PRB (Problem Detail) Segment */
  buildPRB: (properties: Partial<PRB>) => this;
  /** Build PRD (Provider Data) Segment */
  buildPRD: (properties: Partial<PRD>) => this;
  /** Build PSH (Product Summary Header) Segment */
  buildPSH: (properties: Partial<PSH>) => this;
  /** Build PTH (Pathway) Segment */
  buildPTH: (properties: Partial<PTH>) => this;
  /** Build PV1 (Patient Visit) Segment */
  buildPV1: (properties: PV1) => this;
  /** Build QRD (Query Definition) Segment */
  buildQRD: (properties: QRD) => this;
  /** Build QRF (Query Filter) Segment */
  buildQRF: (properties: QRF) => this;
  /** Build RDF (Table Row Definition) Segment */
  buildRDF: (properties: Partial<RDF>) => this;
  /** Build RDT (Table Row Data) Segment */
  buildRDT: (properties: Partial<RDT>) => this;
  /** Build REL (Clinical Relationship) Segment */
  buildREL: (properties: Partial<REL>) => this;
  /** Build RGS (Resource Group) Segment */
  buildRGS: (properties: Partial<RGS>) => this;
  /** Build ROL (Role) Segment */
  buildROL: (properties: Partial<ROL>) => this;
  /** Build RX1 (Pharmacy/Treatment Order) Segment */
  buildRX1: (properties: RX1) => this;
  /** Build RXA (Pharmacy/Treatment Administration) Segment */
  buildRXA: (properties: Partial<RXA>) => this;
  /** Build RXD (Pharmacy/Treatment Dispense) Segment */
  buildRXD: (properties: Partial<RXD>) => this;
  /** Build RXE (Pharmacy/Treatment Encoded Order) Segment */
  buildRXE: (properties: Partial<RXE>) => this;
  /** Build RXG (Pharmacy/Treatment Give) Segment */
  buildRXG: (properties: Partial<RXG>) => this;
  /** Build RXO (Pharmacy/Treatment Order) Segment */
  buildRXO: (properties: Partial<RXO>) => this;
  /** Build RXR (Pharmacy/Treatment Route) Segment */
  buildRXR: (properties: Partial<RXR>) => this;
  /** Build SCH (Scheduling Activity Information) Segment */
  buildSCH: (properties: Partial<SCH>) => this;
  /** Build SFT (Software Segment) */
  buildSFT: (properties: Partial<SFT>) => this;
  /** Build SPM (Specimen) Segment */
  buildSPM: (properties: Partial<SPM>) => this;
  /** Build STF (Staff Identification) Segment */
  buildSTF: (properties: Partial<STF>) => this;
  /** Build STZ (Sterilization Parameter) Segment */
  buildSTZ: (properties: Partial<STZ>) => this;
  /** Build TXA (Transcription Document Header) Segment */
  buildTXA: (properties: Partial<TXA>) => this;
  /** Build UB1 (UB82 Data) Segment */
  buildUB1: (properties: UB1) => this;
  /** Build UB2 (UB92 Data) Segment */
  buildUB2: (properties: Partial<UB2>) => this;
  /** Build URD (Results/Update Definition) Segment */
  buildURD: (properties: URD) => this;
  /** Build URS (Unsolicited Selection) Segment */
  buildURS: (properties: URS) => this;
  /** Build VAR (Variance) Segment */
  buildVAR: (properties: Partial<VAR>) => this;
  /** Check the MSH Header for this Specification validation. */
  checkMSH: (properties: MSH) => boolean;
  /** Export compiled HL7 String */
  toString: () => string;
  /** Name of the HL7 Spec */
  version: string;
}
//#endregion
//#region src/utils/assertNumber.d.ts
/**
 * Assert Number on a Property
 * @since 1.0.0
 * @param props Property Object
 * @param name Property Name
 * @param min Min Number
 * @param max Max Number
 */
declare const assertNumber: (properties: Record<string, number>, name: string, min: number, max?: number) => void;
//#endregion
//#region src/declaration/deferred.d.ts
/**
 * @since 2.0.0
 */
interface Deferred<T = any> {
  promise: Promise<T>;
  reject: (reason?: any) => void;
  resolve: (value: PromiseLike<T> | T) => void;
}
//#endregion
//#region src/utils/createDeferred.d.ts
/**
 * Create Deferred
 * @since 2.0.0
 * @param noUncaught
 */
declare const createDeferred: <T = any>(noUncaught?: boolean) => Deferred<T>;
//#endregion
//#region src/utils/decodeHexString.d.ts
/**
 * Decode Hex String
 * @since 1.0.0
 * @param value
 */
declare const decodeHexString: (value: string) => string;
//#endregion
//#region src/utils/escapeForRegExp.d.ts
/**
 * Escape for RegEx Expressing
 * @since 1.0.0
 * @param value
 */
declare const escapeForRegExp: (value: string) => string;
//#endregion
//#region src/utils/expBackoff.d.ts
/**
 * Calculate exponential backoff/retry delay.
 * Where attempts >= 1, exp > 1
 * @example expBackoff(1000, 30000, attempts)
 *   ---------------------------------
 *    attempts | possible delay
 *   ----------+----------------------
 *        1    | 1000 to 2000
 *        2    | 1000 to 4000
 *        3    | 1000 to 8000
 *        4    | 1000 to 16000
 *        5    | 1000 to 30000
 *   ---------------------------------
 * Attempts required before max delay is possible = Math.ceil(Math.log(high/step) / Math.log(exp))
 * @since 1.0.0
 * @param step
 * @param high
 * @param attempts
 * @param exp
 */
declare const expBackoff: (step: number, high: number, attempts: number, exp?: number) => number;
//#endregion
//#region src/utils/ipAddress.d.ts
/**
 * Valid IPv4 Checker
 * @remarks Backed by Node's `net.isIPv4` for full RFC 791 coverage.
 * @since 1.0.0
 * @param ip
 */
declare const validIPv4: (ip: string) => boolean;
/**
 * Valid IPv6 Checker
 * @remarks Backed by Node's `net.isIPv6`. Accepts the full form
 * (`2001:0db8:85a3:0000:0000:8a2e:0370:7334`), shorthand notation
 * (`::1`, `fe80::1`, `2001:db8::1`), and IPv4-mapped IPv6 addresses
 * (`::ffff:192.168.1.1`). Bracketed forms (`[::1]`) and zone-id suffixes
 * (`fe80::1%eth0`) are stripped before validation.
 * @since 1.0.0
 * @param ip
 */
declare const validIPv6: (ip: string) => boolean;
/**
 * Detect IP family
 * @remarks Returns `4` for valid IPv4 literals, `6` for valid IPv6 literals,
 * or `0` for hostnames / FQDNs that should be resolved via DNS.
 * @since 4.0.0
 * @param value
 */
declare const detectIPFamily: (value: string) => 0 | 4 | 6;
//#endregion
//#region src/utils/is.d.ts
/**
 * Check to see if the message starts with the Batch (BHS) header segment.
 * @since 1.0.0
 * @param message
 */
declare const isBatch: (message: string) => boolean;
/**
 * Check to see if the message starts with a File Batch (FHS) header segment.
 * @param message
 */
declare const isFile: (message: string) => boolean;
/**
 * Is Number
 * @remarks Custom for this package.
 * @since 1.0.0
 * @param value
 */
declare const isHL7Number: (value: number | string) => boolean;
/**
 * Is String
 * @remarks Custom for this package.
 * @since 1.0.0
 * @param value
 */
declare const isHL7String: (value: any) => boolean;
//#endregion
//#region src/utils/randomString.d.ts
/**
 * Generate a random string
 * @since 1.0.0
 * @default 20
 * @param length
 */
declare const randomString: (length?: number) => string;
//#endregion
//#region src/hl7/base.d.ts
/**
 * Base Class of an HL7 Specification
 * @since 1.0.0
 */
declare class HL7_BASE extends EventEmitter implements HL7_SPEC {
  /**
   * Options for the Hl7 Message.
   * @since 4.0.0
   * @readonly */
  readonly _opt: ClientBuilderOptions;
  name: string;
  /** Version
   * @since 1.0.0 */
  version: string;
  /**
   * Get whether the last segment build produced any validation errors.
   * @since 4.0.0
   */
  get hasValidationErrors(): boolean;
  /**
   * Max length of ADD Segment.
   * Changes based on extended class.
   * @since 4.0.0
   * @protected */
  protected _maxAddSegmentLength: number | undefined;
  /**
   * @since 4.0.0
   * @protected */
  protected _message: Message;
  /**
   * The Current Segment we are working on.
   * @since 4.0.0
   * @protected
   */
  protected _segment: Segment;
  /**
   * Regardless if errors are soft, always throw and exception or deviation from the rule.
   * @since 4.0.0
   * @private
   */
  private readonly hardError;
  /**
   * Create a new HL7 Message
   * @since 4.0.0
   */
  constructor(properties?: ClientBuilderOptions);
  /**
   *
   * @param props
   */
  buildACC(properties: ACC): this;
  /**
   * Build the ADD Segment
   * @remarks Add an ADD Segment to the HL7 Message
   * @param props
   */
  buildADD(properties: ADD): this;
  /** Build AIG (Appointment Information - General) Segment */
  buildAIG(properties: Partial<AIG>): this;
  /** Build AIL (Appointment Information - Location) Segment */
  buildAIL(properties: Partial<AIL>): this;
  /** Build AIP (Appointment Information - Personnel) Segment */
  buildAIP(properties: Partial<AIP>): this;
  /** Build AIS (Appointment Information - Service) Segment */
  buildAIS(properties: Partial<AIS>): this;
  /** Build AL1 (Allergy Information) Segment */
  buildAL1(properties: Partial<AL1>): this;
  /** Build APR (Appointment Preferences) Segment */
  buildAPR(properties: Partial<APR>): this;
  /**
   *
   * @since 4.0.0
   * @param props
   */
  buildBLG(properties: BLG): this;
  /** Build BPX (Blood Product Dispense Status) Segment */
  buildBPX(properties: Partial<BPX>): this;
  /** Build BTX (Blood Product Transfusion/Disposition) Segment */
  buildBTX(properties: Partial<BTX>): this;
  /** Build CSP (Clinical Study Phase) Segment */
  buildCSP(properties: Partial<CSP>): this;
  /** Build CSR (Clinical Study Registration) Segment */
  buildCSR(properties: Partial<CSR>): this;
  /** Build CSS (Clinical Study Data Schedule) Segment */
  buildCSS(properties: Partial<CSS>): this;
  /** Build CTD (Contact Data) Segment */
  buildCTD(properties: Partial<CTD>): this;
  /**
   *
   * @since 4.0.0
   * @param props
   */
  buildDG1(properties: DG1): this;
  /** Build DRG (Diagnosis Related Group) Segment */
  buildDRG(properties: Partial<DRG>): this;
  /**
   *
   * @since 4.0.0
   * @param props
   */
  buildDSC(properties: any): this;
  /**
   *
   * @since 4.0.0
   * @param props
   */
  buildDSP(properties: any): this;
  /**
   *
   * @since 4.0.0
   * @param props
   */
  buildERR(properties: any): this;
  /**
   *
   * @since 4.0.0
   * @param props
   */
  buildEVN(properties: Partial<EVN>): this;
  /**
   *
   * @since 4.0.0
   * @param props
   */
  buildFT1(properties: Partial<FT1>): this;
  /** Build GOL (Goal Detail) Segment */
  buildGOL(properties: Partial<GOL>): this;
  /**
   *
   * @since 4.0.0
   * @param props
   */
  buildGT1(properties: Partial<GT1>): this;
  /** Build IAM (Patient Adverse Reaction Information) Segment */
  buildIAM(properties: Partial<IAM>): this;
  /**
   *
   * @since 4.0.0
   * @param props
   */
  buildIN1(properties: Partial<IN1>): this;
  /** Build IPC (Imaging Procedure Control) Segment */
  buildIPC(properties: Partial<IPC>): this;
  /** Build ISD (Interaction Status Detail) Segment */
  buildISD(properties: Partial<ISD>): this;
  /** Build ITM (Material Item Master) Segment */
  buildITM(properties: Partial<ITM>): this;
  /** Build IVT (Material Location) Segment */
  buildIVT(properties: Partial<IVT>): this;
  /** Build MFE (Master File Entry) Segment */
  buildMFE(properties: Partial<MFE>): this;
  /** Build MFI (Master File Identification) Segment */
  buildMFI(properties: Partial<MFI>): this;
  /**
   *
   * @since 4.0.0
   * @param props
   */
  buildMRG(properties: Partial<MRG>): this;
  /**
   *
   * @since 4.0.0
   * @param props
   */
  buildMSA(properties: Partial<MSA>): this;
  /**
   * Build MSH Header
   * @remarks Add the required fields based on the spec chosen.
   * @since 1.0.0
   * @return void
   * @param props
   */
  buildMSH(properties: Partial<MSH>): this;
  /**
   *
   * @since 4.0.0
   */
  buildNCK(): this;
  /**
   *
   * @since 4.0.0
   * @param props
   */
  buildNK1(properties: Partial<NK1>): this;
  /**
   *
   * @since 4.0.0
   * @param props
   */
  buildNPU(properties: Partial<NPU>): this;
  /**
   *
   * @since 4.0.0
   * @param props
   */
  buildNSC(properties: Partial<NSC>): this;
  /**
   *
   * @since 4.0.0
   * @param props
   */
  buildNST(properties: NST): this;
  /**
   *
   * @since 4.0.0
   * @param props
   */
  buildNTE(properties: Partial<NTE>): this;
  /**
   *
   * @since 4.0.0
   * @param props
   */
  buildOBR(properties: Partial<OBR>): this;
  /**
   *
   * @since 4.0.0
   * @param props
   */
  buildOBX(properties: Partial<OBX>): this;
  /** Build ODS (Dietary Orders, Supplements, and Preferences) Segment */
  buildODS(properties: Partial<ODS>): this;
  /** Build ODT (Diet Tray Instructions) Segment */
  buildODT(properties: Partial<ODT>): this;
  /** Build OM1 (General Attributes of an Observation) Segment */
  buildOM1(properties: Partial<OM1>): this;
  /** Build OM2 (Numeric Observations) Segment */
  buildOM2(properties: Partial<OM2>): this;
  /** Build OM3 (Categorical Test/Observation) Segment */
  buildOM3(properties: Partial<OM3>): this;
  /** Build OM4 (Observations Requiring Specimens) Segment */
  buildOM4(properties: Partial<OM4>): this;
  /** Build OM5 (Observation Batteries) Segment */
  buildOM5(properties: Partial<OM5>): this;
  /** Build OM6 (Observations Copied from Other Observations) Segment */
  buildOM6(properties: Partial<OM6>): this;
  /**
   *
   * @since 4.0.0
   * @param props
   */
  buildORC(properties: Partial<ORC>): this;
  /** Build PCR (Possible Causal Relationship) Segment */
  buildPCR(properties: Partial<PCR>): this;
  /**
   *
   * @since 4.0.0
   * @param props
   */
  buildPD1(properties: Partial<PD1>): this;
  /**
   *
   * @since 4.0.0
   * @param props
   */
  buildPID(properties: Partial<PID>): this;
  /**
   *
   * @since 4.0.0
   * @param props
   */
  buildPR1(properties: Partial<PR1>): this;
  /** Build PRA (Practitioner Detail) Segment */
  buildPRA(properties: Partial<PRA>): this;
  /** Build PRB (Problem Detail) Segment */
  buildPRB(properties: Partial<PRB>): this;
  /** Build PRD (Provider Data) Segment */
  buildPRD(properties: Partial<PRD>): this;
  /** Build PSH (Product Summary Header) Segment */
  buildPSH(properties: Partial<PSH>): this;
  /** Build PTH (Pathway) Segment */
  buildPTH(properties: Partial<PTH>): this;
  /**
   *
   * @since 4.0.0
   * @param props
   */
  buildPV1(properties: Partial<PV1>): this;
  /**
   *
   * @since 4.0.0
   * @param props
   */
  buildQRD(properties: Partial<QRD>): this;
  /**
   *
   * @since 4.0.0
   * @param props
   */
  buildQRF(properties: Partial<QRF>): this;
  /** Build RDF (Table Row Definition) Segment */
  buildRDF(properties: Partial<RDF>): this;
  /** Build RDT (Table Row Data) Segment */
  buildRDT(properties: Partial<RDT>): this;
  /** Build REL (Clinical Relationship) Segment */
  buildREL(properties: Partial<REL>): this;
  /** Build RGS (Resource Group) Segment */
  buildRGS(properties: Partial<RGS>): this;
  /** Build ROL (Role) Segment */
  buildROL(properties: Partial<ROL>): this;
  /**
   *
   * @since 4.0.0
   * @param props
   */
  buildRX1(properties: Partial<RX1>): this;
  /** Build RXA (Pharmacy/Treatment Administration) Segment */
  buildRXA(properties: Partial<RXA>): this;
  /** Build RXD (Pharmacy/Treatment Dispense) Segment */
  buildRXD(properties: Partial<RXD>): this;
  /** Build RXE (Pharmacy/Treatment Encoded Order) Segment */
  buildRXE(properties: Partial<RXE>): this;
  /** Build RXG (Pharmacy/Treatment Give) Segment */
  buildRXG(properties: Partial<RXG>): this;
  /** Build RXO (Pharmacy/Treatment Order) Segment */
  buildRXO(properties: Partial<RXO>): this;
  /** Build RXR (Pharmacy/Treatment Route) Segment */
  buildRXR(properties: Partial<RXR>): this;
  /** Build SCH (Scheduling Activity Information) Segment */
  buildSCH(properties: Partial<SCH>): this;
  /**
   * Build any HL7 segment by name from its generated `SegmentSpec`.
   *
   * @remarks
   * Universal chainable builder for every segment in the metadata catalogue
   * (~187 segments × 11 versions). Field-level R/O/B/W/D/X usage codes are
   * enforced per the HL7 v2 spec for `this.version`:
   * - W / X / "field not in this version" => `HL7ValidationError`
   * - R + missing => `HL7ValidationError`
   * - B => deprecation warning (value still serializes)
   * - D => `dependsOn` must resolve when a value is provided
   *
   * Field values may be keyed in `props` either as `<segname>_<num>` (e.g.
   * `ecd_1`), as the bare numeric string `"1"`, or as the number `1`.
   *
   * For MSH specifically, use `buildMSH` instead — MSH has special framing
   * rules (separator characters, single-occurrence guard) that this generic
   * builder does not enforce.
   *
   * @example
   * ```ts
   * new HL7_2_8()
   *   .buildMSH({ msh_9_1: "ADT", msh_9_2: "A01", msh_10: "X", msh_11_1: "P" })
   *   .buildSegment("ECD", { ecd_1: "1", ecd_2: "RC" })
   *   .toString();
   * ```
   *
   * @since 4.0.0
   */
  buildSegment(name: string, properties?: Record<string, unknown>): this;
  /** Build SFT (Software Segment) */
  buildSFT(properties: Partial<SFT>): this;
  /** Build SPM (Specimen) Segment */
  buildSPM(properties: Partial<SPM>): this;
  /** Build STF (Staff Identification) Segment */
  buildSTF(properties: Partial<STF>): this;
  /** Build STZ (Sterilization Parameter) Segment */
  buildSTZ(properties: Partial<STZ>): this;
  /** Build TXA (Transcription Document Header) Segment */
  buildTXA(properties: Partial<TXA>): this;
  /**
   *
   * @since 4.0.0
   * @param props
   */
  buildUB1(properties: Partial<UB1>): this;
  /** Build UB2 (UB92 Data) Segment */
  buildUB2(properties: Partial<UB2>): this;
  /**
   *
   * @since 4.0.0
   * @param props
   */
  buildURD(properties: Partial<URD>): this;
  /**
   *
   * @since 4.0.0
   * @param props
   */
  buildURS(properties: Partial<URS>): this;
  /** Build VAR (Variance) Segment */
  buildVAR(properties: Partial<VAR>): this;
  /**
   * Check MSH Header Properties
   * @since 1.0.0
   * @return boolean
   * @param _props
   */
  checkMSH(_properties: MSH): boolean;
  /**
   *
   */
  headerExists(): void;
  /**
   * Set the date.
   * @param date
   * @param length
   */
  setDate(date?: Date, length?: DateLength): HL7Date;
  /** Return Message Object
   * @since 4.0.0
   */
  toMessage(): Message;
  /**
   * Return the string of the entire HL7 message.
   * @since 4.0.0
   */
  toString(): string;
  /**
   * Reject building a segment that is not part of the current spec version.
   *
   * @remarks
   * Used at the top of segment-spec-driven `buildXXX` methods. Throws
   * unconditionally (regardless of `hardError`) when the current builder's
   * version is not in `spec.versions` — e.g. attempting to build ECD on an
   * HL7 v2.3.1 builder, since ECD did not exist before v2.4.
   *
   * @since 4.0.0
   */
  protected _assertSegmentInVersion(spec: SegmentSpec): void;
  /**
   * Build the ACC Segment
   * @remarks Add an ACC Segment to the HL7 Message
   * @since 4.0.0
   * @return void
   * @param _props
   */
  protected _buildACC(_properties: ACC): void;
  protected _buildAIG(_properties: Partial<AIG>): void;
  protected _buildAIL(_properties: Partial<AIL>): void;
  protected _buildAIP(_properties: Partial<AIP>): void;
  protected _buildAIS(_properties: Partial<AIS>): void;
  protected _buildAL1(_properties: Partial<AL1>): void;
  protected _buildAPR(_properties: Partial<APR>): void;
  /**
   * @since 4.0.0
   * @return void
   * @param _props
   */
  protected _buildBLG(_properties: BLG): void;
  protected _buildBPX(_properties: Partial<BPX>): void;
  protected _buildBTX(_properties: Partial<BTX>): void;
  protected _buildCSP(_properties: Partial<CSP>): void;
  protected _buildCSR(_properties: Partial<CSR>): void;
  protected _buildCSS(_properties: Partial<CSS>): void;
  protected _buildCTD(_properties: Partial<CTD>): void;
  /**
   * @since 4.0.0
   * @return void
   * @param _props
   */
  protected _buildDG1(_properties: DG1): void;
  protected _buildDRG(_properties: Partial<DRG>): void;
  /**
   * @since 4.0.0
   * @return void
   * @param _props
   */
  protected _buildDSC(_properties: DSC): void;
  /**
   * @since 4.0.0
   * @return void
   * @param props
   */
  protected _buildDSP(properties: Partial<DSP>): void;
  /**
   * @since 4.0.0
   * @return void
   * @param _props
   */
  protected _buildERR(_properties: ERR): void;
  /**
   * @since 4.0.0
   * @return void
   * @param _props
   */
  protected _buildEVN(_properties: EVN): void;
  /**
   * @since 4.0.0
   * @return void
   * @param _props
   */
  protected _buildFT1(_properties: Partial<FT1>): void;
  protected _buildGOL(_properties: Partial<GOL>): void;
  /**
   * @since 4.0.0
   * @return void
   * @param _props
   */
  protected _buildGT1(_properties: Partial<GT1>): void;
  protected _buildIAM(_properties: Partial<IAM>): void;
  /**
   * @since 4.0.0
   * @return void
   * @param _props
   */
  protected _buildIN1(_properties: Partial<IN1>): void;
  protected _buildIPC(_properties: Partial<IPC>): void;
  protected _buildISD(_properties: Partial<ISD>): void;
  protected _buildITM(_properties: Partial<ITM>): void;
  protected _buildIVT(_properties: Partial<IVT>): void;
  protected _buildMFE(_properties: Partial<MFE>): void;
  protected _buildMFI(_properties: Partial<MFI>): void;
  /**
   * @since 4.0.0
   * @return void
   * @param _props
   */
  protected _buildMRG(_properties: Partial<MRG>): void;
  /**
   * @since 4.0.0
   * @return void
   * @param _props
   */
  protected _buildMSA(_properties: Partial<MSA>): void;
  /**
   * Build the MSH Segment
   * @remarks Add an MSH Segment to the HL7 Message
   * @since 4.0.0
   * @return void
   * @param _props
   */
  protected _buildMSH(_properties: Partial<MSH>): void;
  /**
   * @since 4.0.0
   * @return void
   */
  protected _buildNCK(): void;
  /**
   * @since 4.0.0
   * @return void
   * @param _props
   */
  protected _buildNK1(_properties: Partial<NK1>): void;
  /**
   * @since 4.0.0
   * @return void
   * @param _props
   */
  protected _buildNPU(_properties: Partial<NPU>): void;
  /**
   * @since 4.0.0
   * @return void
   * @param _props
   */
  protected _buildNSC(_properties: Partial<NSC>): void;
  /**
   * @since 4.0.0
   * @return void
   * @param props
   */
  protected _buildNST(properties: NST): void;
  /**
   * @since 4.0.0
   * @return void
   * @param _props
   */
  protected _buildNTE(_properties: Partial<NTE>): void;
  /**
   * @since 4.0.0
   * @return void
   * @param _props
   */
  protected _buildOBR(_properties: Partial<OBR>): void;
  /**
   * @since 4.0.0
   * @return void
   * @param _props
   */
  protected _buildOBX(_properties: Partial<OBX>): void;
  protected _buildODS(_properties: Partial<ODS>): void;
  protected _buildODT(_properties: Partial<ODT>): void;
  protected _buildOM1(_properties: Partial<OM1>): void;
  protected _buildOM2(_properties: Partial<OM2>): void;
  protected _buildOM3(_properties: Partial<OM3>): void;
  protected _buildOM4(_properties: Partial<OM4>): void;
  protected _buildOM5(_properties: Partial<OM5>): void;
  protected _buildOM6(_properties: Partial<OM6>): void;
  /**
   * @since 4.0.0
   * @return void
   * @param _props
   */
  protected _buildORC(_properties: Partial<ORC>): void;
  protected _buildPCR(_properties: Partial<PCR>): void;
  /**
   * @since 4.0.0
   * @return void
   * @param _props
   */
  protected _buildPD1(_properties: Partial<PD1>): void;
  /**
   * @since 4.0.0
   * @return void
   * @param _props
   */
  protected _buildPID(_properties: Partial<PID>): void;
  /**
   * @since 4.0.0
   * @return void
   * @param _props
   */
  protected _buildPR1(_properties: Partial<PR1>): void;
  protected _buildPRA(_properties: Partial<PRA>): void;
  protected _buildPRB(_properties: Partial<PRB>): void;
  protected _buildPRD(_properties: Partial<PRD>): void;
  protected _buildPSH(_properties: Partial<PSH>): void;
  protected _buildPTH(_properties: Partial<PTH>): void;
  /**
   * @since 4.0.0
   * @return void
   * @param _props
   */
  protected _buildPV1(_properties: Partial<PV1>): void;
  /**
   * @since 4.0.0
   * @return void
   * @param _props
   */
  protected _buildQRD(_properties: Partial<QRD>): void;
  /**
   * @since 4.0.0
   * @return void
   * @param _props
   */
  protected _buildQRF(_properties: Partial<QRF>): void;
  protected _buildRDF(_properties: Partial<RDF>): void;
  protected _buildRDT(_properties: Partial<RDT>): void;
  protected _buildREL(_properties: Partial<REL>): void;
  protected _buildRGS(_properties: Partial<RGS>): void;
  protected _buildROL(_properties: Partial<ROL>): void;
  /**
   * @since 4.0.0
   * @return void
   * @param _props
   */
  protected _buildRX1(_properties: Partial<RX1>): void;
  protected _buildRXA(_properties: Partial<RXA>): void;
  protected _buildRXD(_properties: Partial<RXD>): void;
  protected _buildRXE(_properties: Partial<RXE>): void;
  protected _buildRXG(_properties: Partial<RXG>): void;
  protected _buildRXO(_properties: Partial<RXO>): void;
  protected _buildRXR(_properties: Partial<RXR>): void;
  protected _buildSCH(_properties: Partial<SCH>): void;
  protected _buildSFT(_properties: Partial<SFT>): void;
  protected _buildSPM(_properties: Partial<SPM>): void;
  protected _buildSTF(_properties: Partial<STF>): void;
  protected _buildSTZ(_properties: Partial<STZ>): void;
  protected _buildTXA(_properties: Partial<TXA>): void;
  /**
   * @since 4.0.0
   * @return void
   * @param _props
   */
  protected _buildUB1(_properties: Partial<UB1>): void;
  protected _buildUB2(_properties: Partial<UB2>): void;
  /**
   * @since 4.0.0
   * @return void
   * @param _props
   */
  protected _buildURD(_properties: Partial<URD>): void;
  /**
   * @since 4.0.0
   * @return void
   * @param _props
   */
  protected _buildURS(_properties: Partial<URS>): void;
  protected _buildVAR(_properties: Partial<VAR>): void;
  /**
   * Convert a typed component object (e.g. `{ streetAddress: "...", city: "..." }`)
   * into the HL7 `^`-delimited composite string the wire format expects, while
   * validating each piece against its `ComponentSpec`.
   *
   * @remarks
   * Lookup precedence for each component, in order:
   *   1. `obj[<num>]` — numeric key, e.g. `1`.
   *   2. `obj["<num>"]` — numeric-as-string.
   *   3. Any key matching `*_<num>` (e.g. `xad_1`, `xpn_3`).
   *   4. The camelCase rendering of the component name (e.g.
   *      `"Street Address"` → `streetAddress`, `"Zip Or Postal Code"` →
   *      `zipOrPostalCode`).
   *
   * Per-component validation enforced here:
   *   - `R` => required, throws if unset.
   *   - `W` / `X` => withdrawn / not supported, throws if a value is provided.
   *   - `length` => max-length check.
   * Trailing empty components are trimmed so the wire output stays clean
   * (e.g. an XAD with only Street/City emits `Street^^City`, not
   * `Street^^City^^^…^^`).
   *
   * @since 4.0.0
   */
  protected _composeFromObject(object: Record<string, unknown>, components: readonly ComponentSpec[], fieldPath: string): string;
  /**
   * Initialize a new segment on the message and set it as the current segment.
   * @since 4.0.0
   */
  protected _startSegment(name: string): void;
  /**
   * Spec-driven field setter that consults a `FieldSpec`'s per-version
   * `usage` map (R/O/B/W/D/X) and translates it into validation rules.
   *
   * @remarks
   * Behavior per HL7 usage code for `this.version`:
   * - usage missing for the version => hard error: field is not part of that
   *   version of the spec.
   * - `"W"` (Withdrawn) or `"X"` (Not Supported) => hard error if a value is
   *   provided. Always throws regardless of `hardError`.
   * - `"R"` (Required) => sets `required: true` on the rule.
   * - `"D"` (Dependent/Conditional) => requires `field.dependsOn` to resolve.
   * - `"B"` (Backward Compatibility) => sets `deprecated: true` (warns, value
   *   still serializes).
   * - `"O"` (Optional) => no extra constraint.
   *
   * @see https://hl7-definition.caristix.com/v2/ for the per-version codes.
   * @since 4.0.0
   */
  protected _validatorSetField(spec: SegmentSpec, fieldNumber: number, value: any, overrides?: Partial<ValidationRule>): string[];
  /**
   * @since 4.0.0
   */
  protected _validatorSetValue(fieldPath: string, value: any, rules?: ValidationRule): string[];
  private _compareVersions;
  private _validatorCheckDependency;
  private _validatorCheckValue;
  private _validatorIsVersionCompatible;
  private _validatorNormalize;
  private _validatorThrowError;
  private _validatorWarn;
}
//#endregion
//#region src/hl7/2.1/types.d.ts
interface ClientBuilderOptions_Hl7_2_1 extends ClientBuilderOptions {
  table_0001?: string[];
  table_0002?: string[];
  table_0003?: string[];
  table_0004?: string[];
  table_0007?: string[];
  table_0008?: string[];
  table_0062?: string[];
  table_0074?: string[];
  table_0076?: string[];
  table_0078?: string[];
  table_0085?: string[];
  table_0100?: string[];
  table_0116?: string[];
  table_0119?: string[];
  table_0121?: string[];
  table_0123?: string[];
  table_0125?: string[];
  table_0127?: string[];
  table_0128?: string[];
  table_0136?: string[];
}
//#endregion
//#region src/hl7/2.1/index.d.ts
/**
 * Hl7 Version 2.1
 * @remarks Used to build an HL7 based off the HL7 2.1 Specification.
 * @since 1.0.0
 * @extends HL7_BASE
 * @example
 * ```ts
 * const message = new HL7_2_1();
 *
 * message.buildMSH({
 *  msh_9: "ACK",
 *  msh_10: "12345",
 *  msh_11: "T",
 * });
 *
 * Will generate: MSH|^~\&||||||20081231||ACK|12345|T|2.1
 *
 * ```
 */
declare class HL7_2_1 extends HL7_BASE {
  protected _table_0001: string[];
  protected _table_0002: string[];
  protected _table_0003: string[];
  protected _table_0004: string[];
  protected _table_0007: string[];
  protected _table_0008: string[];
  protected _table_0062: string[];
  protected _table_0074: string[];
  protected _table_0076: string[];
  protected _table_0078: string[];
  protected _table_0085: string[];
  protected _table_0100: string[];
  protected _table_0116: string[];
  protected _table_0119: string[];
  protected _table_0121: string[];
  protected _table_0123: string[];
  protected _table_0125: string[];
  /**
   *
   * @param props
   */
  constructor(properties?: ClientBuilderOptions_Hl7_2_1);
  /**
   * Build ACC Segment
   * @param props
   */
  protected _buildACC(properties: Partial<HL7_2_1_ACC>): void;
  /**
   *
   * @param props
   * @protected
   */
  protected _buildBLG(properties: Partial<HL7_2_1_BLG>): void;
  /**
   *
   * @param props
   * @protected
   */
  protected _buildDG1(properties: Partial<HL7_2_1_DG1>): void;
  protected _buildDSC(properties: Partial<HL7_2_1_DSC>): void;
  protected _buildERR(properties: Partial<HL7_2_1_ERR>): void;
  protected _buildEVN(properties: Partial<HL7_2_1_EVN>): void;
  protected _buildFT1(properties: Partial<HL7_2_1_FT1>): void;
  protected _buildGT1(properties: Partial<HL7_2_1_GT1>): void;
  protected _buildIN1(properties: Partial<HL7_2_1_IN1>): void;
  protected _buildMRG(properties: Partial<HL7_2_1_MRG>): void;
  protected _buildMSA(properties: Partial<HL7_2_1_MSA>): void;
  /**
   * Build HL7 MSH Segment
   * @since 1.0.0
   * @param props
   */
  protected _buildMSH(properties: Partial<HL7_2_1_MSH>): void;
  protected _buildNK1(properties: Partial<HL7_2_1_NK1>): void;
  protected _buildNPU(properties: Partial<HL7_2_1_NPU>): void;
  protected _buildNSC(properties: Partial<HL7_2_1_NSC>): void;
  protected _buildNTE(properties: Partial<HL7_2_1_NTE>): void;
  protected _buildOBR(properties: Partial<HL7_2_1_OBR>): void;
  protected _buildOBX(properties: Partial<HL7_2_1_OBX>): void;
  protected _buildORC(properties: Partial<HL7_2_1_ORC>): void;
  protected _buildPID(properties: Partial<HL7_2_1_PID>): void;
  protected _buildPR1(properties: Partial<HL7_2_1_PR1>): void;
  protected _buildPV1(properties: Partial<HL7_2_1_PV1>): void;
  protected _buildQRD(properties: Partial<HL7_2_1_QRD>): void;
  protected _buildQRF(properties: Partial<HL7_2_1_QRF>): void;
  protected _buildRX1(properties: Partial<HL7_2_1_RX1>): void;
  protected _buildUB1(properties: Partial<HL7_2_1_UB1>): void;
  protected _buildURD(properties: Partial<HL7_2_1_URD>): void;
  protected _buildURS(properties: Partial<HL7_2_1_URS>): void;
}
//#endregion
//#region src/hl7/2.2/msh.d.ts
/**
 * HL7 2.2 MSH Specification
 * @since 4.0.0
 */
interface HL7_2_2_MSH {
  /** Message Control ID (max 20 chars)
   * @default Random string */
  msh_10?: string;
  /** Processing ID: P=Production, T=Test */
  msh_11?: "P" | "T";
  /** Sending Application */
  msh_3?: string;
  /** Sending Facility */
  msh_4?: string;
  /** Receiving Application */
  msh_5?: string;
  /** Receiving Facility */
  msh_6?: string;
  /** Message Date/Time */
  msh_7?: Date;
  /** Security */
  msh_8?: string;
  /** Message Code (e.g. "ADT") */
  msh_9_1: string;
  /** Trigger Event (e.g. "A01") */
  msh_9_2: string;
  receivingApplication?: string;
  receivingFacility?: string;
  sendingApplication?: string;
  sendingFacility?: string;
}
//#endregion
//#region src/hl7/2.2/types.d.ts
interface ClientBuilderOptions_Hl7_2_2 extends ClientBuilderOptions_Hl7_2_1 {
  table_0326?: string[];
}
//#endregion
//#region src/hl7/2.2/index.d.ts
/**
 * Hl7 Specification Version 2.2
 * @remarks Used to build HL7 messages following the 2.2 specification.
 * @since 1.0.0
 */
declare class HL7_2_2 extends HL7_2_1 {
  protected _table_0127: string[];
  protected _table_0128: string[];
  protected _table_0136: string[];
  protected _table_0326: string[];
  constructor(properties?: ClientBuilderOptions_Hl7_2_2);
  /**
   * Check MSH Header Properties for HL7 2.2
   * @since 1.0.0
   */
  checkMSH(msh: HL7_2_2_MSH): boolean;
  protected _buildAL1(properties: Partial<HL7_2_2_AL1>): void;
  protected _buildMFE(properties: Partial<HL7_2_2_MFE>): void;
  protected _buildMFI(properties: Partial<HL7_2_2_MFI>): void;
  protected _buildMSH(properties: Partial<HL7_2_1_MSH>): void;
  protected _buildOBR(properties: Partial<HL7_2_1_OBR>): void;
  protected _buildOBX(properties: Partial<HL7_2_1_OBX>): void;
  protected _buildODS(properties: Partial<HL7_2_2_ODS>): void;
  protected _buildODT(properties: Partial<HL7_2_2_ODT>): void;
  protected _buildORC(properties: Partial<HL7_2_1_ORC>): void;
  protected _buildPID(properties: Partial<HL7_2_1_PID>): void;
  protected _buildPV1(properties: Partial<HL7_2_1_PV1>): void;
  protected _buildRXA(properties: Partial<HL7_2_2_RXA>): void;
  protected _buildRXD(properties: Partial<HL7_2_2_RXD>): void;
  protected _buildRXE(properties: Partial<HL7_2_2_RXE>): void;
  protected _buildRXG(properties: Partial<HL7_2_2_RXG>): void;
  protected _buildRXO(properties: Partial<HL7_2_2_RXO>): void;
  protected _buildRXR(properties: Partial<HL7_2_2_RXR>): void;
  protected _buildSTF(properties: Partial<HL7_2_2_STF>): void;
  protected _buildUB2(properties: Partial<HL7_2_2_UB2>): void;
}
//#endregion
//#region src/hl7/2.3/msh.d.ts
/**
 * HL7 2.3 MSH Specification
 * @since 4.0.0
 */
interface HL7_2_3_MSH extends HL7_2_2_MSH {
  /** Processing ID: D=Debugging, P=Production, T=Test */
  msh_11_1: "D" | "P" | "T";
  /** Processing Mode */
  msh_11_2?: "" | "A" | "I" | "R";
  /** MSH.13 - Sequence Number */
  msh_13?: string;
  /** MSH.14 - Continuation Pointer */
  msh_14?: string;
  /** MSH.15 - Accept Acknowledgment Type */
  msh_15?: "AL" | "ER" | "NE" | "SU";
  /** MSH.16 - Application Acknowledgment Type */
  msh_16?: "AL" | "ER" | "NE" | "SU";
  /** MSH.17 - Country Code */
  msh_17?: string;
  /** MSH.18 - Character Set */
  msh_18?: string;
}
//#endregion
//#region src/hl7/2.3/types.d.ts
interface ClientBuilderOptions_Hl7_2_3 extends ClientBuilderOptions_Hl7_2_2 {
  table_0155?: string[];
}
//#endregion
//#region src/hl7/2.3/index.d.ts
/**
 * Hl7 Specification Version 2.3
 * @remarks Used to build HL7 messages following the 2.3 specification.
 * @since 1.0.0
 */
declare class HL7_2_3 extends HL7_2_2 {
  protected _table_0155: string[];
  constructor(properties?: ClientBuilderOptions_Hl7_2_3);
  /**
   * Check MSH Header Properties for HL7 2.3
   * @since 1.0.0
   */
  checkMSH(msh: HL7_2_3_MSH): boolean;
  protected _buildAIG(properties: Partial<HL7_2_3_AIG>): void;
  protected _buildAIL(properties: Partial<HL7_2_3_AIL>): void;
  protected _buildAIP(properties: Partial<HL7_2_3_AIP>): void;
  protected _buildAIS(properties: Partial<HL7_2_3_AIS>): void;
  protected _buildAPR(properties: Partial<HL7_2_3_APR>): void;
  protected _buildCSP(properties: Partial<HL7_2_3_CSP>): void;
  protected _buildCSR(properties: Partial<HL7_2_3_CSR>): void;
  protected _buildCSS(properties: Partial<HL7_2_3_CSS>): void;
  protected _buildCTD(properties: Partial<HL7_2_3_CTD>): void;
  protected _buildMSH(properties: Partial<HL7_2_1_MSH>): void;
  protected _buildNK1(properties: Partial<HL7_2_1_NK1>): void;
  protected _buildOBR(properties: Partial<HL7_2_1_OBR>): void;
  protected _buildOBX(properties: Partial<HL7_2_1_OBX>): void;
  protected _buildORC(properties: Partial<HL7_2_1_ORC>): void;
  protected _buildPCR(properties: Partial<HL7_2_3_PCR>): void;
  protected _buildPD1(properties: Partial<HL7_2_3_PD1>): void;
  protected _buildPID(properties: Partial<HL7_2_1_PID>): void;
  protected _buildPRA(properties: Partial<HL7_2_3_PRA>): void;
  protected _buildPRD(properties: Partial<HL7_2_3_PRD>): void;
  protected _buildPSH(properties: Partial<HL7_2_3_PSH>): void;
  protected _buildRDF(properties: Partial<HL7_2_3_RDF>): void;
  protected _buildRDT(properties: Partial<HL7_2_3_RDT>): void;
  protected _buildRGS(properties: Partial<HL7_2_3_RGS>): void;
  protected _buildROL(properties: Partial<HL7_2_3_ROL>): void;
  protected _buildSCH(properties: Partial<HL7_2_3_SCH>): void;
  protected _buildVAR(properties: Partial<HL7_2_3_VAR>): void;
}
//#endregion
//#region src/hl7/tables/0356.d.ts
declare const TABLE_0356: string[];
//#endregion
//#region src/hl7/2.3.1/msh.d.ts
/** HL7 2.3.1 MSH - extends 2.3 with fields 19-20 */
interface HL7_2_3_1_MSH extends HL7_2_3_MSH {
  /** MSH.19 - Principal Language of Message */
  msh_19?: string;
  /** MSH.20 - Alternate Character Set Handling Scheme */
  msh_20?: Table0356Value;
}
type Table0356Value = (typeof TABLE_0356)[number];
//#endregion
//#region src/hl7/2.3.1/types.d.ts
interface ClientBuilderOptions_Hl7_2_3_1 extends ClientBuilderOptions_Hl7_2_3 {
  table_0356?: string[];
}
//#endregion
//#region src/hl7/2.3.1/index.d.ts
/**
 * Hl7 Specification Version 2.3.1
 * @since 1.0.0
 */
declare class HL7_2_3_1 extends HL7_2_3 {
  protected _table_0356: string[];
  constructor(properties?: ClientBuilderOptions_Hl7_2_3_1);
  checkMSH(msh: HL7_2_3_1_MSH): boolean;
  protected _buildMSH(properties: Partial<HL7_2_1_MSH>): void;
}
//#endregion
//#region src/hl7/types/ecd.d.ts
/**
 * v2.8 narrowing of `HL7_ECD`. ECD.4 was withdrawn in v2.8 — typing it as
 * `never` makes assignment a compile-time error.
 *
 * @since 4.0.0
 */
type HL7_2_8_ECD$1 = {
  ecd_4?: never;
  requestedCompletionTime?: never;
} & Omit<HL7_ECD, "ecd_4" | "requestedCompletionTime">;
/**
 * HL7 ECD — Equipment Command segment.
 *
 * Field availability differs per HL7 spec version. The base `HL7_ECD`
 * interface lists every field that exists in any version (introduced in v2.4).
 * Per-version aliases narrow this set by typing fields as `never` when they
 * are withdrawn (W) or not supported (X) in that version, so the IDE flags
 * them at compile time.
 *
 * @since 4.0.0
 */
interface HL7_ECD {
  /** ECD.1 — Reference Command Number (NM, R). */
  ecd_1: number | string;
  /** ECD.2 — Remote Control Command (CWE, R, table 0368). */
  ecd_2: string;
  /** ECD.3 — Response Required (ID, O, table 0136). */
  ecd_3?: "N" | "Y";
  /**
   * ECD.4 — Requested Completion Time (TQ).
   *
   * Available as `O` in v2.4–v2.5.1, `B` (Backward Compatibility) in
   * v2.6–v2.7.1, and **Withdrawn (`W`) in v2.8**. The v2.8 narrowed type
   * removes this field from the IDE's autocomplete and flags any attempt
   * to set it as a TypeScript error. Runtime check enforces the same.
   */
  ecd_4?: string;
  /** ECD.5 — Parameters (TX, O, repeatable). */
  ecd_5?: string;
  parameters?: string;
  referenceCommandNumber?: number | string;
  remoteControlCommand?: string;
  requestedCompletionTime?: string;
  responseRequired?: "N" | "Y";
}
//#endregion
//#region src/hl7/2.4/ecd.d.ts
/**
 * v2.4 ECD — full field set as introduced in HL7 v2.4.
 * @since 4.0.0
 */
type HL7_2_4_ECD = HL7_ECD;
//#endregion
//#region src/hl7/2.4/msh.d.ts
/**
 * HL7 2.4 MSH Specification
 * @since 1.0.0
 */
type HL7_2_4_MSH = {
  /** Processing Mode — adds "T" in 2.4 */msh_11_2?: "" | "A" | "I" | "R" | "T";
  /** Message Structure (e.g. "ADT_A01")
   * @default Combination of msh_9_1 and msh_9_2 with underscore */
  msh_9_3?: string;
} & HL7_2_3_1_MSH;
//#endregion
//#region src/hl7/2.4/types.d.ts
type ClientBuilderOptions_Hl7_2_4 = ClientBuilderOptions_Hl7_2_3_1;
//#endregion
//#region src/hl7/2.4/index.d.ts
/**
 * Hl7 Specification Version 2.4
 * @since 1.0.0
 */
declare class HL7_2_4 extends HL7_2_3_1 {
  constructor(properties?: ClientBuilderOptions_Hl7_2_4);
  /**
   * Build the ECD (Equipment Command) segment.
   *
   * @remarks
   * Introduced in HL7 v2.4. Field-level validation (R/O/B/W/D) is driven by
   * `ECD_SPEC` and the per-version `usage` map, so the same method body
   * automatically does the right thing in derived classes (v2.5 → v2.8). For
   * example, on a v2.8 builder, attempting to set `ecd_4` throws because that
   * field is `W` (Withdrawn) in v2.8.
   *
   * @since 4.0.0
   */
  buildECD(properties: Partial<HL7_2_4_ECD>): this;
  checkMSH(msh: HL7_2_4_MSH): boolean;
  protected _buildDRG(properties: Partial<HL7_2_4_DRG>): void;
  protected _buildECD(properties: Partial<HL7_ECD>): void;
  protected _buildGOL(properties: Partial<HL7_2_4_GOL>): void;
  protected _buildIAM(properties: Partial<HL7_2_4_IAM>): void;
  protected _buildMSH(properties: Partial<HL7_2_1_MSH>): void;
  protected _buildOBR(properties: Partial<HL7_2_1_OBR>): void;
  protected _buildOM1(properties: Partial<HL7_2_4_OM1>): void;
  protected _buildOM2(properties: Partial<HL7_2_4_OM2>): void;
  protected _buildOM3(properties: Partial<HL7_2_4_OM3>): void;
  protected _buildOM4(properties: Partial<HL7_2_4_OM4>): void;
  protected _buildOM5(properties: Partial<HL7_2_4_OM5>): void;
  protected _buildOM6(properties: Partial<HL7_2_4_OM6>): void;
  protected _buildORC(properties: Partial<HL7_2_1_ORC>): void;
  protected _buildPID(properties: Partial<HL7_2_1_PID>): void;
  protected _buildPRB(properties: Partial<HL7_2_4_PRB>): void;
  protected _buildPTH(properties: Partial<HL7_2_4_PTH>): void;
  protected _buildTXA(properties: Partial<HL7_2_4_TXA>): void;
}
//#endregion
//#region src/hl7/2.5/msh.d.ts
/** HL7 2.5 MSH — same structure as 2.4 */
type HL7_2_5_MSH = HL7_2_4_MSH;
//#endregion
//#region src/hl7/2.5/types.d.ts
type ClientBuilderOptions_Hl7_2_5 = ClientBuilderOptions_Hl7_2_4;
//#endregion
//#region src/hl7/2.5/index.d.ts
/**
 * Hl7 Specification Version 2.5
 * @since 1.0.0
 */
declare class HL7_2_5 extends HL7_2_4 {
  constructor(properties?: ClientBuilderOptions_Hl7_2_5);
  checkMSH(msh: HL7_2_5_MSH): boolean;
  protected _buildSFT(properties: Partial<HL7_2_5_SFT>): void;
  protected _buildSPM(properties: Partial<HL7_2_5_SPM>): void;
}
//#endregion
//#region src/hl7/2.5.1/msh.d.ts
/** HL7 2.5.1 MSH — same structure as 2.5 */
type HL7_2_5_1_MSH = HL7_2_5_MSH;
//#endregion
//#region src/hl7/2.5.1/types.d.ts
type ClientBuilderOptions_Hl7_2_5_1 = ClientBuilderOptions_Hl7_2_5;
//#endregion
//#region src/hl7/2.5.1/index.d.ts
/**
 * Hl7 Specification Version 2.5.1
 * @since 1.0.0
 */
declare class HL7_2_5_1 extends HL7_2_5 {
  constructor(properties?: ClientBuilderOptions_Hl7_2_5_1);
  checkMSH(msh: HL7_2_5_1_MSH): boolean;
}
//#endregion
//#region src/hl7/2.6/msh.d.ts
/** HL7 2.6 MSH — same structure as 2.5.1 */
type HL7_2_6_MSH = HL7_2_5_1_MSH;
//#endregion
//#region src/hl7/2.6/types.d.ts
type ClientBuilderOptions_Hl7_2_6 = ClientBuilderOptions_Hl7_2_5_1;
//#endregion
//#region src/hl7/2.6/index.d.ts
/**
 * Hl7 Specification Version 2.6
 * @since 1.0.0
 */
declare class HL7_2_6 extends HL7_2_5_1 {
  constructor(properties?: ClientBuilderOptions_Hl7_2_6);
  checkMSH(msh: HL7_2_6_MSH): boolean;
  protected _buildBPX(properties: Partial<HL7_2_6_BPX>): void;
  protected _buildBTX(properties: Partial<HL7_2_6_BTX>): void;
  protected _buildITM(properties: Partial<HL7_2_6_ITM>): void;
  protected _buildIVT(properties: Partial<HL7_2_6_IVT>): void;
  protected _buildREL(properties: Partial<HL7_2_6_REL>): void;
}
//#endregion
//#region src/hl7/2.7/msh.d.ts
/** HL7 2.7 MSH — same structure as 2.6; MSH.10 control ID max length grows to 199 */
type HL7_2_7_MSH = HL7_2_6_MSH;
//#endregion
//#region src/hl7/2.7/types.d.ts
type ClientBuilderOptions_Hl7_2_7 = ClientBuilderOptions_Hl7_2_6;
//#endregion
//#region src/hl7/2.7/index.d.ts
/**
 * Hl7 Specification Version 2.7
 * @remarks MSH.10 control ID max length grows to 199 in 2.7.
 * @since 1.0.0
 */
declare class HL7_2_7 extends HL7_2_6 {
  constructor(properties?: ClientBuilderOptions_Hl7_2_7);
  checkMSH(msh: HL7_2_7_MSH): boolean;
  protected _buildIPC(properties: Partial<HL7_2_7_IPC>): void;
  protected _buildISD(properties: Partial<HL7_2_7_ISD>): void;
  protected _buildMSH(properties: Partial<HL7_2_1_MSH>): void;
}
//#endregion
//#region src/hl7/2.7.1/msh.d.ts
/** HL7 2.7.1 MSH — same structure as 2.7 */
type HL7_2_7_1_MSH = HL7_2_7_MSH;
//#endregion
//#region src/hl7/2.7.1/types.d.ts
type ClientBuilderOptions_Hl7_2_7_1 = ClientBuilderOptions_Hl7_2_7;
//#endregion
//#region src/hl7/2.7.1/index.d.ts
/**
 * Hl7 Specification Version 2.7.1
 * @since 1.0.0
 */
declare class HL7_2_7_1 extends HL7_2_7 {
  constructor(properties?: ClientBuilderOptions_Hl7_2_7_1);
  checkMSH(msh: HL7_2_7_1_MSH): boolean;
}
//#endregion
//#region src/hl7/2.8/ecd.d.ts
/**
 * v2.8 ECD — `ECD.4 Requested Completion Time` is **withdrawn (`W`)** and
 * typed as `never` so the IDE rejects any attempt to set `ecd_4` /
 * `requestedCompletionTime`. Runtime check throws the same.
 * @since 4.0.0
 */
type HL7_2_8_ECD = HL7_2_8_ECD$1;
//#endregion
//#region src/hl7/2.8/msh.d.ts
/** HL7 2.8 MSH — same structure as 2.7.1 */
type HL7_2_8_MSH = HL7_2_7_1_MSH;
//#endregion
//#region src/hl7/2.8/types.d.ts
type ClientBuilderOptions_Hl7_2_8 = ClientBuilderOptions_Hl7_2_7_1;
//#endregion
//#region src/hl7/2.8/index.d.ts
/**
 * Hl7 Specification Version 2.8
 * @since 1.0.0
 */
declare class HL7_2_8 extends HL7_2_7_1 {
  constructor(properties?: ClientBuilderOptions_Hl7_2_8);
  /**
   * v2.8 narrowing of `buildECD` — `ecd_4` is typed as `never` so the IDE
   * rejects any attempt to set it. Runtime check enforces the same.
   *
   * @since 4.0.0
   */
  buildECD(properties: Partial<HL7_2_8_ECD>): this;
  checkMSH(msh: HL7_2_8_MSH): boolean;
  protected _buildSTZ(properties: Partial<HL7_2_8_STZ>): void;
}
//#endregion
//#region src/hl7/headers.d.ts
type ACC = HL7_2_1_ACC;
type ADD = HL7_ADD;
type AIG = HL7_2_3_AIG;
type AIL = HL7_2_3_AIL;
type AIP = HL7_2_3_AIP;
type AIS = HL7_2_3_AIS;
type AL1 = HL7_2_2_AL1;
type APR = HL7_2_3_APR;
type BLG = HL7_2_1_BLG;
type BPX = HL7_2_6_BPX;
type BTX = HL7_2_6_BTX;
type CSP = HL7_2_3_CSP;
type CSR = HL7_2_3_CSR;
type CSS = HL7_2_3_CSS;
type CTD = HL7_2_3_CTD;
type DG1 = HL7_2_1_DG1;
type DRG = HL7_2_4_DRG;
type DSC = HL7_2_1_DSC;
type DSP = HL7_DSP;
type ERR = HL7_2_1_ERR;
type EVN = HL7_2_1_EVN;
type FT1 = HL7_2_1_FT1;
type GOL = HL7_2_4_GOL;
type GT1 = HL7_2_1_GT1;
type IAM = HL7_2_4_IAM;
type IN1 = HL7_2_1_IN1;
type IPC = HL7_2_7_IPC;
type ISD = HL7_2_7_ISD;
type ITM = HL7_2_6_ITM;
type IVT = HL7_2_6_IVT;
type MFE = HL7_2_2_MFE;
type MFI = HL7_2_2_MFI;
type MRG = HL7_2_1_MRG;
type MSA = HL7_2_1_MSA;
/**
 * MSH Unions
 * @since 1.0.0
 */
type MSH = HL7_2_1_MSH | HL7_2_2_MSH | HL7_2_3_1_MSH | HL7_2_3_MSH | HL7_2_4_MSH | HL7_2_5_1_MSH | HL7_2_5_MSH | HL7_2_6_MSH | HL7_2_7_1_MSH | HL7_2_7_MSH | HL7_2_8_MSH;
type NK1 = HL7_2_3_NK1;
type NPU = HL7_2_1_NPU;
type NSC = HL7_2_1_NSC;
type NST = HL7_NST;
type NTE = HL7_2_1_NTE;
type OBR = HL7_2_4_OBR;
type OBX = HL7_2_3_OBX;
type ODS = HL7_2_2_ODS;
type ODT = HL7_2_2_ODT;
type OM1 = HL7_2_4_OM1;
type OM2 = HL7_2_4_OM2;
type OM3 = HL7_2_4_OM3;
type OM4 = HL7_2_4_OM4;
type OM5 = HL7_2_4_OM5;
type OM6 = HL7_2_4_OM6;
type ORC = HL7_2_4_ORC;
type PCR = HL7_2_3_PCR;
type PD1 = HL7_2_3_PD1;
type PID = HL7_2_4_PID;
type PR1 = HL7_2_1_PR1;
type PRA = HL7_2_3_PRA;
type PRB = HL7_2_4_PRB;
type PRD = HL7_2_3_PRD;
type PSH = HL7_2_3_PSH;
type PTH = HL7_2_4_PTH;
type PV1 = HL7_2_2_PV1;
type QRD = HL7_2_1_QRD;
type QRF = HL7_2_1_QRF;
type RDF = HL7_2_3_RDF;
type RDT = HL7_2_3_RDT;
type REL = HL7_2_6_REL;
type RGS = HL7_2_3_RGS;
type ROL = HL7_2_3_ROL;
type RX1 = HL7_2_1_RX1;
type RXA = HL7_2_2_RXA;
type RXD = HL7_2_2_RXD;
type RXE = HL7_2_2_RXE;
type RXG = HL7_2_2_RXG;
type RXO = HL7_2_2_RXO;
type RXR = HL7_2_2_RXR;
type SCH = HL7_2_3_SCH;
type SFT = HL7_2_5_SFT;
type SPM = HL7_2_5_SPM;
type STF = HL7_2_2_STF;
type STZ = HL7_2_8_STZ;
type TXA = HL7_2_4_TXA;
type UB1 = HL7_2_1_UB1;
type UB2 = HL7_2_2_UB2;
type URD = HL7_2_1_URD;
type URS = HL7_2_1_URS;
type VAR = HL7_2_3_VAR;
//#endregion
//#region src/modules/types.d.ts
interface ClientBuilderFileOptions extends ClientBuilderOptions {
  /**
   * Extension of the file when it gets created.
   * @since 1.0.0
   * @default hl7
   */
  extension?: string;
  /** The file as a buffer passed onto the constructor
   * @since 1.0.0  */
  fileBuffer?: Buffer;
  /** If you are providing the full file path, please set it here.
   * @since 1.0.0 */
  fullFilePath?: string;
  /** Location where the file will be saved.
   * If this is not set,
   * the files will get save it in the same directory of the executing file that is calling the function.
   * If running this package inside a DOCKER/KUBERNETES node,
   * if the container is destroyed and the files are not saved on a folder mounted outside the node,
   * the files will be lost on restart.
   * @since 1.0.0
   * @default ""
   */
  location?: string;
  /** The HL7 string that we are going to parse.
   * @default "" */
  text?: string;
}
interface ClientBuilderMessageOptions extends ClientBuilderOptions {
  /**
   * MSH Header Options
   * @since 1.0.0
   */
  messageHeader?: MSH;
  /** The HL7 string that we are going to parse.
   * @default "" */
  text?: string;
}
/**
 * Client Builder Options
 * @remarks Used to specific default parameters around building an HL7 message if that is
 * so desired.
 * @since 1.0.0
 */
interface ClientBuilderOptions {
  /** The date type for the date field. Usually generated at the time of the class being initialized.
   * @since 1.0.0
   * @default 14
   */
  date?: "12" | "14" | "19" | "8";
  /** */
  hardError?: boolean;
  /** At the end of each line, add this as the new line character.
   * @since 1.0.0
   * @default \r */
  newLine?: string;
  /** The character used to separate different components.
   * @since 1.0.0
   * @default ^ */
  separatorComponent?: string;
  /** The character used to escape characters that need it in order for the computer to interpret the string correctly.
   * @since 1.0.0
   * @default \\ */
  separatorEscape?: string;
  /** The character used for separating fields.
   * @since 1.0.0
   * @default | */
  separatorField?: string;
  /** The character used for repetition field/values pairs.
   * @since 1.0.0
   * @default ~ */
  separatorRepetition?: string;
  /** The character used to have subcomponents seperated.
   * @since 1.0.0
   * @default & */
  separatorSubComponent?: string;
}
interface ClientListenerOptions extends ClientOptions {
  /** If set to false, you have to tell the system to start trying to connect
   * by sending 'start' method.
   * @default true
   */
  autoConnect?: boolean;
  /** Encoding of the messages we expect from the HL7 message.
   * @default "utf8"
   */
  encoding?: BufferEncoding;
  /**
   * Your custom function to store messages if messages have to queue.
   * Note: You must set up flushQueue prop as well.
   * @since 3.1.0
   * @example
   * ```ts
   * const enqueueMessage = (message: Message): void => {
   *   messageQueue.push(message);
   * };
   * ```
   * @remarks
   * `enqueueMessage(message)` is called whenever a message should be stored.
   */
  enqueueMessage?: (message: MessageItem, notifyPendingCount: NotifyPendingCount) => Promise<void> | void;
  /**
   * Your custom function to get messages from your custom enqueueMessage function.
   * Note: You must set up enqueueMessage prop as well.
   * @since 3.1.0
   * @example
   * ```ts
   * const flushQueue = (deliver: (msg: Message) => void): void => {
   *   while (messageQueue.length > 0) {
   *     const msg = messageQueue.shift();
   *     if (msg) deliver(msg);
   *   }
   * };
   * ```
   * @remarks
   * `flushQueue(deliverFn)` is called on reconnecting and established to send stored messages back into the connection.
   */
  flushQueue?: (callback: FallBackHandler, notifyPendingCount: NotifyPendingCount) => Promise<void> | void;
  /** Max Connections this connection makes.
   * Has to be greater than 1.
   * @default 10 */
  maxConnections?: number;
  /**
   * @since 3.1.0
   * @default 10,000
   */
  maxLimit?: number;
  /** The port we should connect to on the server. */
  port: number;
  /** Wait for ACK before sending a new message.
   * If this is set to false, you can send as many messages as you want but since you are not expecting any ACK from a
   * previous message sent before sending another one.
   * This does not stop the "total acknowledgement" counter on the
   * client object to stop increasing.
   * @default true **/
  waitAck?: boolean;
}
interface ClientOptions {
  /**
   * Enable Happy-Eyeballs / dual-stack auto-selection when resolving the
   * host name. Only takes effect when dual-stack is opted into
   * (`ipv4: true, ipv6: true`). When on, Node races IPv6 and IPv4 connection
   * attempts and uses whichever wins, so a remote with a stale or
   * unreachable AAAA record silently falls back to its A record (and vice
   * versa). Forwarded directly to `net.connect()` / `tls.connect()`.
   * @since 4.0.0
   * @default true; ignored when `ipv4` or `ipv6` is exclusive
   */
  autoSelectFamily?: boolean;
  /**
   * How long, in milliseconds, to wait for a connection attempt on one
   * address family before racing the other when `autoSelectFamily` is on.
   * @since 4.0.0
   * @default 250
   */
  autoSelectFamilyAttemptTimeout?: number;
  /**
   * How long a connection attempt checked before ending the socket and attempting again.
   * If this is set to zero, the client will stay connected.
   * Min. is 0 (Stay Connected), and Max. is 60000 (60 seconds.)
   * Use with caution.
   * @default 0
   */
  connectionTimeout?: number;
  /** Host - You can do a FQDN or the IPv(4|6) address. */
  host?: string;
  /** IPv4 - When `true`, IPv4 connections are accepted. The host (if a
   * literal) is validated as IPv4 when this is the only enabled family.
   * Combine with {@link ipv6}` = true` to opt into dual-stack with
   * Happy-Eyeballs fallback.
   * @default true */
  ipv4?: boolean;
  /** IPv6 - When `true`, IPv6 connections are accepted. The host (if a
   * literal) is validated as IPv6 when this is the only enabled family.
   * Combine with {@link ipv4}` = true` (the default) to opt into dual-stack
   * with Happy-Eyeballs fallback.
   * @default false */
  ipv6?: boolean;
  /** Max attempts
   * to send the message before an error is thrown if we are in the process of re-attempting to connect to the server.
   * Has to be greater than 1. You cannot exceed 50.
   * @default 10 */
  maxAttempts?: number;
  /** If we are trying to establish an initial connection to the server, let's end it after this many attempts.
   * The time between re-connecting is determined by {@link connectionTimeout}.
   * You cannot exceed 50.
   * @since 1.1.0
   * @default 30
   */
  maxConnectionAttempts?: number;
  /** The number of times a connection timeout occurs until it stops attempting and just stops.
   * @since 2.1.0
   * @default 10
   */
  maxTimeout?: number;
  /** Max delay, in milliseconds, for exponential-backoff when reconnecting
   * @default 30_000 */
  retryHigh?: number;
  /** Step size, in milliseconds, for exponential-backoff when reconnecting
   * @default 1000 */
  retryLow?: number;
  /** Additional options when creating the TCP socket with net.connect(). */
  socket?: TcpSocketConnectOpts;
  /** Enable TLS, or set TLS specific options like overriding the CA for
   * self-signed certificates. */
  tls?: boolean | ConnectionOptions;
  /** The HL7 version this client pins. Required. Every message (or every
   * message contained in a batch/file) sent through a connection must carry a
   * matching `MSH.12`, or the send is rejected before it is queued.
   * Must be one of the known HL7 versions
   * (2.1, 2.2, 2.3, 2.3.1, 2.4, 2.5, 2.5.1, 2.6, 2.7, 2.7.1, 2.8).
   * @since 4.0.0 */
  version: HL7Version;
}
type FallBackHandler = (message: MessageItem) => void;
type MessageItem = Batch | FileBatch | Message;
type NotifyPendingCount = (count: number) => Promise<void>;
/**
 * Outbound Handler
 * @remarks Used to receive a response from the server
 * @since 1.0.0
 * @param res
 */
type OutboundHandler = (res: InboundResponse) => Promise<void> | void;
//#endregion
//#region src/builder/normalizedParser.d.ts
declare function normalizedClientBatchParserOptions(raw?: ClientBuilderMessageOptions): ClientBuilderMessageOptions;
declare function normalizedClientFileParserOptions(raw?: ClientBuilderFileOptions): ClientBuilderFileOptions;
declare function normalizedClientMessageParserOptions(raw?: ClientBuilderMessageOptions): ClientBuilderMessageOptions;
//#endregion
//#region src/builder/batch.d.ts
/**
 * Batch Class
 * @remarks Creating a Batch (BHS) which could include hundreds of MSH segments for processing.
 * Normally used in large data processing.
 * However, the server usually breaks down a batch MSH into single "elements" to process them and returns that the batch.
 * @since 1.0.0
 */
declare class Batch extends RootBase {
  /** @internal */
  _messagesCount: number;
  /** @internal **/
  _opt: ReturnType<typeof normalizedClientBatchParserOptions>;
  /** @internal */
  protected _lines: string[];
  /**
   * @since 1.0.0
   * @param props Passing the options to build the batch.
   */
  constructor(properties?: ClientBuilderMessageOptions);
  /**
   * Add a Message to the Batch
   * @remarks This adds a Message (MSH) output into the batch.
   * It also increases the count of the BTS segment as the batch final result
   * when in end tells the receiving end how many message (MSH) segments are included.
   * @since 1.0.0
   * @param message The {@link Message} to add into the batch.
   * @param index Used Internally mostly to add an MSH segment within a BHS segment at a certain index.
   */
  add(message: Message, index?: number | undefined): void;
  /**
   * End Batch
   * @remarks At the conclusion of building the batch,
   * (Usually {@link add} method will be before this) will add the Batch Trailing Segment (BTS) to the end.
   * If a message (MSH) is added after this,
   * that message (MSH) will get added to the first BHS found if there is more than one.
   * This might be typical inside a file output process.
   * {@link FileBatch} for more information.
   * @since 1.0.0
   */
  end(): void;
  /**
   * Get BHS Segment at Path
   * @since 1.0.0
   * @param path Could be 'BHS.7' or 7, and it shall get the same result.
   * @example
   * ```ts
   * const date = batch.get('BHS.7')
   * ```
   * or
   * ```ts
   * const date = batch.get(7)
   * ```
   */
  get(path: number | string): HL7Node;
  /**
   * Get the First Segment
   * @remarks Returns the first segment found in the Batch (BHS).
   * This is only used during the {@link add} method
   * in determining
   * if there is more than one Batch of MSH in a File Batch {@link FileBatch}
   * which can hold more than one Batch groups.
   * @since 1.0.0
   * @param name The name of the segment.
   * At max usually three characters long.
   */
  getFirstSegment(name: string): Segment;
  /**
   * Get Messages within a submitted Batch
   * @remarks This will parse the passed on "text"
   * in the contractor options and get all the messages (MSH) segments within it and return an array of them.
   * @since 1.0.0
   * @example
   * ```ts
   * try {
   *  // parser the batch
   *  const parser = new Batch({ text: loadedMessage })
   *  // load the messages
   *  const allMessage = parser.messages()
   *  // loop messages
   *  allMessage.forEach((message: Message) => {
   *    const messageParsed = new Message({ text: message.toString() })
   *  })
   * } catch (e) {
   *   // error here
   * }
   * ```
   * @returns Returns an array of messages or a HL7ParserError will throw.
   */
  messages(): Message[];
  /** @internal */
  read(path: string[]): HL7Node;
  /**
   * Set Batch Segment at Path with a Value
   * @since 1.0.0
   * @example
   * ```ts
   * const batch = new Batch()
   * batch.set('BHS.7', '20231231')
   * ```
   * @param path Where you want to set in the segment
   * @param value The value.
   * It Can be an Array, String, or Boolean.
   * If the value is not set, you can chain this to expand the paths
   * @example
   * If the value is not used this can be employed:
   * ```ts
   * batch.set('BHS.3').set(0).set('BHS.3.1', 'abc');
   * ```
   */
  set(path: number | string, value?: any): HL7Node;
  /**
   * Start Batch
   * @remarks This allows you to override the orginial contractor BHS fields that are required.
   * In this case, 'BHS.7'
   * (Date Field) is filled out with a 14-character date field with YYYYMMDDHHMMSS entered in by default.
   * @since 1.0.0
   * @param style Your options produce: YYYYMMDDHHMMSS = 14 | YYYYMMDDHHMM = 12 | YYYYMMDD = 8
   * @defaultValue YYYYMMDDHHMMSS (14)
   */
  start(style?: "12" | "14" | "8"): void;
  /**
   * Create File from a Batch
   * @remarks Will procure a file of the saved MSH in the proper format
   * that includes a FHS and FTS segments with the possibility of more than one BHS segments inside with one or more MSH inside each BHS groups.
   * @since 1.0.0
   * @param name File Name
   * @param newLine Provide a New Line
   * @param location Where to save the exported file
   * @param extension Custom extension of the file.
   * Default: hl7
   * @example
   * ```ts
   * const batch = new Batch({text: hl7_batch_string})
   * batch.toFile('readTestBHS', true, 'temp/')
   * ```
   * You can set an `extension` parameter on Batch to set a custom extension if you don't want to be HL7.
   */
  toFile(name: string, newLine?: boolean, location?: string, extension?: string): string;
  /** @internal */
  protected createChild(text: string, _index: number): HL7Node;
  /** @internal */
  protected pathCore(): string[];
  /** @internal */
  protected writeCore(path: string[], value: string): HL7Node;
  /** @internal **/
  private _addSegment;
  /** @internal */
  private _getFirstSegment;
}
//#endregion
//#region src/builder/modules/segmentList.d.ts
/**
 * Segment List
 * @since 1.0.0
 */
declare class SegmentList extends NodeBase {
  /** @internal */
  get name(): string;
  /** @internal */
  protected get children(): HL7Node[];
  /** @internal */
  private readonly _segments;
  /** @internal */
  constructor(parent: NodeBase, segments: Segment[]);
  /** @internal */
  read(path: string[]): HL7Node;
  /**
   * Iterate over each segment in the list. Lets callers do
   * `for (const seg of message.get("EVN")) { ... }` even when there is
   * just one matching segment.
   * @since 4.0.0
   */
  [Symbol.iterator](): Iterator<Segment>;
  /** @internal */
  toString(): string;
  /** @internal */
  protected pathCore(): string[];
  /** @internal */
  protected writeCore(path: string[], value: string): HL7Node;
}
//#endregion
//#region src/client/normalizedClient.d.ts
type ValidatedClientKeys = "connectionTimeout" | "host";
interface ValidatedClientOptions extends Pick<Required<ClientOptions>, ValidatedClientKeys> {
  autoSelectFamily: boolean;
  autoSelectFamilyAttemptTimeout: number;
  connectionTimeout: number;
  /** Resolved family for the connection. `0` means dual-stack (let Node decide
   * with Happy Eyeballs); `4`/`6` mean force that family. */
  family: 0 | 4 | 6;
  host: string;
  ipv4: boolean;
  ipv6: boolean;
  maxTimeout: number;
  retryHigh: number;
  retryLow: number;
  socket?: TcpSocketConnectOpts;
  tls?: ConnectionOptions;
  version: HL7Version;
}
/** @internal */
/** @internal */
declare function normalizeClientOptions(raw?: ClientOptions): ValidatedClientOptions;
//#endregion
//#region src/client/connection.d.ts
interface IConnection extends EventEmitter {
  /** The connection has been closed manually. You have to start the connection again. */
  on(name: "close", callback: () => void): this;
  /** The connection is made. */
  on(name: "connect", callback: () => void): this;
  /** The connection is being (re)established or attempting to re-connect. */
  on(name: "connection", callback: () => void): this;
  /** The handle is open to do a manual start to connect. */
  on(name: "open", callback: () => void): this;
  /** The total acknowledged for this connection. */
  on(name: "client.acknowledged", callback: (number: number) => void): this;
  /** The connection has an error. */
  on(name: "client.error", callback: (error: any) => void): this;
  /** The total sent for this connection. */
  on(name: "client.sent", callback: (number: number) => void): this;
  /** The connection has timeout. Review "client.error" event for the reason. */
  on(name: "client.timeout", callback: () => void): this;
  /** When the in-memory queue limit is exceeded */
  on(name: "client.limitExceeded", callback: (port: number) => void): this;
}
/** Connection Class
 * @remarks Create a connection customer that will listen to result send to the particular port.
 * @since 1.0.0 */
declare class Connection extends EventEmitter implements IConnection {
  /** @internal */
  _connectionTimer?: NodeJS.Timeout | undefined;
  /** @internal */
  _handler: OutboundHandler;
  /** @internal */
  _onConnect: Deferred<void>;
  /** @internal */
  _retryTimer: NodeJS.Timeout | undefined;
  /** @internal */
  readonly stats: {
    /** Total acknowledged messages back from server.
     * @since 1.1.0 */
    acknowledged: number;
    /** Pending Messages
     * @since 3.1.0 */
    pending: number;
    /** Total message sent to server.
     * @since 1.1.0 */
    sent: number;
  };
  /** @internal */
  protected _readyState: ReadyState;
  /** @internal */
  private _awaitingResponse;
  /** @internal */
  private _codec;
  /** @internal */
  private _dataResult;
  /** @internal */
  private readonly _enqueueMessageFn;
  /** @internal */
  private readonly _extendMaxLimit;
  /** @internal */
  private readonly _flushQueueFn;
  /** @internal */
  private readonly _main;
  /** @internal */
  private readonly _maxLimit;
  /** @internal */
  private readonly _notifyOnLimitExceeded;
  /** @internal */
  private readonly _opt;
  /** @internal */
  private readonly _pendingMessages;
  /** @internal */
  private _pendingSetup;
  /** @internal */
  private _retryCount;
  /** @internal */
  private _retryTimeoutCount;
  /** @internal */
  private _socket;
  /**
   * @since 1.0.0
   * @param client The client parent that we are connecting too.
   * @param props The individual port connection options.
   * Some values will be defaulted by the parent server connection.
   * @param handler The function that will send the returned information back to the client after we got a response from the server.
   * @example
   * ```ts
   * const OB = client.createConnection({ port: 3000 }, async (res) => {})
   * ```
   */
  constructor(client: Client, properties: ClientListenerOptions, handler: OutboundHandler);
  /** Close Client Listener Instance.
   * @remarks Force close a connection.
   * It will stop any re-connection timers.
   * If you want to restart, your app has to restart the connection.
   * @since 1.0.0
   * @example
   * ```ts
   * outbound.close()
   * ```
   */
  close(): Promise<void>;
  /**
   * Start the connection if not auto started.
   * @since 2.0.0
   */
  connect(): Promise<void>;
  /**
   * Get Port
   * @remarks Get the port that this connection will connect to.
   * @since 2.0.0
   */
  getPort(): number;
  /** Send a HL7 Message to the Listener
   * @remarks This function sends a message/batch/file batch to the remote side.
   * It has the ability, if set to auto-retry (defaulted to 1 re-connect before connection closes)
   * @since 1.0.0
   * @param message The message we need to send to the port.
   * @example
   * ```ts
   *
   * // the OB was set from the original 'createConnection' method.
   *
   * let message = new Message({
   *  messageHeader: {
   *    msh_9_1: "ADT",
   *    msh_9_2: "A01",
   *    msh_11_1: "P" // marked for production here in the example
   *  }
   * })
   *
   * await OB.sendMessage(message)
   *
   * ```
   */
  sendMessage(message: Batch | FileBatch | Message): Promise<void>;
  /** @internal */
  protected _connect(): Socket;
  /**
   * This is the default Enqueue Message Handler
   * @since 3.1.0
   * @param message
   * @param notifyPendingCount
   * @protected
   */
  protected defaultEnqueueMessage(message: MessageItem, notifyPendingCount: NotifyPendingCount): Promise<void>;
  /**
   * This is the default Flush Message Handler
   * @since 3.1.0
   * @param callback
   * @param notifyPendingCount
   * @protected
   */
  protected defaultFlushQueue(callback: FallBackHandler, notifyPendingCount: NotifyPendingCount): Promise<void>;
  /**
   * This is checked during Encoding to handle overflow from use of memory.
   * @since 3.1.0
   * @protected
   */
  protected handleQueueOverflow(): void;
  /**
   * The handle that handles telling the client how many pending message this connection has.
   * @since 3.1.0
   * @param count
   */
  private _handlePendingUpdate;
  /** @internal */
  private _negotiate;
}
//#endregion
//#region src/client/client.d.ts
/**
 * Client Class
 * @remarks The main class that starts a client connection to a valid HL7 TCP/MLLP specified server.
 * @since 1.0.0 */
declare class Client extends EventEmitter {
  /** @internal */
  _connections: Connection[];
  /** @internal */
  _opt: ReturnType<typeof normalizeClientOptions>;
  /** @internal */
  readonly stats: {
    /** Overall Ack *
     * @since 2.0.0 */
    _totalAck: number;
    /** Total outbound connections able to connect to at this moment.
     * @since 1.1.0 */
    _totalConnections: number;
    /** Overall Pending
     * @since 3.1.0 */
    _totalPending: number;
    /** Overall total sent messages
     * @since 2.0.0 */
    _totalSent: number;
  };
  /**
   * This creates a new client to a new server connection.
   * This is the remote side in which we will connect.
   * Then using the {@link createConnection} method, you establish a connection to the port.
   * @since 1.0.0
   * @param props
   * @example
   * ```ts
   * const client = new Client({host: '0.0.0.0'})
   * ```
   */
  constructor(properties?: ClientOptions);
  /**
   * Close all connections
   * @since 2.0.0
   */
  closeAll(): void;
  /** Connect to a listener to a specified port.
   * @since 1.0.0
   * @param props This individual port connections which can override the main server connection properties.
   * Some properties from the server build could be defaulted if not specified here.
   * @param cb The function that the client will process if and when they get a response from the server.
   * It follows an async/await function.
   * @example
   * ```ts
   * const outGoing = client.createOutbound({port: 3000}, async (res: InboundResponse) => {})
   * ```
   * Review the {@link InboundResponse} on the properties returned.
   */
  createConnection(properties: ClientListenerOptions, callback: OutboundHandler): Connection;
  /**
   * Get the host that we will connect to.
   * The port might be different from each different "connection"
   * @since 1.1.0
   */
  getHost(): string;
  /**
   * Total ack in this object lifetime.
   * @since 2.0.0
   */
  totalAck(): number;
  /**
   * Total pending messages that need to be sent out
   * on reconnection to the server.
   * @since 3.1.0
   */
  totalPending(): number;
  /**
   * Total sent messages in this object lifetime.
   * @since 2.0.0
   */
  totalSent(): number;
}
//#endregion
//#region src/helpers/exception.d.ts
/** Parent Cass of HL7 Error
 * @since 1.0.0 */
declare class HL7Error extends Error {
  code: number;
  /** @internal */
  constructor(code: number, message: string);
}
/** Used to indicate a fatal failure of a connection.
 * @since 1.0.0 */
declare class HL7FatalError extends HL7Error {
  /** @internal */
  name: string;
  constructor(message: string);
}
/** Used to indicate a fatal failure of a connection.
 * @since 1.0.0 */
declare class HL7ParserError extends HL7Error {
  /** @internal */
  name: string;
  constructor(message: string);
}
/** Used to indicate a fatal failure of a validator.
 * @since 1.0.0 */
declare class HL7ValidationError extends HL7Error {
  /** @internal */
  name: string;
  constructor(message: string);
}
//#endregion
//#region src/hl7/metadata/datatypes/ce.d.ts
/**
 * CE — composite HL7 data type.
 *
 * Generated from the Caristix HL7 Definition API
 * (https://hl7-definition.caristix.com/v2/HL7v2.X/DataTypes/CE)
 * by scripts/generate-segment-specs.mjs. Do not edit by hand — re-run
 * the generator instead.
 *
 * Both numeric (`ce_<n>`) and camelCase keys are accepted; pick
 * whichever reads better. The runtime composer joins set components
 * with the HL7 component separator (`^`) and validates each piece.
 *
 * @since 4.0.0
 */
interface HL7_CE {
  alternateIdentifier?: string;
  alternateText?: string;
  /** CE.1 - Identifier */
  ce_1?: string;
  /** CE.2 - Text */
  ce_2?: string;
  /** CE.3 - Name Of Coding System */
  ce_3?: string;
  /** CE.4 - Alternate Identifier */
  ce_4?: string;
  /** CE.5 - Alternate Text */
  ce_5?: string;
  /** CE.6 - Name Of Alternate Coding System */
  ce_6?: string;
  identifier?: string;
  nameOfAlternateCodingSystem?: string;
  nameOfCodingSystem?: string;
  text?: string;
}
//#endregion
//#region src/hl7/metadata/datatypes/cwe.d.ts
/**
 * CWE — composite HL7 data type.
 *
 * Generated from the Caristix HL7 Definition API
 * (https://hl7-definition.caristix.com/v2/HL7v2.X/DataTypes/CWE)
 * by scripts/generate-segment-specs.mjs. Do not edit by hand — re-run
 * the generator instead.
 *
 * Both numeric (`cwe_<n>`) and camelCase keys are accepted; pick
 * whichever reads better. The runtime composer joins set components
 * with the HL7 component separator (`^`) and validates each piece.
 *
 * @since 4.0.0
 */
interface HL7_CWE {
  alternateCodingSystemOid?: string;
  alternateCodingSystemVersionId?: string;
  alternateIdentifier?: string;
  alternateText?: string;
  alternateValueSetOid?: string;
  alternateValueSetVersionId?: string;
  codingSystemOid?: string;
  codingSystemVersionId?: string;
  /** CWE.1 - Identifier */
  cwe_1?: string;
  /** CWE.10 - Second Alternate Identifier */
  cwe_10?: string;
  /** CWE.11 - Second Alternate Text */
  cwe_11?: string;
  /** CWE.12 - Name Of Second Alternate Coding System */
  cwe_12?: string;
  /** CWE.13 - Second Alternate Coding System Version Id */
  cwe_13?: string;
  /** CWE.14 - Coding System Oid */
  cwe_14?: string;
  /** CWE.15 - Value Set Oid */
  cwe_15?: string;
  /** CWE.16 - Value Set Version Id */
  cwe_16?: string;
  /** CWE.17 - Alternate Coding System Oid */
  cwe_17?: string;
  /** CWE.18 - Alternate Value Set Oid */
  cwe_18?: string;
  /** CWE.19 - Alternate Value Set Version Id */
  cwe_19?: string;
  /** CWE.2 - Text */
  cwe_2?: string;
  /** CWE.20 - Second Alternate Coding System Oid */
  cwe_20?: string;
  /** CWE.21 - Second Alternate Value Set Oid */
  cwe_21?: string;
  /** CWE.22 - Second Alternate Value Set Version Id */
  cwe_22?: string;
  /** CWE.3 - Name Of Coding System */
  cwe_3?: string;
  /** CWE.4 - Alternate Identifier */
  cwe_4?: string;
  /** CWE.5 - Alternate Text */
  cwe_5?: string;
  /** CWE.6 - Name Of Alternate Coding System */
  cwe_6?: string;
  /** CWE.7 - Coding System Version Id */
  cwe_7?: string;
  /** CWE.8 - Alternate Coding System Version Id */
  cwe_8?: string;
  /** CWE.9 - Original Text */
  cwe_9?: string;
  identifier?: string;
  nameOfAlternateCodingSystem?: string;
  nameOfCodingSystem?: string;
  nameOfSecondAlternateCodingSystem?: string;
  originalText?: string;
  secondAlternateCodingSystemOid?: string;
  secondAlternateCodingSystemVersionId?: string;
  secondAlternateIdentifier?: string;
  secondAlternateText?: string;
  secondAlternateValueSetOid?: string;
  secondAlternateValueSetVersionId?: string;
  text?: string;
  valueSetOid?: string;
  valueSetVersionId?: string;
}
//#endregion
//#region src/hl7/metadata/datatypes/cx.d.ts
/**
 * CX — composite HL7 data type.
 *
 * Generated from the Caristix HL7 Definition API
 * (https://hl7-definition.caristix.com/v2/HL7v2.X/DataTypes/CX)
 * by scripts/generate-segment-specs.mjs. Do not edit by hand — re-run
 * the generator instead.
 *
 * Both numeric (`cx_<n>`) and camelCase keys are accepted; pick
 * whichever reads better. The runtime composer joins set components
 * with the HL7 component separator (`^`) and validates each piece.
 *
 * @since 4.0.0
 */
interface HL7_CX {
  assigningAgencyOrDepartment?: string;
  assigningAuthority?: string;
  assigningFacility?: string;
  assigningJurisdiction?: string;
  checkDigitScheme?: string;
  /** CX.1 - Id Number */
  cx_1?: string;
  /** CX.10 - Assigning Agency Or Department */
  cx_10?: string;
  /** CX.11 - Security Check */
  cx_11?: string;
  /** CX.12 - Security Check Scheme */
  cx_12?: string;
  /** CX.2 - Identifier Check Digit */
  cx_2?: string;
  /** CX.3 - Check Digit Scheme */
  cx_3?: string;
  /** CX.4 - Assigning Authority */
  cx_4?: string;
  /** CX.5 - Identifier Type Code */
  cx_5?: string;
  /** CX.6 - Assigning Facility */
  cx_6?: string;
  /** CX.7 - Effective Date */
  cx_7?: string;
  /** CX.8 - Expiration Date */
  cx_8?: string;
  /** CX.9 - Assigning Jurisdiction */
  cx_9?: string;
  effectiveDate?: string;
  expirationDate?: string;
  identifierCheckDigit?: string;
  identifierTypeCode?: string;
  idNumber?: string;
  securityCheck?: string;
  securityCheckScheme?: string;
}
//#endregion
//#region src/hl7/metadata/datatypes/ei.d.ts
/**
 * EI — composite HL7 data type.
 *
 * Generated from the Caristix HL7 Definition API
 * (https://hl7-definition.caristix.com/v2/HL7v2.X/DataTypes/EI)
 * by scripts/generate-segment-specs.mjs. Do not edit by hand — re-run
 * the generator instead.
 *
 * Both numeric (`ei_<n>`) and camelCase keys are accepted; pick
 * whichever reads better. The runtime composer joins set components
 * with the HL7 component separator (`^`) and validates each piece.
 *
 * @since 4.0.0
 */
interface HL7_EI {
  /** EI.1 - Entity Identifier */
  ei_1?: string;
  /** EI.2 - Namespace ID */
  ei_2?: string;
  /** EI.3 - Universal ID */
  ei_3?: string;
  /** EI.4 - Universal ID Type */
  ei_4?: string;
  entityIdentifier?: string;
  namespaceId?: string;
  universalId?: string;
  universalIdType?: string;
}
//#endregion
//#region src/hl7/metadata/datatypes/hd.d.ts
/**
 * HD — composite HL7 data type.
 *
 * Generated from the Caristix HL7 Definition API
 * (https://hl7-definition.caristix.com/v2/HL7v2.X/DataTypes/HD)
 * by scripts/generate-segment-specs.mjs. Do not edit by hand — re-run
 * the generator instead.
 *
 * Both numeric (`hd_<n>`) and camelCase keys are accepted; pick
 * whichever reads better. The runtime composer joins set components
 * with the HL7 component separator (`^`) and validates each piece.
 *
 * @since 4.0.0
 */
interface HL7_HD {
  /** HD.1 - Namespace ID */
  hd_1?: string;
  /** HD.2 - Universal ID */
  hd_2?: string;
  /** HD.3 - Universal ID Type */
  hd_3?: string;
  namespaceId?: string;
  universalId?: string;
  universalIdType?: string;
}
//#endregion
//#region src/hl7/metadata/datatypes/xad.d.ts
/**
 * XAD — composite HL7 data type.
 *
 * Generated from the Caristix HL7 Definition API
 * (https://hl7-definition.caristix.com/v2/HL7v2.X/DataTypes/XAD)
 * by scripts/generate-segment-specs.mjs. Do not edit by hand — re-run
 * the generator instead.
 *
 * Both numeric (`xad_<n>`) and camelCase keys are accepted; pick
 * whichever reads better. The runtime composer joins set components
 * with the HL7 component separator (`^`) and validates each piece.
 *
 * @since 4.0.0
 */
interface HL7_XAD {
  addressee?: string;
  addressIdentifier?: string;
  addressRepresentationCode?: string;
  addressType?: string;
  addressUsage?: string;
  addressValidityRange?: string;
  badAddressIndicator?: string;
  censusTract?: string;
  city?: string;
  comment?: string;
  country?: string;
  countyParishCode?: string;
  effectiveDate?: string;
  expirationDate?: string;
  expirationReason?: string;
  otherDesignation?: string;
  otherGeographicDesignation?: string;
  preferenceOrder?: string;
  protectionCode?: string;
  stateOrProvince?: string;
  streetAddress?: string;
  temporaryIndicator?: string;
  /** XAD.1 - Street Address */
  xad_1?: string;
  /** XAD.10 - Census Tract */
  xad_10?: string;
  /** XAD.11 - Address Representation Code */
  xad_11?: string;
  /** XAD.12 - Address Validity Range */
  xad_12?: string;
  /** XAD.13 - Effective Date */
  xad_13?: string;
  /** XAD.14 - Expiration Date */
  xad_14?: string;
  /** XAD.15 - Expiration Reason */
  xad_15?: string;
  /** XAD.16 - Temporary Indicator */
  xad_16?: string;
  /** XAD.17 - Bad Address Indicator */
  xad_17?: string;
  /** XAD.18 - Address Usage */
  xad_18?: string;
  /** XAD.19 - Addressee */
  xad_19?: string;
  /** XAD.2 - Other Designation */
  xad_2?: string;
  /** XAD.20 - Comment */
  xad_20?: string;
  /** XAD.21 - Preference Order */
  xad_21?: string;
  /** XAD.22 - Protection Code */
  xad_22?: string;
  /** XAD.23 - Address Identifier */
  xad_23?: string;
  /** XAD.3 - City */
  xad_3?: string;
  /** XAD.4 - State Or Province */
  xad_4?: string;
  /** XAD.5 - Zip Or Postal Code */
  xad_5?: string;
  /** XAD.6 - Country */
  xad_6?: string;
  /** XAD.7 - Address Type */
  xad_7?: string;
  /** XAD.8 - Other Geographic Designation */
  xad_8?: string;
  /** XAD.9 - County/Parish Code */
  xad_9?: string;
  zipOrPostalCode?: string;
}
//#endregion
//#region src/hl7/metadata/datatypes/xcn.d.ts
/**
 * XCN — composite HL7 data type.
 *
 * Generated from the Caristix HL7 Definition API
 * (https://hl7-definition.caristix.com/v2/HL7v2.X/DataTypes/XCN)
 * by scripts/generate-segment-specs.mjs. Do not edit by hand — re-run
 * the generator instead.
 *
 * Both numeric (`xcn_<n>`) and camelCase keys are accepted; pick
 * whichever reads better. The runtime composer joins set components
 * with the HL7 component separator (`^`) and validates each piece.
 *
 * @since 4.0.0
 */
interface HL7_XCN {
  assigningAgencyOrDepartment?: string;
  assigningAuthority?: string;
  assigningFacility?: string;
  assigningJurisdiction?: string;
  checkDigitScheme?: string;
  degree?: string;
  effectiveDate?: string;
  expirationDate?: string;
  familyName?: string;
  givenName?: string;
  identifierCheckDigit?: string;
  identifierTypeCode?: string;
  nameAssemblyOrder?: string;
  nameContext?: string;
  nameRepresentationCode?: string;
  nameTypeCode?: string;
  nameValidityRange?: string;
  personIdentifier?: string;
  prefix?: string;
  professionalSuffix?: string;
  secondAndFurtherGivenNamesOrInitialsThereof?: string;
  securityCheck?: string;
  securityCheckScheme?: string;
  sourceTable?: string;
  suffix?: string;
  /** XCN.1 - Person Identifier */
  xcn_1?: string;
  /** XCN.10 - Name Type Code */
  xcn_10?: string;
  /** XCN.11 - Identifier Check Digit */
  xcn_11?: string;
  /** XCN.12 - Check Digit Scheme */
  xcn_12?: string;
  /** XCN.13 - Identifier Type Code */
  xcn_13?: string;
  /** XCN.14 - Assigning Facility */
  xcn_14?: string;
  /** XCN.15 - Name Representation Code */
  xcn_15?: string;
  /** XCN.16 - Name Context */
  xcn_16?: string;
  /** XCN.17 - Name Validity Range */
  xcn_17?: string;
  /** XCN.18 - Name Assembly Order */
  xcn_18?: string;
  /** XCN.19 - Effective Date */
  xcn_19?: string;
  /** XCN.2 - Family Name */
  xcn_2?: string;
  /** XCN.20 - Expiration Date */
  xcn_20?: string;
  /** XCN.21 - Professional Suffix */
  xcn_21?: string;
  /** XCN.22 - Assigning Jurisdiction */
  xcn_22?: string;
  /** XCN.23 - Assigning Agency Or Department */
  xcn_23?: string;
  /** XCN.24 - Security Check */
  xcn_24?: string;
  /** XCN.25 - Security Check Scheme */
  xcn_25?: string;
  /** XCN.3 - Given Name */
  xcn_3?: string;
  /** XCN.4 - Second And Further Given Names Or Initials Thereof */
  xcn_4?: string;
  /** XCN.5 - Suffix (e.g., Jr Or Iii) */
  xcn_5?: string;
  /** XCN.6 - Prefix (e.g., Dr) */
  xcn_6?: string;
  /** XCN.7 - Degree (e.g., Md) */
  xcn_7?: string;
  /** XCN.8 - Source Table */
  xcn_8?: string;
  /** XCN.9 - Assigning Authority */
  xcn_9?: string;
}
//#endregion
//#region src/hl7/metadata/datatypes/xon.d.ts
/**
 * XON — composite HL7 data type.
 *
 * Generated from the Caristix HL7 Definition API
 * (https://hl7-definition.caristix.com/v2/HL7v2.X/DataTypes/XON)
 * by scripts/generate-segment-specs.mjs. Do not edit by hand — re-run
 * the generator instead.
 *
 * Both numeric (`xon_<n>`) and camelCase keys are accepted; pick
 * whichever reads better. The runtime composer joins set components
 * with the HL7 component separator (`^`) and validates each piece.
 *
 * @since 4.0.0
 */
interface HL7_XON {
  assigningAuthority?: string;
  assigningFacility?: string;
  checkDigit?: string;
  checkDigitScheme?: string;
  identifierTypeCode?: string;
  idNumber?: string;
  nameRepresentationCode?: string;
  organizationIdentifier?: string;
  organizationName?: string;
  organizationNameTypeCode?: string;
  /** XON.1 - Organization Name */
  xon_1?: string;
  /** XON.10 - Organization Identifier */
  xon_10?: string;
  /** XON.2 - Organization Name Type Code */
  xon_2?: string;
  /** XON.3 - Id Number */
  xon_3?: string;
  /** XON.4 - Check Digit */
  xon_4?: string;
  /** XON.5 - Check Digit Scheme */
  xon_5?: string;
  /** XON.6 - Assigning Authority */
  xon_6?: string;
  /** XON.7 - Identifier Type Code */
  xon_7?: string;
  /** XON.8 - Assigning Facility */
  xon_8?: string;
  /** XON.9 - Name Representation Code */
  xon_9?: string;
}
//#endregion
//#region src/hl7/metadata/datatypes/xpn.d.ts
/**
 * XPN — composite HL7 data type.
 *
 * Generated from the Caristix HL7 Definition API
 * (https://hl7-definition.caristix.com/v2/HL7v2.X/DataTypes/XPN)
 * by scripts/generate-segment-specs.mjs. Do not edit by hand — re-run
 * the generator instead.
 *
 * Both numeric (`xpn_<n>`) and camelCase keys are accepted; pick
 * whichever reads better. The runtime composer joins set components
 * with the HL7 component separator (`^`) and validates each piece.
 *
 * @since 4.0.0
 */
interface HL7_XPN {
  calledBy?: string;
  degree?: string;
  effectiveDate?: string;
  expirationDate?: string;
  familyName?: string;
  givenName?: string;
  nameAssemblyOrder?: string;
  nameContext?: string;
  nameRepresentationCode?: string;
  nameTypeCode?: string;
  nameValidityRange?: string;
  prefix?: string;
  professionalSuffix?: string;
  secondAndFurtherGivenNamesOrInitialsThereof?: string;
  suffix?: string;
  /** XPN.1 - Family Name */
  xpn_1?: string;
  /** XPN.10 - Name Validity Range */
  xpn_10?: string;
  /** XPN.11 - Name Assembly Order */
  xpn_11?: string;
  /** XPN.12 - Effective Date */
  xpn_12?: string;
  /** XPN.13 - Expiration Date */
  xpn_13?: string;
  /** XPN.14 - Professional Suffix */
  xpn_14?: string;
  /** XPN.15 - Called By */
  xpn_15?: string;
  /** XPN.2 - Given Name */
  xpn_2?: string;
  /** XPN.3 - Second And Further Given Names Or Initials Thereof */
  xpn_3?: string;
  /** XPN.4 - Suffix (e.g., Jr Or Iii) */
  xpn_4?: string;
  /** XPN.5 - Prefix (e.g., Dr) */
  xpn_5?: string;
  /** XPN.6 - Degree (e.g., Md) */
  xpn_6?: string;
  /** XPN.7 - Name Type Code */
  xpn_7?: string;
  /** XPN.8 - Name Representation Code */
  xpn_8?: string;
  /** XPN.9 - Name Context */
  xpn_9?: string;
}
//#endregion
//#region src/hl7/metadata/datatypes/xtn.d.ts
/**
 * XTN — composite HL7 data type.
 *
 * Generated from the Caristix HL7 Definition API
 * (https://hl7-definition.caristix.com/v2/HL7v2.X/DataTypes/XTN)
 * by scripts/generate-segment-specs.mjs. Do not edit by hand — re-run
 * the generator instead.
 *
 * Both numeric (`xtn_<n>`) and camelCase keys are accepted; pick
 * whichever reads better. The runtime composer joins set components
 * with the HL7 component separator (`^`) and validates each piece.
 *
 * @since 4.0.0
 */
interface HL7_XTN {
  anyText?: string;
  areaCityCode?: string;
  communicationAddress?: string;
  countryCode?: string;
  effectiveStartDate?: string;
  expirationDate?: string;
  expirationReason?: string;
  extension?: string;
  extensionPrefix?: string;
  localNumber?: string;
  preferenceOrder?: string;
  protectionCode?: string;
  sharedTelecommunicationIdentifier?: string;
  speedDialCode?: string;
  telecommunicationEquipmentType?: string;
  telecommunicationUseCode?: string;
  telephoneNumber?: string;
  unformattedTelephoneNumber?: string;
  /** XTN.1 - Telephone Number */
  xtn_1?: string;
  /** XTN.10 - Extension Prefix */
  xtn_10?: string;
  /** XTN.11 - Speed Dial Code */
  xtn_11?: string;
  /** XTN.12 - Unformatted Telephone Number */
  xtn_12?: string;
  /** XTN.13 - Effective Start Date */
  xtn_13?: string;
  /** XTN.14 - Expiration Date */
  xtn_14?: string;
  /** XTN.15 - Expiration Reason */
  xtn_15?: string;
  /** XTN.16 - Protection Code */
  xtn_16?: string;
  /** XTN.17 - Shared Telecommunication Identifier */
  xtn_17?: string;
  /** XTN.18 - Preference Order */
  xtn_18?: string;
  /** XTN.2 - Telecommunication Use Code */
  xtn_2?: string;
  /** XTN.3 - Telecommunication Equipment Type */
  xtn_3?: string;
  /** XTN.4 - Communication Address */
  xtn_4?: string;
  /** XTN.5 - Country Code */
  xtn_5?: string;
  /** XTN.6 - Area/City Code */
  xtn_6?: string;
  /** XTN.7 - Local Number */
  xtn_7?: string;
  /** XTN.8 - Extension */
  xtn_8?: string;
  /** XTN.9 - Any Text */
  xtn_9?: string;
}
//#endregion
//#region src/hl7/metadata/datatypes/index.d.ts
/**
 * Sub-component layout for every composite HL7 data type, keyed by
 * uppercase id (e.g. `"XAD"`, `"XPN"`, `"CWE"`). Used by the runtime
 * composer to validate and assemble `^`-delimited composite values.
 *
 * Components are taken from the version with the largest set, since
 * composite types only ever grow (added components never break older
 * positions).
 *
 * @since 4.0.0
 */
declare const DATA_TYPES: Readonly<Record<string, readonly ComponentSpec[]>>;
//#endregion
//#region src/hl7/metadata/segments/ecd.d.ts
/**
 * ECD — Equipment Command
 *
 * Generated from the Caristix HL7 Definition API
 * (https://hl7-definition.caristix.com/v2/HL7v2.X/Segments/ECD)
 * by scripts/generate-segment-specs.mjs. Do not edit by hand — re-run the
 * generator instead.
 *
 * @since 4.0.0
 */
declare const ECD_SPEC: SegmentSpec;
//#endregion
//#region src/hl7/metadata/segments/index.d.ts
/**
 * Lookup of every generated SegmentSpec, keyed by uppercase segment name.
 *
 * @since 4.0.0
 */
declare const SEGMENT_SPECS: Readonly<Record<string, SegmentSpec>>;
//#endregion
//#region src/modules/codec.d.ts
/** MLLPCodec Class
 * @since 3.1.0 */
declare class MLLPCodec {
  /** @internal */
  private readonly _encoding;
  /** @internal */
  private readonly _returnCharacter;
  /** @internal */
  private dataBuffer;
  /** @internal */
  private lastMessage;
  /**
   * @since 3.1.0
   * @param encoding
   * @param returnCharacter
   */
  constructor(encoding?: BufferEncoding, returnCharacter?: string);
  /**
   * Get the last message.
   * @since 3.1.0
   */
  getLastMessage(): null | string;
  /**
   * Process the incoming data from the client.
   * @since 3.1.0
   * @param data
   */
  receiveData(data: Buffer | string): boolean;
  /**
   * Send a message and send it to the remote side.
   * @since 3.1.0
   * @param socket
   * @param message
   * @param encoding
   */
  sendMessage(socket: Socket | undefined, message: string, encoding: BufferEncoding): void;
  /**
   * Process the stored message that was sent over.
   * @since 3.1.0
   * @private
   */
  private processMessage;
  /**
   * @since 3.1.0
   * @param message
   * @private
   */
  private stripMLLPCharacters;
}
//#endregion
//#region src/hl7/tables/registry.d.ts
declare const TABLES: Readonly<Record<HL7Version, Readonly<Record<string, readonly string[]>>>>;
/**
 * Look up an HL7 value table's allowed values for a given version. Accepts a
 * numeric id (e.g. `396`) or string id (e.g. `"0396"`); ids normalize to
 * 4-char zero-padded form. Returns undefined when the version lacks the table.
 *
 * @since 4.0.0
 */
declare function lookupTable(version: HL7Version, id: number | string): readonly string[] | undefined;
//#endregion
export { ACC, ADD, AIG, AIL, AIP, AIS, AL1, APR, BLG, BPX, BTX, Batch, CSP, CSR, CSS, CTD, Client, Client as default, type ClientBuilderFileOptions, type ClientBuilderMessageOptions, type ClientBuilderOptions, type ClientListenerOptions, type ClientOptions, ComponentSpec, Connection, DATA_TYPES, DG1, DRG, DSC, DSP, Delimiters, ECD_SPEC, ERR, EVN, EmptyNode, FT1, type FallBackHandler, FieldSpec, FileBatch, GOL, GT1, HL7Error, HL7FatalError, type HL7Node, HL7ParserError, HL7UsageCode, HL7ValidationError, HL7Version, HL7_2_1, type HL7_2_1_MSH, HL7_2_2, type HL7_2_2_MSH, HL7_2_3, HL7_2_3_1, type HL7_2_3_1_MSH, type HL7_2_3_MSH, HL7_2_4, HL7_2_4_ECD, type HL7_2_4_MSH, HL7_2_5, HL7_2_5_1, type HL7_2_5_1_MSH, type HL7_2_5_MSH, HL7_2_6, type HL7_2_6_MSH, HL7_2_7, HL7_2_7_1, type HL7_2_7_1_MSH, type HL7_2_7_MSH, HL7_2_8, type HL7_2_8_ECD, type HL7_2_8_MSH, HL7_BASE, type HL7_CE, type HL7_CWE, type HL7_CX, HL7_ECD, type HL7_EI, type HL7_HD, HL7_SPEC, type HL7_XAD, type HL7_XCN, type HL7_XON, type HL7_XPN, type HL7_XTN, IAM, type IConnection, IN1, IPC, ISD, ITM, IVT, InboundResponse, KNOWN_VERSIONS, MFE, MFI, MLLPCodec, MRG, MSA, MSH, Message, type MessageItem, NK1, NPU, NSC, NST, NTE, NodeBase, type NotifyPendingCount, OBR, OBX, ODS, ODT, OM1, OM2, OM3, OM4, OM5, OM6, ORC, type OutboundHandler, PCR, PD1, PID, PR1, PRA, PRB, PRD, PSH, PTH, PV1, QRD, QRF, RDF, RDT, REL, RGS, ROL, RX1, RXA, RXD, RXE, RXG, RXO, RXR, ReadyState, SCH, SEGMENT_SPECS, SFT, SPM, STF, STZ, Segment, SegmentList, SegmentSpec, TABLES, TXA, UB1, UB2, URD, URS, VAR, assertNumber, createDeferred, createHL7Date, decodeHexString, detectIPFamily, escapeForRegExp, expBackoff, isBatch, isFile, isHL7Number, isHL7String, isKnownVersion, lookupTable, padHL7Date, randomString, validIPv4, validIPv6 };
//# sourceMappingURL=index.d.mts.map